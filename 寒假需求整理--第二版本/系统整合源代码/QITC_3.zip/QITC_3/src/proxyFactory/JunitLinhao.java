package proxyFactory;

import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.junit.Test;

import cn.jxqt.service.Detection.ClientInforSituation;
import cn.jxqt.service.Detection.IStrategy;
import cn.jxqt.util.ExcelToDbUtil;

public class JunitLinhao {

	public static void main(String[] args) {
		List<Object> testResult = null;
		List<Object>ClientInfor = null;
		ExcelToDbUtil a = new ExcelToDbUtil();
		String[] voNames = {"ClientInfor","TestResult"};
			Map<String,List<Object>> excelContents = a.getAllByExcel("Detectionitem", voNames, "G:\\蓝点资料\\12级蓝点暑假项目\\产品阶段性任务\\寒假需求整理--第二版本\\项目测试\\数据导入测试模板\\江西农大蓝点工作室规定模板\\检测统计分析-模板.xls");
			testResult = excelContents.get("TestResult");
			ClientInfor = excelContents.get("ClientInfor");
			ProxyFactory proxy = new ProxyFactory();
			IStrategy a1 = (IStrategy) proxy.createProxyIntance(new DetectionServiceBean(testResult, ClientInfor));
			System.out.println("come on baby==>" +a1.getClientInfoSituation().toString());
	}
	@Test
	public void heihei(){
		
	}
	
	@Test
	public void haha(){
		Map map = new IdentityHashMap<String, String>();
		map.put("linhao", "linhao");
		map.put("linhu", "linhu");
		map.put("linpeng", "linpeng");
		map.put("linhu", "linhu");
		Iterator itPId = map.entrySet().iterator();
        while(itPId.hasNext()){
        	Map.Entry<String, String> entryPId = (Entry<String, String>) itPId.next();
        	System.out.println("map的值=="+entryPId.getKey()+"值==="+entryPId.getValue());
        }
	}
}
