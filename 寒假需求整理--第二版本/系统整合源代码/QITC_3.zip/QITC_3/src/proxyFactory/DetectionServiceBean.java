package proxyFactory;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import cn.jxqt.util.StatisticalAnalysisUtil;
import cn.jxqt.vo.ClientInfor;
import cn.jxqt.vo.statisticsalaysis.ClientInfoSituation;
import cn.jxqt.vo.statisticsalaysis.ComparisonInfor;
import cn.jxqt.vo.statisticsalaysis.DatectionSample;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmount;
import cn.jxqt.vo.statisticsalaysis.DetectionVarieties;
import cn.jxqt.vo.statisticsalaysis.StandardComparsionInfor;
import cn.jxqt.vo.statisticsalaysis.StatisticalComparison;
import cn.jxqt.vo.statisticsalaysis.ZBTest;

public class DetectionServiceBean implements IStrategy{
	 protected List<Object> testResasult = null;
	 protected List<Object> clientInfor = null;
	 public DetectionServiceBean(List<Object> testResasult,List<Object> clientInfor){
		   this.testResasult=testResasult;
		   this.clientInfor = clientInfor;
	   }
	// 测试表1 食品室2013年（1月至12月）受检茶叶数量与项次数
	@Override
	public List<DetectionVarieties> getDectionVarietiesOrAmount() {
		// TODO Auto-generated method stub
		return null;
	}
	// 送检客户情况
	@Override
	public List<ClientInfoSituation> getClientInfoSituation() {
		// TODO Auto-generated method stub
		List<String> ClientName = new ArrayList<String>();// 存放客户名称集合，该集合必须将重复数据覆盖
		Map mapPId = new IdentityHashMap<String, String>();// 存放客户名称以及送检样品数量的map集合
		Map mapClientAddress = new IdentityHashMap<String, String>();// 存放客户名称以及对应的所属地区
		List<ClientInfoSituation> list1 = new ArrayList<ClientInfoSituation>();// 将多个统计结果数存放在这个双重list集合并返回
		List<String> list = new ArrayList<String>();// 存放统计出的单个结果数
		List<String> amount = new ArrayList<String>();// 用于统计出样品的总数
		int size=clientInfor.size();
		for (int i = 0; i < size; i++) {// 遍历得到客户订单信息
			ClientInfor testa = (ClientInfor) clientInfor.get(i);
			ClientName.add(testa.getClient_name());
			// 送检样品数以及客户名称
			amount.add(testa.getP_id());
			mapPId.put(testa.getClient_name(), testa.getP_id());
//			PId.add(pid);
			// 客户地址以及客户名称
			mapClientAddress.put(testa.getClient_name(), testa.getClient_address());
		}
		List<String> amount1 = StatisticalAnalysisUtil
				.removeDuplicateWithOrder(amount);// 统计总的样品数量
		List<String> ClientName1 = StatisticalAnalysisUtil
				.removeDuplicateWithOrder(ClientName);// 将重复有顺序的数据转换成有顺序不重复的集合
		ClientInfoSituation clientInfoSituationSuper = new ClientInfoSituation();
		ClientInfoSituation clientInfoSituation = null;
		int size1 = ClientName1.size();
		for (int clientname1 = 0; clientname1 < size1; clientname1++) {// 一个类别对应多个样品，一个样品对应多个检测项目，用三循环达到一对多的关系
			String Client_Name = ClientName1.get(clientname1);// 客户名称
			List<String> pid = new ArrayList<String>();
			List<String> clientAddress2 = new ArrayList<String>();
			Iterator itPId = mapPId.entrySet().iterator();
	        while(itPId.hasNext()){
	        	Map.Entry<String, String> entryPId = (Entry<String, String>) itPId.next();
	        	if (Client_Name.equalsIgnoreCase(entryPId.getKey())) {
					pid.add(entryPId.getValue());
					Iterator itClient = mapClientAddress.entrySet().iterator();
					 while(itClient.hasNext()){
				        	Map.Entry<String, String> entryClient = (Entry<String, String>) itClient.next();
				        	if (Client_Name.equalsIgnoreCase(entryClient.getKey())) {
								clientAddress2.add(entryClient.getValue());
							}   
					 }
				}
	        }
			clientInfoSituation = (ClientInfoSituation) clientInfoSituationSuper.clone();
			clientInfoSituation.setId(clientname1 + 1);
			clientInfoSituation.setClientName(Client_Name);
			List<String> pid3 = StatisticalAnalysisUtil
					.removeDuplicateWithOrder(pid);// 将重复数据集合转换成有序不重复集合
			List<String> clientAddress3 = StatisticalAnalysisUtil
					.removeDuplicateWithOrder(clientAddress2);//
			int flag = pid3.size();
			double ratio = ((double) flag / (double) amount1.size()) * 100;
			String Ratio = StatisticalAnalysisUtil.getAfterTwo(ratio);
			clientInfoSituation.setInspectionRate(Ratio);
			// 样品数量
			clientInfoSituation.setInspectionNumber(flag);
			// 客户地址
			clientInfoSituation.setAddress(clientAddress3.get(0));
			list1.add(clientInfoSituation);
			list.clear();
		}
		return list1;
	  }
	// 样品检出情况(非自报检+自报检)
	@Override
	public List<DatectionSample> getDectionSample() {
		// TODO Auto-generated method stub
		return null;
	}
	// 检测方法使用种类及频次
	@Override
	public List<DectionMethodAmount> getDectionMethodOrAmount() {
		// TODO Auto-generated method stub
		return null;
	}
	//检出农药的频次与种类（除自报检）
	@Override
	public List<ZBTest> getZBCountResults() {
		// TODO Auto-generated method stub
		return null;
	}
    //	检测农药与限量标准对照表
	@Override
	public List<StatisticalComparison> getDectionMatchLimitedLibrary() {
		// TODO Auto-generated method stub
		return null;
	}
//	表八
	@Override
	public List<StandardComparsionInfor> getComparisonResultInfor(
			String[] selects) {
		// TODO Auto-generated method stub
		return null;
	}
//	表九
	@Override
	public List<ComparisonInfor> getDectionCheckLimitedLibrary(String[] selects) {
		// TODO Auto-generated method stub
		return null;
	}

}
