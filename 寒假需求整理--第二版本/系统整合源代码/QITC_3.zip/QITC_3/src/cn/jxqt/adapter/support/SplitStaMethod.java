package cn.jxqt.adapter.support;

public class SplitStaMethod {

	private static final SplitStaMethod INSTANCE = new SplitStaMethod();

	private SplitStaMethod() {
	}
	
	public static SplitStaMethod getInstance() {
		return INSTANCE;
	}

	/**
	 * 使用递归判断出是否存在标准编号格式的数据
	 * 
	 * @param str
	 * @param flag
	 * @param index
	 * @return
	 */
	private int matches(String str, boolean flag, int index) {
		if (str.matches("[a-zA-Z]+/[a-zA-Z]+\\W+\\d+.\\d+-\\d+")) {
			return index;
		} else {
			if (str.length() != 1) {
				// 如果是标准编号在后面
				if (!flag) {
					return matches(str.substring(1, str.length()), flag, ++index);
				} else {
					// 如果是标准编号在后面
					return matches(str.substring(0, str.length() - 1), flag,
							--index);
				}
			}
		}
		return -1;
	}

	/**
	 * 拆分出标准编号和标准名称
	 * @param str	
	 * @return
	 */
	public String[] split(String str) {
		String[] results = new String[2];
		boolean flag = false;
		int index = 0;
		// 判断标准在前面还是在后面，若匹配此正则表达式，则是在前面，否则在后面
		if (str.matches("^\\w+.+")) {
			flag = true;
			index = str.length();
		}
		// System.out.println("str is : " + str + " and flag is :" + flag +
		// "and index is :" + index);
		index = matches(str, flag, index);

		if (index == -1 && !flag) {
			// 只有标准编号的情况下
			if (flag) {
				results[1] = null;
				results[0] = str;
			} else {
				// 且没有标准编号
				results[0] = null;
				results[1] = str;
			}
		} else {
			if (flag) {
				results[0] = str.substring(0, index);
				results[1] = str.substring(index, str.length());
			} else {
				results[1] = str.substring(0, index);
				results[0] = str.substring(index, str.length());
			}
		}
		return results;
	}
}
