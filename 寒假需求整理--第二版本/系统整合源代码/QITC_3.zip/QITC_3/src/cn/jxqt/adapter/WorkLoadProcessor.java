package cn.jxqt.adapter;

import java.util.List;

import org.web.exception.VoProcessorException;
import org.web.service.VoProcessor;

import cn.jxqt.util.WorkLoadStatistics;
import cn.jxqt.vo.WorkLoad;

public class WorkLoadProcessor extends VoProcessor {

	@Override
	protected boolean isReverse(Object vo) {
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	protected List<Object> convert(List<Object> vos)
			throws VoProcessorException {

		return new WorkLoadStatistics(vos).statistics();
	}

	@Override
	protected List<Object> reverseConvert(List<Object> vos)
			throws VoProcessorException {
		return new WorkLoadStatistics(vos).statistics();
	}

}
