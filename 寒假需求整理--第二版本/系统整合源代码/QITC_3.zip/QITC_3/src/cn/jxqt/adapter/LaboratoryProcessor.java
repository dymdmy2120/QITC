package cn.jxqt.adapter;

import java.util.List;

import org.web.exception.VoProcessorException;
import org.web.service.VoProcessor;

import cn.jxqt.po.Laboratory;
import cn.jxqt.util.FirstLetterUtil;

public class LaboratoryProcessor extends VoProcessor {
	private static final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	@Override
	protected List<Object> convert(List<Object> vos)
													throws VoProcessorException {
		// TODO Auto-generated method stub
		Laboratory laboratory = null;
		String lab_id_head = null;
		int max = 2;
		for (Object o : vos) {
			laboratory = ((Laboratory) o);
			if(laboratory.getLab_id()!=null){
				continue;
			}
			String  lab_id = FirstLetterUtil.getFirstLetter(laboratory.getLab_name()).toUpperCase(); 
			if(lab_id.length() >= 6){
				lab_id_head = lab_id.substring(0, 6);
			}else{
				lab_id_head = lab_id;
				max = 8 - lab_id.length();
			}
			for(int i = 0; i < max ; i++){
				lab_id_head = lab_id_head + chars.charAt((int)(Math.random() * 26));
			}
			lab_id = lab_id_head;
			laboratory.setLab_id(lab_id);
		}
		return vos;
	}

	@Override
	protected List<Object> reverseConvert(List<Object> vos)
			throws VoProcessorException {
		// TODO Auto-generated method stub
		return vos;
	}

}
