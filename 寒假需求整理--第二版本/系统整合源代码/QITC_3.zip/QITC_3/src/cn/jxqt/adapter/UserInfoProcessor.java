package cn.jxqt.adapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.web.exception.VoProcessorException;
import org.web.service.VoProcessor;

import cn.jxqt.po.Power;
import cn.jxqt.po.User;
import cn.jxqt.po.UserPower;
import cn.jxqt.vo.UserInfo;

public class UserInfoProcessor extends VoProcessor {

	@Override
	protected List<Object> convert(List<Object> vos)
			throws VoProcessorException {
		
		UserInfo userinfo = (UserInfo) vos.get(0);
		User user = new User();
		list.clear();
		this.copyValue(user, userinfo, "p_id,p_ids");
		list.add(user);
		String[] p_ids = userinfo.getP_ids();
		if (p_ids != null) {
			for (int j = 0; j < p_ids.length; j++) {
				UserPower userpower = new UserPower();
				if (Integer.parseInt(p_ids[j]) <= 62) { // 过滤掉那些非法权限 62是最后一个权限
					userpower.setP_id(p_ids[j]);
					userpower.setU_id(userinfo.getU_id());
					list.add(userpower);
				}
			}
		}
		return list;
		
		
	}

	@Override
	protected List<Object> reverseConvert(List<Object> vos)
			throws VoProcessorException {
		List<Object> newlist = new ArrayList<Object>();
		Map<String, String> map = new HashMap<String, String>(); // 标记已经统计了的
		for (int j = 0; j < vos.size(); j++) {
			UserInfo userInfo = (UserInfo) vos.get(j);
			String u_id = userInfo.getU_id();
			if (map.get(u_id) == null) { // 进入if体 表示该用户u_id 还没有进行统计过
				String[] p_ids = listAdapter(vos, u_id);
				userInfo.setP_ids(p_ids);
				map.put(userInfo.getU_id(), userInfo.getU_id());
				newlist.add(userInfo);
			}
		}
		list.clear();
		list.addAll(newlist);
		return list;
	}

	@Override
	protected boolean isReverse(Object vo) {
		System.out.println("isReverse");
		if (((UserInfo) vo).getP_ids() != null) {
			return true;
		}
		if (((UserInfo) vo).getP_id() == null) {
			return true;
		}
		return false;
	}

	/**
	 * 根据传入的vos集合，以及用户编号，返回集合中该用户的权限形成的数组。
	 * 
	 * @param vos
	 * @param id
	 * @return
	 */
	@SuppressWarnings("unused")
	private String[] listAdapter(List<?> vos, String id) {
		String[] p_ids = new String[getSize(vos, id)];
		int temp = 0;
		for (int i = 0; i < vos.size(); i++) {
			UserInfo userInfo = (UserInfo) vos.get(i);
			if (userInfo.getU_id().equals(id)) {
				String p_id = userInfo.getP_id();
				p_ids[temp] = p_id;
				temp++;
			}

		}

		return p_ids;
	}

	/**
	 * 根据传入的集合以及用户编号ID,得到该用户ID的记录数目。
	 * 
	 * @param vos
	 * @param id
	 * @return 该userinfo在集合中的数目
	 */
	private int getSize(List<?> vos, String id) {
		int temp = 0;
		for (int i = 0; i < vos.size(); i++) {
			UserInfo userInfo = (UserInfo) vos.get(i);
			if (userInfo.getU_id().equals(id)) {
				temp++;
			}
		}
		return temp;
	}

}
