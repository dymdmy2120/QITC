package cn.jxqt.adapter;

import java.text.SimpleDateFormat;
import java.util.List;

import org.web.exception.VoProcessorException;
import org.web.service.VoProcessor;

import cn.jxqt.po.Laws;

public class LawsProcessor extends VoProcessor {

	@Override
	protected List<Object> convert(List<Object> vos)
								throws VoProcessorException {
		// TODO Auto-generated method stub
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			Laws law = null;
			for(Object o : vos){
				law = ((Laws)o);
				if(law != null && law.getLaws_id() == null){
					law.setLaws_id(dateFormat.format(law.getRel_date())+String.valueOf((int)(Math.random()*100)));
				}
			}
		return vos;
	}

	@Override
	protected List<Object> reverseConvert(List<Object> vos)
			throws VoProcessorException {
		// TODO Auto-generated method stub
		return vos;
	}

	@Override
	protected boolean isReverse(Object vo) {
		// TODO Auto-generated method stub
		return ((Laws)vo).getLaws_id()!= null;
	}

}
