package cn.jxqt.adapter;

import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.log4j.Logger;
import org.web.exception.VoProcessorException;
import org.web.service.VoProcessor;

import tool.mastery.core.StringUtil;
import cn.jxqt.adapter.support.SplitStaMethod;

public class LabAptProcessor extends VoProcessor {

	public static final Logger LOG = Logger.getLogger(LabAptProcessor.class);

	@Override
	protected List<Object> convert(List<Object> vos)
			throws VoProcessorException {
		for (Object bean : vos) {
			// 将前台传递过来数据进行拆分
			try {
				String staMethod = (String) PropertyUtils.getProperty(bean,
						"staMethod");
				if (StringUtil.StringIsNull(staMethod)) {
					continue;
				}
				// 切割标准方法，得到标准编号和标准名称
				String[] splitStr = SplitStaMethod.getInstance().split(
						staMethod);
				PropertyUtils.setProperty(bean, "m_id", splitStr[0]);
				PropertyUtils.setProperty(bean, "m_name", splitStr[1]);
			} catch (Exception e) {
				LOG.debug("错误信息为：" + e.getMessage() + e);
			}
		}
		return vos;
	}

	@Override
	protected List<Object> reverseConvert(List<Object> vos)
			throws VoProcessorException {
		for (Object bean : vos) {
			try {
				String m_id = (String) PropertyUtils
						.getProperty(bean, "m_id");
				String m_name = (String) PropertyUtils.getProperty(bean,
						"m_name");
				PropertyUtils.setProperty(bean, "staMethod", (m_name+ "  " + m_id));
			} catch (Exception e) {
				LOG.debug("错误信息为：" + e.getMessage() + e);
			}
		}
		return vos;
	}

}
