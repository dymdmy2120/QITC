package cn.jxqt.adapter;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.exception.DBException;
import org.web.exception.VoProcessorException;
import org.web.service.VoProcessor;

import cn.jxqt.po.Product;
import cn.jxqt.vo.Standard;

public class StandardProcessor extends VoProcessor {

	@Override
	protected List<Object> convert(List<Object> vos)
			throws VoProcessorException {
		// TODO Auto-generated method stub
		// 处理好的List集合
		List<Object> retList = new ArrayList<Object>();
		String seperator = "、";
		int vosSize = vos.size();
		for (int i = 0; i < vosSize; i++) {
			Standard standard = (Standard) vos.get(i);
			String matrix = standard.getMatrix();
			String matrix_id = standard.getMatrix_id();
			if (matrix == null) {
				throw new VoProcessorException("基质范围为空");
			}
			String[] matrixArray = matrix.split(seperator);
			String[] matrix_idArray = null;
			int max = 0; 
			if(matrix_id != null) {
				
				matrix_idArray = matrix_id.split(seperator);
				max = matrix_idArray.length;
			}
				
			int min = matrixArray.length;
		
			if (min > max) {
				int temp = min;
				min = max;
				max = temp;
			}
			for (int p_index = 0; p_index < max; p_index++) {
				Standard tempStandard = (Standard) standard.clone();
				if (matrix_idArray != null && matrix_idArray.length != max ) {
					if(p_index < min) {
						String p_id = matrix_idArray[p_index];
						tempStandard.setP_id(Integer.parseInt(p_id));
					}
				}else {
					if(matrix_idArray != null) {
					String p_id = matrix_idArray[p_index];
					tempStandard.setP_id(Integer.parseInt(p_id));
					}
				}
				if(matrixArray.length != max ) {
					if (p_index < min) {
						String pName = matrixArray[p_index];
						tempStandard.setP_name(pName);
					}
				}else {
					String pName = matrixArray[p_index];
					tempStandard.setP_name(pName);
				}
				retList.add(tempStandard);
			}

		}
		LOG.debug("retList is :" + retList);
		return retList;
	}

	@Override
	protected List<Object> reverseConvert(List<Object> vos)
			throws VoProcessorException {
		// TODO Auto-generated method stub
		List<Object> retList = new LinkedList<Object>();
		// 检测基质是 相同的标准号不同的样品以,分割开
		String separator = ",";
		int length = vos.size();
		// 连接所有sta_id字段
		StringBuilder strField = new StringBuilder();
		// 把产品以,连接
		StringBuilder strMatrix = new StringBuilder();
		// 把产品id以、隔开
		StringBuilder strMatrix_id = new StringBuilder();
		// 存放一个那个集合元素序号被访问
		int[] indexArray = new int[vos.size()];
		// 赋值
		initalArray(indexArray);
		// 存放该连接后的字符串中sta_id是否被访问 并设置为true都为未访问状态
		Boolean[] isAccessed = new Boolean[length];
		for (int i = 0; i < length; i++) {
			Integer sta_id = ((Standard) vos.get(i)).getSta_id();
			// 将所有sta_id以,拼接起来
			strField.append(sta_id + separator);
			isAccessed[i] = true;
		}

		// 以,拆分字段 该sta_id 为拼接后的 2,3,4,3,4,5
		String[] strArray = strField.toString().split(separator);
		strField.insert(0, separator);
		int strLength = strArray.length;
		for (int str_index = 0; str_index < strLength; str_index++) {
			strMatrix.setLength(0);
			strMatrix_id.setLength(0);
			String strTemp = strField.toString();
			// 表示该字符串是否已经被访问
			if (isAccessed[str_index].booleanValue()) {
				int index = -1;
				int count = 0;
				while (true) {

					// 对于 12,2,3,34 这种情况时候就无法正确得到sta_id出现的位置
					// 可把一系列字符串出现 ,12,用一个字母R替换掉,然后再得到R出现的位置

					// 对于两位的数字可能会出现问题 所有把其他所有数字替换成 以便和容器对象序号对应
					String regxFir = ",*.*," + strArray[str_index] + ",.*,*";
					String regxSec = ",*.*," + "\\d+" + ",.*,*";
					while (true) {
						if (strTemp.matches(regxFir)) {

							strTemp = strTemp.replaceAll(separator
									+ strArray[str_index] + separator, ",R,");
							// 先把要扫描的sta_id用R替换 替换完后用r替换其他sta_id
						} else if (strTemp.matches(regxSec)) {
							strTemp = strTemp.replaceAll(separator + "\\d+"
									+ separator, ",r,");
						} else {
							break;
						}
					}

					index = strTemp.indexOf("R", index + 1);
					if (index != -1)
						indexArray[count++] = index;
					// 在同一个sta_id的情况下去除相同的mbr_name
					if (index == -1) {
						// 重新给此对象设置 基质范围并添加到返回容器中
						Standard standard = (Standard) vos.get(str_index);
						// 去掉最后一个,
						String matrix = null;
						String matrix_id = null;
						if (!"".equals(strMatrix.toString()))
							matrix = strMatrix.deleteCharAt(
									strMatrix.lastIndexOf("、")).toString();
						if (!"".equals(strMatrix_id.toString()))
							matrix_id = strMatrix_id.deleteCharAt(
									strMatrix_id.lastIndexOf("、")).toString();

				

									standard.setMatrix(matrix);
									standard.setMatrix_id(strMatrix_id
											.toString());
									retList.add(standard);
						break;
					}
					String p_name = ((Standard) vos.get(index / 2)).getP_name();
					Integer p_id = ((Standard) vos.get(index / 2)).getP_id();

					String regxPname = ".*" + p_name + "、.*";
					if (p_name != null
							&& !strMatrix.toString().matches(regxPname)) {
						strMatrix.append(p_name + "、");
						strMatrix_id.append(p_id + "、");
					}
					// 把已访问的sta_id设置为true
					isAccessed[(index - 1) / 2] = false;
				}

			}

		}
		return retList;
	}

	private void initalArray(int[] valueArray) {
		for (int i = 0, legth = valueArray.length; i < legth; i++) {
			valueArray[i] = -1;
		}
	}

	public static void main(String[] args) throws VoProcessorException {

		StandardProcessor standard = new StandardProcessor();
		char[] c = { '1', '2' };

		List lists = new ArrayList<Object>();
		Standard standard1 = new Standard();
		Standard standard2 = new Standard();
		Standard standard3 = new Standard();
		Standard standard4 = new Standard();
		Standard standard5 = new Standard();
		Standard standard6 = new Standard();
		standard1.setSta_id(600);
		standard1.setP_name("时肉");
		standard1.setM_name("炔丙烯草胺");

		standard2.setSta_id(113);
		standard2.setP_name("牛肉");
		standard2.setM_name("杀虫脒");

		standard3.setSta_id(600);
		standard3.setP_name("时肉1");
		standard3.setM_name("炔丙烯草胺1");

		standard4.setSta_id(1);
		standard4.setP_name("米11肉");
		standard4.setM_name("β-六六六");

		standard5.setSta_id(600);
		standard5.setP_name("鸡时肉");
		standard5.setM_name("叠氮津");

		standard6.setSta_id(113);
		standard6.setP_name("鸡2肉");
		standard6.setM_name("炔丙烯草胺");

		lists.add(standard1);

		 lists.add(standard2);
		lists.add(standard3);
		 lists.add(standard4);
		lists.add(standard5);
		lists.add(standard6);

		//
		for (Object list : standard.reverseConvert(lists))
			System.out.println(list.toString());

		StringBuilder s = new StringBuilder();
		s.append("牛肉,");
		s.append("香蕉,");
		String s1 = "香蕉,牛肉,";
		String regxFir = ".*" + "香s蕉" + ",.*";
		boolean b = s1.matches(regxFir);
		String s2 = "1,2,4,";
		String[] a = s2.split(",");
		System.out.println(a.length);
		System.out.println(b + "b");

	}

}
