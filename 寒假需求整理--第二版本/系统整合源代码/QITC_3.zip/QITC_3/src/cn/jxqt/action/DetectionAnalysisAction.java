package cn.jxqt.action;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.web.dao.core.support.Page;
import org.web.exception.BeanInitializationException;
import org.web.servlet.ActionSupport;
import org.web.servlet.FilePathAware;
import org.web.servlet.HttpServletRequestAware;

import tool.mastery.core.CharacterUtil;
import cn.jxqt.po.User;
import cn.jxqt.service.deteanaly.DetectionAnalysisService;
import cn.jxqt.service.deteanaly.GetValueService;
import cn.jxqt.service.deteanaly.support.SqlConstant;
import cn.jxqt.util.ExcelToDbUtil;
import cn.jxqt.util.FileDelete;
import cn.jxqt.util.StorageData;
import cn.jxqt.vo.DCAssessment;
import cn.jxqt.vo.OperDetectAbility;

public class DetectionAnalysisAction extends ActionSupport implements
		FilePathAware, HttpServletRequestAware {

	/**
	 * 
	 */
	private Map<String, String> filePath = null;
	private HttpServletRequest request;

	@Override
	public String execute() throws BeanInitializationException {
		// TODO Auto-generated method stub
		// PrintWriter out = response.getWriter();
		// SmartUpload mySmartUpload = new SmartUpload();
		final String path = request.getSession().getServletContext()
				.getRealPath("/")
				+ "temp\\";// 固定文件上传路径为path并放在一个临时的文件夹中

		// int count = 0;
		// String fileName = "";
		try {
			/*
			 * // smartUpload变量进行初始化 mySmartUpload.initialize(config, request,
			 * response); // 准备上传 mySmartUpload.upload();
			 */
			Map<String, List<String>> boundsInfo = new HashMap<String, List<String>>(); // 存放的是限量库和要显示的字段
			List<List<Object>> beanInfo = new ArrayList<List<Object>>(); // 把查询的条件的值封装成一个集合的集合

			Map<String, String> chooseUnionTable = new HashMap<String, String>(
					3);
			String[] selects = request.getParameterValues("hazardsName");
			String[] fieldArray = null;
			String labName = null;

			chooseUnionTable.put("limit", request.getParameter("limit"));
			chooseUnionTable.put("apt", request.getParameter("apt"));
			chooseUnionTable.put("dete", request.getParameter("dete"));

			// System.out.println(request.getParameter("dete") + " " +
			// request.getParameter("limit") + " " +
			// request.getParameter("apt"));

			List<Object> listDcass = new ArrayList<Object>();
			Object tempObj = null;
			if (filePath == null) { // 表示客户没有上传文件而是输入的参数
				tempObj = request;
				// 获得实验室的值
				DCAssessment dcAssessent = new DCAssessment();
				dcAssessent.setP_name(request.getParameter("p_name"));
				dcAssessent.setLine(request.getParameter("m_line"));
				dcAssessent.setMbr_cname(request.getParameter("mbr_cname"));
				dcAssessent.setM_id(request.getParameter("m_id"));
				dcAssessent.setResidue(request.getParameter("residue"));
				listDcass.add(dcAssessent);
			} else {
				if (filePath.size() != 0) {
					String fileName = filePath.get("DCAssessment");
					System.out.println(fileName);
					List<Object> dcassessment = new ExcelToDbUtil()
							.getAllByExcel("DCAssessment", fileName);
					listDcass = dcassessment;

					FileDelete.deleteFile(fileName);

					filePath.clear();
				}
			}
			if (filePath == null) {
				labName = request.getParameter("laboratory");
				fieldArray = request.getParameterValues("s2");
			} else {
				labName = request.getParameter("laboratory");
				// labName = transCode(labName);
				fieldArray = request.getParameterValues("s2");
				selects = request.getParameterValues("hazardsName");
				// for (int i = 0; i < selects.length; i++) {
				// // 对标准名字进行转码否则出现乱码
				// selects[i] = transCode(selects[i]);
				// }
			}
			/*
			 * 遍历对象的集合
			 */
			if (labName != null) {
				labName = CharacterUtil.process(labName);
				// System.out.println("labName : " + labName);
			}
			for (Object objList : listDcass) {
				if (objList instanceof DCAssessment) {
					List<Object> bean = new ArrayList<Object>();
					DCAssessment dcassessent = (DCAssessment) objList;
					String p_name = CharacterUtil.process(dcassessent.getP_name());
					String m_line = CharacterUtil.process(dcassessent.getLine());
					String mbr_cname = CharacterUtil.process(dcassessent.getMbr_cname());
					String m_id = CharacterUtil.process(dcassessent.getM_id());
					String residue = CharacterUtil.process(dcassessent.getResidue());
					bean.add(p_name);
					bean.add(m_line);
					bean.add(mbr_cname);
					bean.add(m_id);
					bean.add(residue);
					//System.out.println(p_name + " : " + mbr_cname);
					if ((chooseUnionTable.get("apt") != null || chooseUnionTable
							.get("dete") != null)) {
						bean.add(labName);
					}else{
						bean.add(null);
					}
					beanInfo.add(bean);
					// System.out.println(m_line.length() + " " + m_line
					// + "m_line");
				} else {
					break;
				}
			}
			/*
			 * for (int i = 0; i < beanInfo.size(); i++) { List s =
			 * beanInfo.get(i); for (int k = 0; k < s.size(); k++)
			 * System.out.println(s.get(k) + " bean"); }
			 */

			List<String> parames = new ArrayList<String>();
			parames.add("p_name");
			parames.add("line");
			parames.add("mbr_cname");
			parames.add("residue");
			parames.add("noticeCount");
			for (int i = 0; i < fieldArray.length; i++) {
				if (fieldArray[i].equals("lab_id")) {
					parames.add("t_laboratory.lab_id");
				} else {
					parames.add(fieldArray[i]);
				}
			}
			for (int i = 0; i < selects.length; i++) {
				// System.out.println("b_name : " + selects[i]);
				boundsInfo.put(selects[i], parames);
			}

			Map<Long, String> mapField = GetValueService
					.getCorrespondMap(parames);
			String serachInfo = SqlConstant.searchInfo;
			
			if (chooseUnionTable.get("limit") == null) {
				serachInfo = SqlConstant.searchInfoNotBname;
			}

			Map<DCAssessment, Set<OperDetectAbility>> mapValues = DetectionAnalysisService
					.getInstance().convertDetectionNotRepeat(beanInfo,
							boundsInfo, serachInfo,
							chooseUnionTable);
			

			// request.setAttribute("result", resultMaps);
			HttpSession session = request.getSession();
			Page page = new Page();
			page.setMaxSize(2);
			page.setCount(mapValues.size());
			session.setAttribute("bean", page);
			session.setAttribute("mapField", mapField);
			session.setAttribute("mapValue", mapValues);

			// word生成代码段
			Object[] objs = new Object[3];
			User user = (User) session.getAttribute("user");
			if (user != null) {
				objs[0] = page;
				objs[1] = mapField; // 表头部分
				objs[2] = mapValues; // 表格单元内容
				StorageData
						.sotrage(user.getU_id() + "_detectionAnalysis", objs);
			} // word生成代码段

		} catch (Exception e) {

			e.printStackTrace();

		}

		return "successful";
	}

	/*
	 * private String getDispatcherPath(boolean executeResult) { // TODO
	 * Auto-generated method stub String retPath =
	 * "user_file/InforDec/result.jsp";
	 * 
	 * return retPath; }
	 */

	@Override
	public void setFilePath(Map<String, String> filePath) {
		this.filePath = filePath;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

}