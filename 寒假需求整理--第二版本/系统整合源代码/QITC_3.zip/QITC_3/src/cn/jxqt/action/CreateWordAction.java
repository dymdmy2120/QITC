package cn.jxqt.action;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.management.RuntimeErrorException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.web.dao.core.support.Page;
import org.web.exception.BeanInitializationException;
import org.web.framework.action.AutoWire;
import org.web.servlet.ActionSupport;
import org.web.servlet.FilePathAware;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.HttpServletResponseAware;

import cn.jxqt.po.User;
import cn.jxqt.util.CreateWord;
import cn.jxqt.util.ParseXml;
import cn.jxqt.util.StorageData;
import cn.jxqt.vo.AlarmSta;
import cn.jxqt.vo.DCAssessment;
import cn.jxqt.vo.OperDetectAbility;

/**
 * 预警通报 生成word
 * 
 * @author Administrator
 * 
 */
public class CreateWordAction extends ActionSupport implements
		HttpServletRequestAware, HttpServletResponseAware {
	private HttpServletRequest request;
	private HttpServletResponse response;
	String filepath = null; // 返回word的路径 相对于服务器网络地址
	@AutoWire
	private AlarmSta alarmSta;

	@Override
	public String execute() throws BeanInitializationException {

		// 参数值为 ewbsa(预警通报) detection(检测结果统计分析)
		String source = request.getParameter("source");
		String u_id = ((User) request.getSession().getAttribute("user"))
				.getU_id(); // 得到用户的id
		String key = u_id + "_" + source;
		StringBuffer rtn = new StringBuffer();
		Object[] objs = StorageData.getData(key); // 得到放进session中的数据项

		if ("ewbsa".equals(source)) { // 如果是预警通报发出的word生成请求
			String index = "";
			if (objs != null) {
				index = (String) objs[5];
				// 如果保存的是查看全部数据 就直接从仓库中取得
				if (index.equals("6") && StorageData.isExisted(key, alarmSta)) {

					// 如果session中保存了该用户的最新一次查询记录 就直接从session中取得数据
					AlarmSta alarmSta1 = (AlarmSta) objs[0];
					List<Object> obj = (List<Object>) objs[1];
					String[] highAlarm = (String[]) objs[2];
					String[] fieldName = (String[]) objs[3];
					StringBuffer content = (StringBuffer) objs[4];
					rtn = createEWBSAWord(alarmSta1, obj, highAlarm, fieldName,
							content);
				}
			}

			if (objs == null | !index.equals("6")
					| !StorageData.isExisted(key, alarmSta)) { // 如果session中没有该用户的最近一次查询

				EWBSAAction ewbsa = new EWBSAAction();
				ewbsa.setHttpServletResponse(response);
				ewbsa.setHttpServletRequest(request);
				ewbsa.setAlarmSta(alarmSta);
				ewbsa.setIndex("6");
				ewbsa.setParam("countries,rel_date,category,mbrsort,reject_des,measures");
				ewbsa.execute();

				rtn = createEWBSAWord(ewbsa.alarmSta, ewbsa.obj,
						ewbsa.highAlarm, ewbsa.fieldName, ewbsa.content);

			}

		}

		if ("detection".equals(source)) { // 如果是统计分析页面发出的word生成请求
			rtn = createDetectionWord(objs);
		}
		if ("detectionAnalysis".equals(source)) {

			Page page = (Page) objs[0];
			Map<Long, String> mapField = (Map<Long, String>) objs[1]; // 表头部分
			// 表格数据单元内容
			Map<DCAssessment, Set<OperDetectAbility>> mapValues = (Map<DCAssessment, Set<OperDetectAbility>>) objs[2];

			Iterator<Long> iterator = mapField.keySet().iterator();
			while (iterator.hasNext()) {
				Long temp = iterator.next();
			}
			Iterator<DCAssessment> iterator2 = mapValues.keySet().iterator();
			while (iterator2.hasNext()) {
				DCAssessment dcassessment = iterator2.next();
				Set<OperDetectAbility> set = mapValues.get(dcassessment);
				Iterator iterator3 = set.iterator();
//				System.out.println(iterator3.hasNext());
//				while (iterator3.hasNext()) {
//					System.out.println(dcassessment + " ===   "
//							+ (OperDetectAbility) iterator3.next());
//				}
			}

		}
		// 向前台返回xml文件
		try {
			this.response.getWriter().print(rtn);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return SUCCESS;
	}

	/**
	 * 创建预警通报的word
	 */
	public StringBuffer createEWBSAWord(AlarmSta alarmSta, List<Object> obj,
			String[] highAlarm, String[] fieldName, StringBuffer content) {

		// 构建返回到前台的xml
		StringBuffer rtn = new StringBuffer();
		rtn.append("<?xml version=\"1.0\"   encoding=\"UTF-8\" ?>");
		rtn.append("<contents>");

		try {
			ParseXml parsexml = new ParseXml(content.toString());
			List<String[]> list = parsexml.getValueByTagName("countries"); // 如果没有检测的国家就返回

			if (list.size() <= 0 | obj.size() <= 0 | highAlarm.length <= 0
					| fieldName.length <= 0) {
				rtn.append("<error>数据库没有数据 无法导出word!</error>");
			} else {

				CreateWord createWord = new CreateWord(request);

				filepath = createWord.createChartReport(alarmSta, obj,
						highAlarm, fieldName, content); // 生成预警通报的word文档

				// 构建生成的word在网站中的地址
				StringBuffer url = request.getRequestURL();
				String urlPath = new String(url);
				urlPath = urlPath.substring(0, urlPath.lastIndexOf("/"))
						+ "/temp/" + filepath + ".doc";
				rtn.append("<url>" + urlPath + "</url>");
			}

			rtn.append("</contents>");

		} catch (Exception e) {
			e.printStackTrace();
			rtn.append("<error>导出word出错，请检查是否安装word相关软件 或是系统中有无数据</error></contents>");
		}

		return rtn;

	}

	public StringBuffer createDetectionWord(Object[] objs) {

		// 构建返回到前台的xml
		StringBuffer rtn = new StringBuffer();
		rtn.append("<?xml version=\"1.0\"   encoding=\"UTF-8\" ?>");
		rtn.append("<contents>");

		CreateWord createWord = new CreateWord(request);
		try {

			filepath = createWord.createReport(objs); // 生成检测统计分析页面的word

			// 构建生成的word在网站中的地址
			StringBuffer url = request.getRequestURL();
			String urlPath = new String(url);
			urlPath = urlPath.substring(0, urlPath.lastIndexOf("/")) + "/temp/"
					+ filepath + ".doc";
			rtn.append("<url>" + urlPath + "</url>");

		} catch (Exception e) {
			rtn.append("<error>导出word失败 请重新生成报表 再导出word</error></contents>");
			e.printStackTrace();
		}
		rtn.append("</contents>");
		return rtn;

	}

	public StringBuffer createDetectionAnalysisWord(Object[] objs) {

		// 构建返回到前台的xml
		StringBuffer rtn = new StringBuffer();
		rtn.append("<?xml version=\"1.0\"   encoding=\"UTF-8\" ?>");
		rtn.append("<contents>");

		CreateWord createWord = new CreateWord(request);
		try {

			filepath = createWord.createReport(objs); // 生成检测统计分析页面的word

			// 构建生成的word在网站中的地址
			StringBuffer url = request.getRequestURL();
			String urlPath = new String(url);
			urlPath = urlPath.substring(0, urlPath.lastIndexOf("/")) + "/temp/"
					+ filepath + ".doc";
			rtn.append("<url>" + urlPath + "</url>");

		} catch (Exception e) {
			rtn.append("<error>导出word失败 请重新生成报表 再导出word</error></contents>");
			e.printStackTrace();
		}
		rtn.append("</contents>");
		return rtn;

	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {

		this.request = request;
	}

	@Override
	public void setHttpServletResponse(HttpServletResponse response) {
		this.response = response;
	}
}
