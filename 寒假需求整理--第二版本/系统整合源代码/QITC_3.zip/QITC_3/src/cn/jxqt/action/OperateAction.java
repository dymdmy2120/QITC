package cn.jxqt.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.web.dao.core.support.Page;
import org.web.exception.ActionExecuteException;
import org.web.exception.ErrorException;
import org.web.framework.Constant;
import org.web.framework.action.AutoWire;
import org.web.servlet.ActionSupport;
import org.web.servlet.FilePathAware;
import org.web.servlet.HttpServletRequestAware;
import org.web.util.QueryValueUtils;

import cn.jxqt.action.interceptor.Helper;
import cn.jxqt.po.User;
import cn.jxqt.service.ProxyImport;
import cn.jxqt.service.VerifyService;
import cn.jxqt.util.ExcelToDbUtil;
import cn.jxqt.util.LogUtil;
import cn.jxqt.util.PageUtil;
import cn.jxqt.vo.FileVoHelper;

public class OperateAction extends ActionSupport implements
		HttpServletRequestAware, FilePathAware {

	private HttpServletRequest request;

	private Map<String, String> filePath;

	private String category_id;

	private List<Object> allList;

	@AutoWire
	private List<Object> list;
	
	private static Logger log = Logger.getLogger(OperateAction.class.getName());

	@Override
	public String execute() throws Exception {
		String viewName = this.action
				.substring(0, this.action.lastIndexOf("_"));
		String operate = this.action
				.substring(this.action.lastIndexOf("_") + 1);
		init(viewName);
		
		Page page = PageUtil.getPage(request, QueryAction.SHOW_NUM);
		if (allList != null) {
			page.setCount(allList.size());
		}
		try {
			if (operate.equalsIgnoreCase(Constant.IMPORT)) {
				ProxyImport pi = new ProxyImport(new ExcelToDbUtil());
				if (category_id != null) {
					list = pi.getAllByExcel(viewName,
							filePath.get("uploadFile"), "category_id",
							category_id);
				} else if (request.getParameter("lab_id") != null) {
					list = pi.getAllByExcel(viewName,
							filePath.get("uploadFile"), "lab_id",
							request.getParameter("lab_id"));
				} else if (request.getParameter("addFlag").toString()
						.equals("labAdd")) {
					list = pi.getAllByExcel(viewName,
							filePath.get("uploadFile"), null, null);
				}
			}
			this.executeOperate(page, viewName, operate);
			String operateName = LogUtil.getOperateName(operate);
			String name = LogUtil.getViewName(viewName, category_id);
			LogUtil.setMDC(request);
			log.info(operateName + "了" + name + "的数据");
		} catch (ErrorException e) {
			this.addMessage(e.getMessage());
		}
		if(this.getResponseMessage().size() == 0) {
			this.addMessage("数据" + FileVoHelper.changeOperateToChinese(operate)
					+ "成功！请耐心等待审核，如需更改，请查看个人信息->未被审核数据进行操作");

		}
	
		/**
		 * 以下为跳转页面时的选项
		 */
		return isImportOrDelete(operate, page);
	}

	private void init(String viewName) {
		category_id = this.request.getParameter("category_id");
		if (category_id != null) {
			this.allowSendReuqstParam();
			this.setProperties("category_id", category_id);
		}
		allList = Helper.getAllList(category_id, request, viewName);
	}

	/**
	 * 当操作是import或者是delete时，返回对应的操作名称
	 * 
	 * @param operate
	 * @param flag
	 * @return
	 */
	private String isImportOrDelete(String operate, Page page) {
		if (operate.equalsIgnoreCase(Constant.DELETE)
				|| operate.equalsIgnoreCase(Constant.UPDATE)) {
			request.setAttribute("list",
					QueryValueUtils.getListByPage(allList, page));
			request.setAttribute("page", page);
			return "update";
		}
		if (operate.equalsIgnoreCase(Constant.IMPORT)) {
			return operate;
		}
		return SUCCESS;
	}

	public void executeOperate(Page page, String viewName, String operate)
			throws ErrorException, ActionExecuteException {
		VerifyService service = new VerifyService(viewName, category_id);
		service.commitVerify(Helper.getMorePageList(request, list, allList,
				viewName, operate, page), operate, (User) request.getSession()
				.getAttribute("user"), request.getParameter("reason"));
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setFilePath(Map<String, String> filePath) {
		this.filePath = filePath;
	}

}
