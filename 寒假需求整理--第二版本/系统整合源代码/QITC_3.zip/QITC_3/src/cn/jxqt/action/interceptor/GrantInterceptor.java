package cn.jxqt.action.interceptor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.exception.BeanInitializationException;
import org.web.exception.DBException;
import org.web.exception.ErrorException;
import org.web.framework.Constant;
import org.web.framework.action.support.ActionHelper;

import tool.mastery.log.Logger;
import cn.jxqt.po.User;
import cn.jxqt.po.UserPower;

public class GrantInterceptor {

	public static final Logger LOG = Logger.getLogger(GrantInterceptor.class);

	/**
	 * 用于存储系统登录过的用户 作用：为了每个用户登录后只做一次查询
	 */
	public static Map<String, String[]> userPower = new HashMap<String, String[]>();

	// 用来存储视图对应的编号
	public static Map<String, String> viewNum = new HashMap<String, String>();

	static {
		viewNum.put("Alarm", "0");
		viewNum.put("Standard", "1");
		viewNum.put("Hazards", "2");
		viewNum.put("Laboratory", "3");
		viewNum.put("Laws", "4");
		viewNum.put("LabNameAction", "5");
		viewNum.put("HazardsAction", "6");
	}

	/**
	 * 过滤规则
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	public static boolean filter(ServletRequest request,
			ServletResponse response) throws ServletException, IOException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpSession session = req.getSession();
		String requestUrl = req.getRequestURI();
		User user = (User) session.getAttribute("user");
		if (user != null) {
			// 得到视图名
			String viewName = ActionHelper.processAction(ActionHelper
					.processRequestPath(requestUrl))[0];
			if (viewName != null || requestUrl.matches(".+_add.+")
					|| requestUrl.matches(".+VerifyPageConf.+")) {
				List<String> info = new ArrayList<String>();
				// 获取视图对应的权限
				// 当视图是不需要权限时，返回不过滤
				if (!viewNum.containsKey(viewName)) {
					if (!requestUrl.matches(".+VerifyPageConf.+")) {
						return false;
					}
				}
				// 如果不存在此用户的痕迹
				if (!userPower.containsKey(user.getU_id())) {
					setPids(user);
				}
				// 获得对应用户的所有权限
				String[] pIds = userPower.get(user.getU_id());
				// 获得视图对应的权限号
				String p_id = viewNum.get(viewName);

				// 查看的权限是否存在
				boolean viewFlag = false;

				// 管理的权限是否存在
				boolean managerFlag = false, isManager = false;
				// 判断是否点击管理的
				if (requestUrl.indexOf("delete") != -1
						|| Constant.UPDATE.equalsIgnoreCase(request
								.getParameter("other"))
						|| requestUrl.matches(".+_add.+")) {
					isManager = true;
				}
				// 审核的权限是否存在
				boolean verifyFlag = false, isVerify = false;
				// 判断是否点击管理的
				if (requestUrl.matches(".+VerifyPageConf.+")) {
					isVerify = true;
				}
				for (int i = 0; i < pIds.length; i++) {
					if (pIds[i].equalsIgnoreCase("2")) {
						verifyFlag = true;
						continue;
					}
					// 若不存在此视图的权限时
					if (pIds[i].substring(0, 1).equalsIgnoreCase(p_id)) {
						if (pIds[i].substring(1, 2).equalsIgnoreCase("0")) {
							viewFlag = true;
						} else if (pIds[i].substring(1, 2)
								.equalsIgnoreCase("1")) {
							managerFlag = true;
						}
					}
				}
				// 如果点击了关于视图管理方面的操作，且没有权限则运行一下程序
				if (!managerFlag && isManager) {
					info.add("您没有管理权限，不能管理此视图的内容！");
					req.setAttribute("info", info);
					req.getRequestDispatcher("/" + viewName + ".query.do")
							.forward(new RemoveRequestParam(req), response);
					return true;
				} else if (!verifyFlag && isVerify) {
					info.add("您没有审核权限，不能进入！");
					req.setAttribute("info", info);
					req.getRequestDispatcher("/index.jsp").forward(req,
							response);
					return true;

				} else if (!viewFlag && !isVerify && !isManager) {// 如果点击了视图查看，但没有权限运行此下的程序
					info.add("您没有权限访问这个页面");
					req.setAttribute("info", info);
					req.getRequestDispatcher("/index.jsp").forward(request,
							response);
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 设置map中的pId
	 * 
	 * @param user
	 * @throws ErrorException
	 * @throws BeanInitializationException
	 */
	public static void setPids(User user) {
		UserPower up = new UserPower();
		up.setU_id(user.getU_id());
		DaoAdvice dao = DaoAdviceFactory.getDao("UserPower");
		List<Object> list = null;
		try {
			list = dao.query(UserPower.class, up, null, false);
		} catch (DBException e1) {
			LOG.debug(e1.getMessage(), e1);
		}
		String[] p_ids = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			up = (UserPower) list.get(i);
			p_ids[i] = up.getP_id();
		}
		userPower.put(user.getU_id(), p_ids);
	}

}
