package cn.jxqt.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.service.VerifyDataGeter;

public class VerifyPageConfAction extends ActionSupport implements
													HttpServletRequestAware {
	private HttpServletRequest request;
	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		VerifyDataGeter vdg = new VerifyDataGeter();
		Map<String,Boolean> result = vdg.getResult();
		this.request.setAttribute("leafsMap", result);
		return "verify";
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

}
