package cn.jxqt.action;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.service.deteanaly.GetValueService;

public class LabNameAction extends ActionSupport implements
		HttpServletRequestAware {

	private HttpServletRequest request;

	@Override
	public String execute() throws BeanInitializationException {

		// FetchFormValueAdvice advice = new
		// DefaultFetchFormValueAdvice(request,
		// "Hazards");

		List<String> boundNames = null;
		try {
			boundNames = getValue.getBoundNames();
		} catch (ErrorException e1) {
			e1.printStackTrace();
		}

		List<String> bname1 = removeDuplicateWithOrder(boundNames);
		
		// 获取实验室字段
		List<String> labName = null;
		try {
			labName = getValue.getLabNames();
		} catch (ErrorException e) {
			e.printStackTrace();
		}
		// System.out.println(labName + "labName");
		request.setAttribute("labName", labName);
		
		//System.out.println(bname1.size());
		request.setAttribute("list", bname1);

		return "successful";

	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	/*
	public String getDispatcherPath(boolean executeResult) {
		String dispatcherPath = "user_file/InforDec/analysic.jsp";
		return dispatcherPath;
	}*/

	private List<String> removeDuplicateWithOrder(List<String> list) {
		Set set = new HashSet<String>();
		List<String> newList = new ArrayList();
		for (Iterator iter = list.iterator(); iter.hasNext();) {
			Object element = iter.next();
			if (set.add(element))
				newList.add((String) element);
		}
		list.clear();
		list.addAll(newList);
		return list;
	}

	private static GetValueService getValue = new GetValueService();
}
