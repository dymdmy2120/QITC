package cn.jxqt.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.web.dao.core.support.Page;
import org.web.framework.action.AutoWire;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.service.VerifyService;
import cn.jxqt.util.PageUtil;
import cn.jxqt.vo.FileVo;

/**
 * 此action用于显示审核信息
 * 
 * @author mastery
 * @Time 2015-4-12 下午3:31:31
 * 
 */
public class VerifyInfoAction extends ActionSupport implements
		HttpServletRequestAware {

	private HttpServletRequest request;

	@AutoWire
	private FileVo fileVo;

	@Override
	public String execute() throws Exception {
		String category = request.getParameter("category_id");
		String viewName = this.action
				.substring(0, this.action.lastIndexOf("."));
		VerifyService service = new VerifyService(viewName, category);
		setResult(service, fileVo, request);
		// 设置参数
		this.allowSendReuqstParam();
		this.setProperties("category_id", category);
		if (request.getParameter("other")!=null) {
			if(request.getParameter("other").equals("Modify")){
				return "Modify";
			}else{
				return "other";
			}
		}
		return SUCCESS;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	public static void setResult(VerifyService service, FileVo fileVo,
			HttpServletRequest request) {
		Page page = PageUtil.getPage(request, QueryAction.SHOW_NUM);
		List<FileVo> list = service.getVerifyData(fileVo, page);
		request.setAttribute("list", list);
		request.setAttribute("page", page);
	}

}
