package cn.jxqt.action;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.web.exception.ErrorException;
import org.web.framework.action.AutoWire;
import org.web.service.QueryService;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.po.Audit;
import cn.jxqt.po.User;
import cn.jxqt.service.LoginService;
import cn.jxqt.util.LogUtil;
import cn.jxqt.util.PageUtil;

public class LoginAction extends ActionSupport implements
											HttpServletRequestAware {
	
	private static final Logger log = Logger.getLogger(LoginAction.class.getName());
	
	private HttpServletRequest request;
	@AutoWire
	private User user;
	private String operation;
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		operation = this.request.getParameter("operation");
		LoginService loginService = new LoginService();
		User retUser = null;
		try {
			//********************登录*****************
			retUser = loginService.performLogin(user,operation );
			this.request.getSession().setAttribute("user", retUser);
			
			if(operation.equals("userLogin")){
				if(loginService.checHasVerify(retUser)){
					this.request.setAttribute("hasVerify", "有新的数据!");
					this.setResponseMessage("系统存在新的数据需要您的审核！");
				}
			}
			
			//********************查询出审核反馈信息*****************
			Audit audit = new Audit();
			audit.setU_id(retUser.getU_id());
			List<Object> list = new QueryService("Audit").getResult(audit,PageUtil.getPage(request, 5));
			this.request.getSession().setAttribute("audits", list);
		} catch (ErrorException e) {
				System.out.println(e.getMessage());
				this.setResponseMessage(e.getMessage());
				return "failed";
		}
		if(operation.indexOf("admin") != -1){
			LogUtil.setMDC(request);
			log.info("管理员登陆");
			return "success2";
		}
//		log.info(LogUtil.ToInfor("普通用户登录",  request));
		LogUtil.setMDC(request);
		log.info("普通用户登陆");
		return "success1";
	}
	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

}
