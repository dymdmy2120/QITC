package cn.jxqt.action;

import javax.servlet.http.HttpServletRequest;

import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.servlet.ActionSupport;
import org.web.servlet.FetchFormValueAdvice;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.support.DefaultFetchFormValueAdvice;

import cn.jxqt.po.User;
import cn.jxqt.service.UserInfoManageService;
import cn.jxqt.util.MD5Util;

public class UserInfoManageAction extends ActionSupport implements
													HttpServletRequestAware{

	private HttpServletRequest request;
	private String operation;
	@Override
	public String execute() throws BeanInitializationException {
		return this.getDispatcherPath(this.executeMyAction());
	}
	private boolean executeMyAction(){
		operation = request.getParameter("operation");
		UserInfoManageService ums = new UserInfoManageService();
		FetchFormValueAdvice fetchForm = new DefaultFetchFormValueAdvice(request,"User");
		User user = null;
		try {
			user = (User)fetchForm.fetchFormObjectValue();
			if(user.getPhoto() != null){
				user.setPhoto(user.getPhoto().replace("\\", "/"));
			}
		} catch (Exception e) {
			return false;
		}
		
		try {
			if(operation.equals("alterpas") || operation.equals("User_updatePassword")){
				user.setPassword(MD5Util.EncoderByMd5(user.getPassword()));
			}
			User tempUser = ums.execute(user);
			if(!operation.equals("alterpas")){
				request.getSession().setAttribute("user", tempUser);
//				System.out.println("更新后查询的用户："+tempUser);
			}
			
			this.setResponseMessage("设置成功！");
		} catch (ErrorException e) {
//			e.printStackTrace();
			this.setResponseMessage(e.getMessage());
			return false;
		}
		if(operation.equals("User_updatePassword")){
			request.getSession().invalidate();
		}
		return true;
	}
	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	public String getDispatcherPath(boolean executeResult) {
		String dispatcherPath = "";
		if(operation.equals("alterpas") ){
			if(executeResult == true){
				return "login.jsp";
			}else{
				return "alerPas.jsp";
			}
		}else{
			dispatcherPath = "user_file/User/"+operation+".jsp";
		}
		return dispatcherPath;
	}

}
