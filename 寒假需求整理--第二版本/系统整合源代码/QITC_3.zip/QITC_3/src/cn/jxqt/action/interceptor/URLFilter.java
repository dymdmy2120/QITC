package cn.jxqt.action.interceptor;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import tool.mastery.core.CollectionUtil;
import tool.mastery.log.Logger;

/**
 * 权限拦截器，且判断是否登陆
 * 
 * @author Administrator
 * 
 */
public class URLFilter implements Filter {

	public static final Logger LOG = Logger.getLogger(URLFilter.class);

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		// 将对象转换成HttpServletRequest对象
		request.setCharacterEncoding("utf-8");
		HttpServletRequest req = (HttpServletRequest) request;
		// 获取uri路径
		String requestUri = req.getRequestURI();
		if (!requestUri.matches(".+\\.do")
				&& !requestUri.matches(".+_[add|query].+")) {
			if (req.getRequestURI().indexOf("index.jsp") != -1) {
				if (isLogin(req, response)) {
					LOG.debug("输入" + requestUri + "拦截成功，理由为: 用户尚未登陆！");
					return;
				}
			}
			chain.doFilter(request, response);
		} else {
			/*
			 * if(isLogin(req, response)) { LOG.debug("输入" + requestUri +
			 * "拦截成功，理由为: 用户尚未登陆！"); return; }
			 */
			if (GrantInterceptor.filter(request, response)) {
				return;
			}
			chain.doFilter(request, response);
		}
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
		// TODO Auto-generated method stub

	}

	/**
	 * 判断是否登录,若未登录则返回登录界面登录
	 * 
	 * @param req
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private boolean isLogin(HttpServletRequest req, ServletResponse response)
			throws ServletException, IOException {
		if (req.getSession().getAttribute("user") == null) {
			req.setAttribute("info",
					CollectionUtil.convertObjectToList("您尚未登录！请先登录！"));
			req.getRequestDispatcher("/login.jsp").forward(req, response);
			return true;
		}
		return false;
	}
}
