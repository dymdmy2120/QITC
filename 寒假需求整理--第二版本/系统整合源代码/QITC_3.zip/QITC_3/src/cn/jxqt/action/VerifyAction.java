package cn.jxqt.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.web.dao.core.support.Page;
import org.web.framework.Constant;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.action.interceptor.Helper;
import cn.jxqt.service.VerifyService;
import cn.jxqt.util.PageUtil;
import cn.jxqt.vo.FileVo;

/**
 * 此action用于数据审核
 * 
 * @author mastery
 * @Time 2015-4-12 下午6:57:53
 * 
 */
public class VerifyAction extends ActionSupport implements
		HttpServletRequestAware {

	private HttpServletRequest request;

	@Override
	public String execute() throws Exception {
		String[] fileVoIds = request.getParameterValues("fileVoId");
		List<FileVo> list = new ArrayList<FileVo>();
		if(fileVoIds != null) {
			FileVo fileVo = null;
			for (String fileVoId : fileVoIds) {
				fileVo = new FileVo();
				fileVo.setFileVoId(Integer.parseInt(fileVoId));
				list.add(fileVo);
			}
		}
		String result = request.getParameter("result");
		if(result == null) {
			throw new AssertionError("result参数不能为空！");
		}
		boolean isAgree = false;
		// 此时代表审核成功
		if(result.equalsIgnoreCase("true")) {
			isAgree = true;	
		}
		String category = request.getParameter("category_id");
		String viewName = this.action
				.substring(0, this.action.lastIndexOf("."));
		String verifyInfo = request.getParameter("verifyInfo");
		String flag = request.getParameter("flag");
		VerifyService service = new VerifyService(viewName, category);
		try {
			List<FileVo> allList = service.getVerifyData(null, null);
			Page page = PageUtil.getPage(request, QueryAction.SHOW_NUM);
			if(allList != null) {
				page.setCount(allList.size());
			}
			list = Helper.getMorePageList(request, list, allList, viewName, Constant.DELETE, page);
			service.verify(list, verifyInfo , isAgree);
		} catch (Exception e) {
			e.printStackTrace();
			this.addMessage(e.getMessage());
		}
		VerifyInfoAction.setResult(service, null, request);
		if(this.getResponseMessage().size() == 0) {
			this.addMessage("恭喜您，审核操作成功！");
		}
		if(flag !=null){
			return "modifydelete";
		}
		return "default";
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

}
