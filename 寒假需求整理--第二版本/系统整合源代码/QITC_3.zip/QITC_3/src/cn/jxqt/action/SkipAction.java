package cn.jxqt.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.web.dao.core.support.Page;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;


public class SkipAction extends ActionSupport implements HttpServletRequestAware{
	
	private HttpServletRequest request;
	@Override
	public String execute() throws Exception {
		HttpSession session = request.getSession();
		String firstIndex = request.getParameter("firstIndex");
		
		
		Page bean = (Page) session.getAttribute("bean");
		// 获得从页面中传递过来的数据
		int temp = Integer.parseInt(firstIndex);
		bean.setPage(temp);
		session.setAttribute("bean", bean);
		
		return "successful";
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

}
