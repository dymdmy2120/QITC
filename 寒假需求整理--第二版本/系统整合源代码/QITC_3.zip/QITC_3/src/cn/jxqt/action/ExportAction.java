package cn.jxqt.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web.dao.core.support.Page;
import org.web.framework.Constant;
import org.web.framework.action.AutoWire;
import org.web.framework.action.support.ActionHelper;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.HttpServletResponseAware;

import cn.jxqt.action.interceptor.Helper;
import cn.jxqt.util.ExportUtil;
import cn.jxqt.util.PageUtil;

public class ExportAction extends ActionSupport implements
		HttpServletRequestAware, HttpServletResponseAware {
	private HttpServletRequest request;
	private HttpServletResponse response;
	@AutoWire
	private List<Object> list;

	@Override
	public String execute() throws Exception {
		String excelPath = request.getServletContext().getRealPath("")
				+ "/WEB-INF/classes/export.xml";
		String viewName = ActionHelper.processAction(this.action)[0];
		Page page = PageUtil.getPage(request, QueryAction.SHOW_NUM);
		List<Object> allList = Helper.getAllList(request.getParameter("category_id"), request, viewName);
		if (allList != null) {
			page.setCount(allList.size());
		}
		List<Object> listValue = Helper.getMorePageList(request, list, allList, viewName, Constant.DELETE,page);
		ExportUtil export = new ExportUtil(excelPath);
		export.buildExcel(listValue, viewName.toLowerCase(), "E://export.xls");

		response.setContentType("application/msexcel;charset=GBK");
		response.setHeader("Content-Disposition", "attachment;filename=\""
				+ new String("export.xls".getBytes(), "ISO8859-1") + "\"");
		ExportUtil.export("E://export.xls", response);

		return SUCCESS;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setHttpServletResponse(HttpServletResponse response) {
		this.response = response;
	}

}
