package cn.jxqt.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.web.exception.BeanInitializationException;
import org.web.servlet.ActionSupport;
import org.web.servlet.FilePathAware;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.po.User;
import cn.jxqt.service.Detection.ClientInforKey;
import cn.jxqt.service.Detection.ClientInforSituation;
import cn.jxqt.service.Detection.ComparisonResultAnaylse;
import cn.jxqt.service.Detection.ComparsionAnalyse;
import cn.jxqt.service.Detection.DectionMethodOrAmount;
import cn.jxqt.service.Detection.DectionMethodOrAmountKey;
import cn.jxqt.service.Detection.DectionSampleOr25;
import cn.jxqt.service.Detection.DectionSampleOr25Key;
import cn.jxqt.service.Detection.DectionVarietiesOrAmount;
import cn.jxqt.service.Detection.DectionVarietiesOrAmountKey;
import cn.jxqt.service.Detection.FatherKey;
import cn.jxqt.service.Detection.IStrategy;
import cn.jxqt.service.Detection.StandardComparison;
import cn.jxqt.service.Detection.StandardComparsionResultAnaylse;
import cn.jxqt.service.Detection.ZBCountUtil;
import cn.jxqt.util.ExcelException;
import cn.jxqt.util.ExcelToDbUtil;
import cn.jxqt.util.FileDelete;
import cn.jxqt.util.ManangerUtil;
import cn.jxqt.util.StorageData;
import cn.jxqt.vo.statisticsalaysis.ComparisonInfor;
import cn.jxqt.vo.statisticsalaysis.DatectionSample;
import cn.jxqt.vo.statisticsalaysis.DetectionVarieties;
import cn.jxqt.vo.statisticsalaysis.StandardComparsionInfor;

public class DetectionAction extends ActionSupport implements
		HttpServletRequestAware, FilePathAware {
	private int i = 0;
	private Map<String, String> filePath;
	private HttpServletRequest request;
	private String DocumentTitle;
	private String DetectionItem;
	private String TestDate;
	private String Department;
	private String exceptionInfo;
	private String[] selected = null;
	List<Object> testResult = null;
	List<Object> ClientInfo = null;
	List<StandardComparsionInfor> comparisonResultInfor = null;
	List<ComparisonInfor> dectionCheckLimitedLibrary = null;
	Object[] objs = null;
    ManangerUtil manger = null;
	@Override
	public String execute() throws BeanInitializationException {
		// TODO Auto-generated method stub
		// 获取临时数据

		selected = request.getParameterValues("s2");
		DocumentTitle = request.getParameter("DocumentTitle");
		DetectionItem = request.getParameter("DetectionItem");
		TestDate = request.getParameter("TestDate");
		Department = request.getParameter("Department");
		// 设置临时数据进行编排
		request.setAttribute("documentTitle", DocumentTitle);
		request.setAttribute("detectionItem", DetectionItem);
		request.setAttribute("testDate", TestDate);
		request.setAttribute("department", Department);
		request.setAttribute("selected", selected);

		// 得到Excel表中的内容
		ExcelToDbUtil a = new ExcelToDbUtil();
		String[] voNames = { "ClientInfor", "TestResult" };
		try {
			Map<String, List<Object>> excelContents = a.getAllByExcel(
					"Detectionitem", voNames, filePath.get("fileUpload"));
			ClientInfo = excelContents.get("ClientInfor");
			testResult = excelContents.get("TestResult");
		} catch (ExcelException e) {
			// TODO Auto-generated catch block
			exceptionInfo = e.getMessage();
			return "error";
		} finally {
			// 对临时数据进行删除，防止服务器负载严重。
			request.setAttribute("exceptionInfo", exceptionInfo);
			FileDelete.deleteFile(filePath.get("fileUpload"));
		}
		// 生成word文档 将查询出来的信息放到session中
		objs = new Object[22];
		manger = new ManangerUtil(testResult, ClientInfo);
		manger.getParam();
		try {
			CustomThread t1 = new CustomThread();
			CustomThread1 t = new CustomThread1(t1);
			try {
				t1.start();
				Thread.sleep(2000);
				t.start();
				t.join();
				t1.join();
			} catch (Exception e) {
				this.setResponseMessage("系统很忙，请等一下操作!");
				return "error";
			}
			HttpSession session = this.request.getSession();
			User user = (User) session.getAttribute("user");
			StorageData.sotrage(user.getU_id() + "_detection", objs); // 将查询出来的信息放到session中
			// 生成word结束
			return "successful";
		} catch (RuntimeException e) {
			e.printStackTrace();
			this.setResponseMessage("统计出错，请从新统计！");
			return "error";
		}
	}

	// 前面7張表
	class CustomThread extends Thread {
		public void run() {
			String threadName = Thread.currentThread().getName();
			System.out.println(threadName + " start.");
			try {
				IStrategy a1 = new DectionVarietiesOrAmount(manger);
				List<DetectionVarieties> dectionVarietiesOrAmount = a1
						.getDectionVarietiesOrAmount();
				request.setAttribute("DectionVarietiesOrAmount",
						dectionVarietiesOrAmount);
				// 检测样品及项目关键字
				FatherKey b1 = new DectionVarietiesOrAmountKey(
						a1.getDectionVarietiesOrAmount());
				request.setAttribute("DectionVarietiesOrAmountKey",
						b1.getDectionVarietiesOrAmountKey());
				// 送检客户情况
				IStrategy a2 = new ClientInforSituation(manger);
				request.setAttribute("ClientInforSituation",
						a2.getClientInfoSituation());
				// 送检客户情况关键字
				FatherKey b2 = new ClientInforKey(a2.getClientInfoSituation());
				request.setAttribute("ClientInforKey", b2.getClientInforKey());
				// 样品检出情况（除自报检）+关键字
				IStrategy a3 = new DectionSampleOr25(manger, "!25");
				request.setAttribute("DectionSampleOrNo25",
						a3.getDectionSample());
				FatherKey b3 = new DectionSampleOr25Key(a3.getDectionSample());
				request.setAttribute("DectionSampleOr25Key",
						b3.getDectionSampleOr25Key());
				// 样品检出情况自报检
				IStrategy a4 = new DectionSampleOr25(manger, "25");
				List<DatectionSample> dectionSampleOr25 = DetectionAction
						.reMove(a4.getDectionSample());
				request.setAttribute("DectionSampleOr25", dectionSampleOr25);
				// 检出农药的频次与种类（除自报检）
				ZBCountUtil a5 = new ZBCountUtil(manger);
				request.setAttribute("ZBCountResults25", a5.getTableZB_mmt());
				request.setAttribute("ZBCountResultsNo25", a5.getTableNotZB_mmt());
				request.setAttribute("ReadKeyword", a5.getKeyWord_mmt());
				// 检测方法使用种类及频次
				IStrategy a6 = new DectionMethodOrAmount(manger);
				request.setAttribute("DectionMethodOrAmount",
						a6.getDectionMethodOrAmount());
				FatherKey b6 = new DectionMethodOrAmountKey(
						a6.getDectionMethodOrAmount());
				request.setAttribute("DectionMethodOrAmountKey",
						b6.getDectionMethodOrAmountKey());

				
				objs[0] = DocumentTitle;
				objs[1] = DetectionItem;
				objs[2] = TestDate;
				objs[3] = Department;
				objs[4] = selected;
				objs[5] = dectionVarietiesOrAmount;
				objs[6] = b1.getDectionVarietiesOrAmountKey();
				objs[7] = a2.getClientInfoSituation();
				objs[8] = b2.getClientInforKey();
				objs[9] = a3.getDectionSample();
				objs[10] = b3.getDectionSampleOr25Key();
				objs[11] = dectionSampleOr25;
				objs[12] = a5.getTableZB_mmt();
				objs[13] = a5.getKeyWord_mmt();
				objs[14] = a6.getDectionMethodOrAmount();
				objs[15] = b6.getDectionMethodOrAmountKey();
				objs[20] = a5.getTableNotZB_mmt();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// 後面2張表
	class CustomThread1 extends Thread {
		CustomThread t;

		public CustomThread1(CustomThread t) {
			this.t = t;
		}

		public void run() {
			try {
				// 张晨辉
				IStrategy a7 = new StandardComparison(manger);
				comparisonResultInfor = a7.getComparisonResultInfor(selected);
				request.setAttribute("criList", comparisonResultInfor);
				request.setAttribute("scrList", StandardComparsionResultAnaylse
						.getStandardComparsionResult(comparisonResultInfor,
								selected));
				IStrategy a8 = new ComparsionAnalyse(manger);
				dectionCheckLimitedLibrary = a8
						.getDectionCheckLimitedLibrary(selected);
				request.setAttribute("comparisonList",
						dectionCheckLimitedLibrary);
				request.setAttribute("resultList", ComparisonResultAnaylse
						.getComparisonResult(dectionCheckLimitedLibrary,
								selected));
				objs[16] = comparisonResultInfor;
				objs[17] = StandardComparsionResultAnaylse
						.getStandardComparsionResult(comparisonResultInfor,
								selected);
				objs[18] = dectionCheckLimitedLibrary;
				objs[19] = ComparisonResultAnaylse.getComparisonResult(
						dectionCheckLimitedLibrary, selected);
			} catch (Exception e) {
				System.out.println("Exception from " + ".run");
			}
		}
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generatthised method stub
		this.request = request;
	}

	@Override
	public void setFilePath(Map<String, String> filePath) {
		// TODO Auto-generated method stub
		this.filePath = filePath;
	}

	// 筛除非自报检样品
	private static List<DatectionSample> reMove(
			List<DatectionSample> dectionSample) {
		// TODO Auto-generated method stub
		List<DatectionSample> list = new ArrayList<DatectionSample>();
		for (int i = 0; i < dectionSample.size(); i++) {
			if (dectionSample.get(i).getSampleNumber() != 0) {
				list.add(dectionSample.get(i));
			}
		}
		return list;
	}
}
