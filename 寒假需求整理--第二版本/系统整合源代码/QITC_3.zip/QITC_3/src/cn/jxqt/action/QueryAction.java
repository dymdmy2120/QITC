package cn.jxqt.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.web.dao.core.support.Page;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.framework.action.AutoWire;
import org.web.service.QueryService;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

import tool.mastery.log.Logger;
import cn.jxqt.service.DemandService;
import cn.jxqt.util.LogUtil;
import cn.jxqt.util.PageUtil;

public class QueryAction extends ActionSupport implements
		HttpServletRequestAware {

	public static final Logger log = Logger.getLogger(QueryAction.class);
	// 设置每页显示条数
	public static final Integer SHOW_NUM = 15;

	private HttpServletRequest request;

	private String viewName;

	private String category;

	@AutoWire
	private Object vo;

	@Override
	public String execute() throws BeanInitializationException {
		viewName = this.action.substring(0, this.action.lastIndexOf("."));
		category = request.getParameter("category_id");
		String name = LogUtil.getViewName(viewName, category);
		LogUtil.setMDC(request);
		log.info("查看" + name);
		try {
			this.request.setAttribute("category_id", category);
			this.executeQuery(viewName, vo);
		} catch (ErrorException e) {
			// e.printStackTrace();
			this.setResponseMessage(e.getMessage());
			return ERROR;
		}
		if (request.getParameter("other") != null) {
			return request.getParameter("other");
		}
		return SUCCESS;
	}

	// 删除不能进行，表示设置了alarm_id,传入进来了，报错是action没有配置
	// 页面不能进行下一页，报空指针，打印出来显示是获得第二页的，都是你的底层报错
	public void executeQuery(String viewName, Object bean)
			throws ErrorException, BeanInitializationException {
		String lab_id = request.getParameter("lab_id");
		QueryService service = null;
		if ("Audit".equalsIgnoreCase(viewName)) {
			service = new DemandService(viewName, true, "u_id",
					request.getParameter("u_id"));
		}else if (category == null && lab_id == null && !"laboratory".equalsIgnoreCase(viewName)) {
			service = new QueryService(viewName, true , true);
		} else if (category != null) {
			service = new DemandService(viewName, true, "category_id", category);
		} else if (lab_id != null  || "laboratory".equalsIgnoreCase(viewName)) {
			service = new DemandService(viewName, true, "lab_id", lab_id);
		}
		Page page = PageUtil.getPage(this.request, SHOW_NUM);
		List<Object> list = service.getResult(bean, page);
		this.request.setAttribute("list", list);
		this.request.setAttribute("page", page);
		this.request.getSession().setAttribute("lists", list);
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

}
