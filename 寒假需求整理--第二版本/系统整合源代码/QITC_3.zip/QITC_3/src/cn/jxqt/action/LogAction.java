package cn.jxqt.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.web.dao.core.support.Page;
import org.web.service.QueryService;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.po.Operate;
import cn.jxqt.util.PageUtil;

public class LogAction extends ActionSupport implements HttpServletRequestAware{

	private HttpServletRequest request;
	
	@Override
	public String execute() throws Exception {
		String query = request.getParameter("query");
		Page page = PageUtil.getPage(request, 10);
		List<Object> operates = null;
		if(query== null || query.equals("")) {
			operates = new QueryService("Operate").getResult(null, page);
		} else {
			Operate operate = new Operate();
			operate.setU_name(query);
			operates = new QueryService("Operate",true).getResult(operate, page);
		}
System.out.println(query+"come on");
System.out.println(operates+"come on");
		request.setAttribute("list", operates);
		request.setAttribute("page", page);
		request.setAttribute("query", query);
		return this.SUCCESS;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}
	
}
