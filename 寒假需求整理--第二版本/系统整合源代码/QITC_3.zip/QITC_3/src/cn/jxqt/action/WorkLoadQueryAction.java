package cn.jxqt.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web.dao.core.support.Page;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.framework.action.AutoWire;
import org.web.service.QueryService;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.HttpServletResponseAware;

import cn.jxqt.vo.WorkLoad;

public class WorkLoadQueryAction extends ActionSupport implements
		HttpServletRequestAware, HttpServletResponseAware {

	private HttpServletRequest request;

	private HttpServletResponse response;
	private List<Object> list = null;
	private String viewName;
	private static String endTime; // 需要查询的截止时间
	@AutoWire
	private WorkLoad vo;

	@Override
	public String execute() throws BeanInitializationException {
		viewName = "WorkLoad";
		endTime = request.getParameter("createtime1");
		try {
			this.executeQuery(viewName, vo);
		} catch (ErrorException e) {
			e.printStackTrace();
			this.setResponseMessage(e.getMessage());
			return ERROR;
		}
		return SUCCESS;
	}

	public void executeQuery(String viewName, Object bean)
			throws ErrorException, BeanInitializationException {
		QueryService service = new QueryService(viewName);
		Page page = getPage();
		list = service.getResult(bean, page);
		this.request.setAttribute("list", list);
		this.request.setAttribute("page", page);
	}

	private Page getPage() {
		Page page = new Page();
		// 获得从页面中传递过来的数据
		String firstIndex = this.request.getParameter("firstIndex");
		if (firstIndex != null) {
			int temp = Integer.parseInt(firstIndex);
			page.setPage(temp);
		}
		return page;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setHttpServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public static String getEndTime() {
		return endTime;
	}
}
