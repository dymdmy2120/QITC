package cn.jxqt.action;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.web.dao.core.support.GlobalSqlAdvice;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.framework.action.AutoWire;
import org.web.servlet.ActionSupport;
import org.web.servlet.FetchFormValueAdvice;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.HttpServletResponseAware;
import org.web.servlet.support.DefaultFetchFormValueAdvice;

import cn.jxqt.po.User;
import cn.jxqt.service.EWBSAService;
import cn.jxqt.util.StorageData;
import cn.jxqt.vo.AlarmSta;

public class EWBSAAction extends ActionSupport implements
		HttpServletRequestAware, HttpServletResponseAware {

	private HttpServletRequest request;
	private HttpServletResponse response;
	private String param;
	private boolean flag = true; // 这里是判断是生成word还是正常的预警通报业务逻辑 默认是预警通报的业务逻辑
	private String index;
	public List<Object> obj;
	public String[] fieldName;
	public String[] highAlarm;
	public Map m;
	public StringBuffer content;
	private static final String LOCK = "";
	@AutoWire
	public AlarmSta alarmSta;

	@Override
	public String execute() throws BeanInitializationException {
		GlobalSqlAdvice.INSTANCE.allowPrintSql(false);
		response.setContentType("text/xml;charset=utf-8");
		response.setHeader("Cache-Control", "no-cache");

		try {
			synchronized(LOCK){
			String year = ((AlarmSta) alarmSta).getYear();
			String title = ((AlarmSta) alarmSta).getTitle();
			String district = ((AlarmSta) alarmSta).getDistrict();

			param = request.getParameter("param"); // 要显示图表的字段 国家还是月份
			index = request.getParameter("index");// 获取得到的柱状图的序号

			if (param == null && index == null) { // 这里是为了配合 生成word需要设置的 默认生成
				param = "countries,rel_date,category,mbrsort,reject_des,measures";
				index = "6";
				flag = false;
			}

			HttpSession session = request.getSession();

			EWBSAService ewBSAService = EWBSAService.getInstance();

			content = new StringBuffer("");
			content.append("<?xml version=\"1.0\"   encoding=\"UTF-8\" ?>");
			content.append("<contents>");
			fieldName = ewBSAService.getPicNamArry(param, session, index,
					alarmSta);
			if (fieldName != null) {
				content.append("<content>");
				for (int i = 0; i < fieldName.length; i++) {
					content.append("<picName>" + fieldName[i] + "</picName>");
				}
				content.append("</content>");

			// 得到的是某年对中国出口产品的统计
			obj = ewBSAService.retChiaOri();
			content.append("<common>");
			content.append("<year>" + year + "</year>");
			content.append("<district>" + district + "</district>");
			content.append("<title>" + title + "</title>");
			content.append("<wholeItem>" + obj.get(0) + "</wholeItem>");
			content.append("<chinaItem>" + obj.get(1) + "</chinaItem>");
			content.append("<proportion>" + obj.get(2) + "</proportion>");
			content.append("</common>");

			content.append("<china>");
			highAlarm = (String[]) obj.get(3);
			for (String s : highAlarm) {
				// 第一个index内容是国家对原产地是中国的通报次数最多 第二个是月份 依次下去
				content.append("<first>" + s + "</first>");
			}
			content.append("</china>");
			// 对通报次数排在前三位进行统计
			m = ewBSAService.getStatResu();
			Set<Entry<String, Map>> set = m.entrySet();
			content.append("<rank>");
			for (Iterator it = set.iterator(); it.hasNext();) {
				Entry<String, Map> ee = (Entry<String, Map>) it.next();

				content.append("<" + ee.getKey() + ">");

				for (Iterator i = ee.getValue().entrySet().iterator(); i
						.hasNext();) {
					Entry<String, List> eee = (Entry<String, List>) i.next();

					content.append("<rankC>");

					for (int k = 0; k < eee.getValue().size(); k++) {
						content.append("<data>" + eee.getValue().get(k)
								+ "</data>");
					}
					content.append("</rankC>");
				}

				content.append("</" + ee.getKey() + ">");
			}
			content.append("</rank>");
			} 
			content.append("</contents>");
			java.util.Date date1 = new java.util.Date();
			long l1 = date1.getTime();

			// 在这里将查询出来的数据放到session中 为了word生成
			User user = (User) session.getAttribute("user");
			Object[] objs = new Object[6];
			objs[0] = alarmSta;
			objs[1] = obj;
			objs[2] = highAlarm;
			objs[3] = fieldName;
			objs[4] = content;
			objs[5] = index;
			StorageData.sotrage(user.getU_id() + "_ewbsa", objs);
//			session.setAttribute(user.getU_id() + "_ewbsa", objs);

			if (flag) { // 这里是为了判断如果是word生成 就不再返回xml数据
				response.getWriter().print(content.toString());
			}
			}
		} catch (ErrorException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return SUCCESS;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public String getIndex() {
		return index;
	}

	public void setIndex(String index) {
		this.index = index;
	}

	public void setAlarmSta(AlarmSta alarmSta) {
		this.alarmSta = alarmSta;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {

		this.request = request;
	}

	@Override
	public void setHttpServletResponse(HttpServletResponse response) {
		// TODO Auto-generated method stub
		this.response = response;
	}

}
