package cn.jxqt.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.web.access.factory.DaoAdviceFactory;
import org.web.access.factory.OperateServiceExecuteAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.dao.core.support.Page;
import org.web.framework.Constant;
import org.web.framework.action.AutoWire;
import org.web.service.OperateServiceExecuteAdvice;
import org.web.service.QueryService;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.action.interceptor.Helper;
import cn.jxqt.po.User;
import cn.jxqt.service.AuditService;
import cn.jxqt.service.DemandService;
import cn.jxqt.util.PageUtil;

public class AuditAction extends ActionSupport implements
		HttpServletRequestAware {
	private static final String viewName = "Audit";
	private HttpServletRequest request = null;
	@AutoWire
	private List<Object> list;

	@Override
	public String execute() throws Exception {

		User user = (User) request.getSession().getAttribute("user");
		String operate = request.getParameter("operate");
		QueryService qs = new QueryService(viewName);
		List<Object> allList = DemandService.getAllList(viewName + user.getU_id());
		Page page = PageUtil.getPage(request, QueryAction.SHOW_NUM);
		if(allList != null) {
			page.setCount(allList.size());
		}
		if(operate.equalsIgnoreCase("delete")){
			OperateServiceExecuteAdvice service = OperateServiceExecuteAdviceFactory
					.getService(viewName);
			service.execute(Helper.getMorePageList(request, list,allList, viewName, Constant.DELETE, page),
					Constant.DELETE);
			this.addMessage("恭喜您删除成功！");
			
		}
		this.allowSendReuqstParam();
//		DaoAdvice sd = DaoAdviceFactory.getDao("Audit");
		this.setProperties("u_id", user.getU_id());
		if(operate.equalsIgnoreCase("deleteAll")){
			AuditService auditDelete = new AuditService();
			auditDelete.deleteAll(viewName, null);
			this.addMessage("恭喜您全部删除成功！");
		}
		List<Object> list = qs.getResult(null, page);
		request.setAttribute("list", list);
		request.setAttribute("page", page);
		return SUCCESS;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

}
