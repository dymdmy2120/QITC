package cn.jxqt.action;

import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.web.exception.ErrorException;

import cn.jxqt.service.backups.AbstractBackupsService;
import cn.jxqt.service.backups.AutoBackupsService;
import cn.jxqt.util.dynamo.DataBaseBackups;
import cn.jxqt.util.dynamo.FileBackups;
import cn.jxqt.util.dynamo.IBackups;

/**
 * @author ASUS 定时备份
 * 
 */
public class TimerBackupsAction implements ServletContextListener {
	private static final long PERIOD_DAY = 1000 * 60 *60*24;

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void contextInitialized(ServletContextEvent event) {
		// TODO Auto-generated method stub
		String prjPath = event.getServletContext().getRealPath("/");
		String bakDaBaseName = "data.sql";
		// 在服务器下要备份的文件夹名
		String bakFileName = "JxQtData";
		// 备份之前压缩后的名字
		String zipName = bakFileName + ".zip";
		// 存放备份数据库文件
		String databaseFile = prjPath + bakFileName + "/" + bakDaBaseName;

		// 存放备份的数据库文件和上传的文档文件路径
		String sourcePath = prjPath + bakFileName + "/";

		// 存放压缩后zip文件(包括数据库文件和上传文件)的路径
		String destPath = prjPath + "auto/" + zipName;

		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 30);
		calendar.set(Calendar.SECOND, 0);
		Date date = calendar.getTime();

		IBackups autoDataBaseBackups = new DataBaseBackups();
		IBackups autoFileBackups = new FileBackups();
		AbstractBackupsService abstractDataBase = new AutoBackupsService(
				autoDataBaseBackups);

		AbstractBackupsService abstractFile = new AutoBackupsService(
				autoFileBackups);
		// 设置初始值
		((AutoBackupsService) abstractDataBase)
				.setBackupsTime(date, PERIOD_DAY);
		((AutoBackupsService) abstractFile).setBackupsTime(date, PERIOD_DAY);

		try {
			abstractDataBase.handleBack("", databaseFile);
			abstractFile.handleBack(sourcePath, destPath);
			
		} catch (ErrorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
