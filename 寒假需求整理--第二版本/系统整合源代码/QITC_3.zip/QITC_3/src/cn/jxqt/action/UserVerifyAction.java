package cn.jxqt.action;

import javax.servlet.http.HttpServletRequest;

import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

public class UserVerifyAction extends ActionSupport implements
HttpServletRequestAware {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		
	}

}
