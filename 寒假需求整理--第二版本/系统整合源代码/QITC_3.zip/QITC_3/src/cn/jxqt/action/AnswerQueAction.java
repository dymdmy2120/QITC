package cn.jxqt.action;


import javax.servlet.http.HttpServletRequest;

import org.web.framework.action.AutoWire;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.po.User;
import cn.jxqt.service.AnswerQueService;
import cn.jxqt.service.ForgetPasService;

public class AnswerQueAction extends ActionSupport implements
										HttpServletRequestAware {
	private HttpServletRequest request;
	@AutoWire
	private User user;

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		AnswerQueService answerQueService = new AnswerQueService();
		try{
			this.request.setAttribute("user",answerQueService.answerQue(user));
			return "success";
		}catch(Exception e){
			User tempUser = new User();
			tempUser.setU_id(user.getU_id());
			ForgetPasService forgetPasSer = new ForgetPasService();
			this.request.setAttribute("user",forgetPasSer.retrievePassword(tempUser));
			this.addMessage(e.getMessage());
			return "failed";
		}
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

}
