package cn.jxqt.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.service.QueryService;
import org.web.servlet.ActionSupport;
import org.web.servlet.FilePathAware;
import org.web.servlet.HttpServletRequestAware;

import cn.jxqt.util.StatisticalAnalysisUtil;
import cn.jxqt.vo.Hazards;

public class HazardsAction extends ActionSupport implements
HttpServletRequestAware,FilePathAware{
	private HttpServletRequest request;
	@Override
	public String execute() throws BeanInitializationException {
		// TODO Auto-generated method stub
		String exceptionInfo = null;
		QueryService query = new QueryService("Hazards");
		List<Object> list = null;
		try {
		 list=query.getResult(null, null);
		} catch (ErrorException e) {
			// TODO Auto-generated catch block
			exceptionInfo = e.getMessage();
			return "error";
		} catch (BeanInitializationException e) {
			// TODO Auto-generated catch block
			exceptionInfo = e.getMessage();
			return "error";
		}
		List<String> bname = new ArrayList<String>();
		for(int i=0;i<list.size();i++){
			Hazards hazards = (Hazards) list.get(i);
			bname.add(hazards.getB_name());
		}
		List<String> bname1=StatisticalAnalysisUtil.removeDuplicateWithOrder(bname);
		request.setAttribute("list", bname1);
		request.setAttribute("exceptionInfo", exceptionInfo);
		return "successful";
	}

	@Override
	public void setFilePath(Map<String, String> filePath) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
		
	}

}
