package cn.jxqt.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.servlet.ActionSupport;
import org.web.servlet.FilePathAware;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.HttpServletResponseAware;

import cn.jxqt.service.restore.AbstractRestoreService;
import cn.jxqt.service.restore.HandRestoresService;
import cn.jxqt.util.HandleFileUtil;
import cn.jxqt.util.dynamo.DataBaseRestore;
import cn.jxqt.util.dynamo.FileRestore;
import cn.jxqt.util.dynamo.IRestore;

public class RestoreAction extends ActionSupport implements
		HttpServletRequestAware, HttpServletResponseAware, FilePathAware {
	private HttpServletRequest request;
	private HttpServletResponse response;
	private Map<String,String> filePath = null;
	@Override
	public String execute() throws BeanInitializationException {
		// TODO Auto-generated method stub
		// 如果为get方法提交则 是属于对系统的备份否则为还原
		List<String> error = new ArrayList<String>();
		boolean flag = false;
		String prjPath = request.getRealPath("/");
		// 系统还原
		// 上传文件
		try { 
			String fileName = "";
			if (filePath != null)
				fileName = filePath.get("restore");

			// 还原数据库文件的名字
			String reDaBaseName = "data.sql";
			// 解压后在服务器下要恢复的数据库文件的文件夹名
			String bakFileName = "JxQtData";

			// 存放恢复后的数据库文件的路径
			String sourcePath = prjPath + bakFileName + "/" + reDaBaseName;

			IRestore restoreDataBase = new DataBaseRestore();
			IRestore restoreFile = new FileRestore();
			// 数据库文件的还原 手动还原
			AbstractRestoreService abstractRestDataBase = new HandRestoresService(
					restoreDataBase); 
			// 对上传文档文件的还原 手动还原
			AbstractRestoreService abstractRestFile = new HandRestoresService(
					restoreFile);
			abstractRestFile.handleRestore(fileName, prjPath);
			abstractRestDataBase.handleRestore(sourcePath,"");
            
			//还原后把上传上的还原zip文件删除
			HandleFileUtil.deleteFile(fileName);
			//把备份的数据库文件删除
			HandleFileUtil.deleteFile(sourcePath);
			this.setResponseMessage("恢复成功");
			request.setAttribute("message",this.getResponseMessage() );

		} catch (ErrorException e) {
			this.setResponseMessage(e.getMessage());
			request.setAttribute("message", this.getResponseMessage()); // 错误返回消息
		} catch (Exception e) {
			this.setResponseMessage(e.getMessage());
			request.setAttribute("message", this.getResponseMessage()); // 错误返回消息
		}
		
		return "rest";

	}


	@Override
	public void setHttpServletResponse(HttpServletResponse response) {
		// TODO Auto-generated method stub
		this.response = response;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}

	@Override
	public void setFilePath(Map<String, String> filePath) {
		// TODO Auto-generated method stub
		this.filePath = filePath;
	}

}
