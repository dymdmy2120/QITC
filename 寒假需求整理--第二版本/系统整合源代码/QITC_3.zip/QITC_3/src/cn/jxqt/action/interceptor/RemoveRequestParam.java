package cn.jxqt.action.interceptor;

import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * 移除不需要的request的参数
 * 
 * @author mastery
 * @Time 2014-11-21 上午11:36:25
 * 
 */
public class RemoveRequestParam extends HttpServletRequestWrapper {
	private Map<String, String[]> params;

	public RemoveRequestParam(HttpServletRequest originalRequest) {
		super(originalRequest);
		params = originalRequest.getParameterMap();
		Method method = null;
		try {
			method = params.getClass().getDeclaredMethod("setLocked",
					boolean.class);
			if (method != null) {
				method.invoke(params, false);
			}
		} catch (Exception e) {
			throw new AssertionError(e);
		}
		Enumeration<String> en = originalRequest.getParameterNames();
		while (en.hasMoreElements()) {
			String paramName = en.nextElement().toString();
			if (paramName.equalsIgnoreCase("category_id")
					|| paramName.equalsIgnoreCase("lab_id")) {
				continue;
			}
			params.remove(paramName);
		}
	}

	public Map<String, String[]> getParameterMap() {
		return params;
	}

	public String getParameter(String name) {
		if (params.get(name) != null) {
			return params.get(name)[0];
		}
		return null;
	}

	public Enumeration<String> getParameterNames() {
		return Collections.enumeration(params.keySet());
	}

	public String[] getParameterValues(String name) {
		return params.get(name);
	}
}
