package cn.jxqt.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.web.access.factory.OperateServiceExecuteAdviceFactory;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.framework.action.AutoWire;
import org.web.service.OperateServiceExecuteAdvice;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;

public class BackOperateAction extends ActionSupport implements
		HttpServletRequestAware {

	private static HttpServletRequest request;
	public String viewName;
	private String operate;
	private static String endTime; // 需要查询的截止时间
	@AutoWire
	private List<Object> list;

	@Override
	public String execute() throws BeanInitializationException {
		viewName = this.action.substring(0, this.action.lastIndexOf("."));
		operate = this.action.substring(this.action.lastIndexOf(".") + 1);
		endTime = request.getParameter("createtime1");
		try {
			this.executeOperate(list, viewName, operate);
			this.addMessage("操作成功");
		} catch (ErrorException e) {
			e.printStackTrace();
			this.addMessage(e.getMessage());
			return "add";
		}
		request.setAttribute("list", list);
		if ("add".equals(operate)) {
			return "add";
		} else {
			return "other";
		}
	}

	public void executeOperate(List<Object> list, String viewName,
			String operate) throws ErrorException, BeanInitializationException {
		OperateServiceExecuteAdvice service = OperateServiceExecuteAdviceFactory
				.getService(viewName);
		service.execute(list, operate);
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	public static HttpServletRequest getRequest() {
		return request;
	}

	public static String getEndTime() {
		return endTime;
	}

}
