package cn.jxqt.action;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.HttpServletResponseAware;

import cn.jxqt.service.deteanaly.GetValueService;


public class GetValueAction extends ActionSupport implements
		HttpServletRequestAware, HttpServletResponseAware {

	private HttpServletRequest request;

	private HttpServletResponse response;

	@Override
	public String execute() throws BeanInitializationException {
		response.setContentType("text/xml;charset=utf-8");
		response.setHeader("Cache-Control", "no-cache");
		String param = request.getParameter("param");
		GetValueService getValueService = new GetValueService();
		List<Map<String, String>> lists = null;
		try {
			lists = getValueService.getVlues(param);
		} catch (ErrorException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		StringBuffer content = new StringBuffer("");
		content.append("<?xml version=\"1.0\"   encoding=\"UTF-8\" ?>");
		content.append("<contents>");
		for (int i = 0; i < lists.size(); i++) {
			Map<String, String> map = lists.get(i);
			Set<String> set = map.keySet();
			Iterator<String> it = set.iterator();
			while (it.hasNext()) {
				String tempStr = it.next();
				boolean flag = tempStr.equals("noticeCount");
				if (i == 0 && !flag) {
					content.append("<fields>");
					content.append("<field value='" + tempStr + "'>"
							+ map.get(tempStr) + "</field>");
					content.append("</fields>");
				}
			}
		}
		content.append("</contents>");
		System.out.println(content);
		try {
			response.getWriter().print(content.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "successful";
	}


	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setHttpServletResponse(HttpServletResponse response) {
		this.response = response;
	}

}
