package cn.jxqt.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web.exception.ActionExecuteException;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.framework.action.AutoWire;
import org.web.service.QueryService;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.HttpServletResponseAware;

import cn.jxqt.po.User;
import cn.jxqt.util.StorageData;
import cn.jxqt.util.TimeUtil;
import cn.jxqt.vo.WorkLoad;

public class AjaxQueryAction extends ActionSupport implements
		HttpServletRequestAware, HttpServletResponseAware {

	private HttpServletRequest request;
	private HttpServletResponse response;
	private List<Object> list;
	private static String[] times = null;
	private String viewName;
	@AutoWire
	private Object vo;

	@SuppressWarnings("deprecation")
	@Override
	public String execute() throws ActionExecuteException {

		viewName = this.action.substring(0, this.action.indexOf(".")) ;

		if ("WorkLoad".equals(viewName)) { // 如果是workload 就得到查询的时间点
			String compareTime = request.getParameter("compareTime"); // 比较的时间点

			String beginTime = compareTime + "-" + "00"; // 查询开始时间

			String[] time = compareTime.split("-");
			// 查询截止时间
			String endTime = compareTime
					+ "-"
					+ (1 + TimeUtil.getDaysByYearMonth(
							Integer.parseInt(time[0]),
							Integer.parseInt(time[1])));

			times = new String[2];
			times[0] = beginTime;
			times[1] = endTime;
			StorageData.sotrage("qitc", times);
		}

		try {
			this.executeQuery(viewName, vo);
		} catch (ErrorException e) {
			this.setResponseMessage(e.getMessage());
			return ERROR;
		}
		if ("WorkLoad".equals(viewName)) {
			WorkLoadAjax();
		} else {
			Userajax();
		}
		return SUCCESS;
	}

	public void executeQuery(String viewName, Object bean)
			throws ErrorException, BeanInitializationException {
		QueryService service = new QueryService(viewName);
		list = service.getResult(bean, null);
	}

	private void Userajax() {
		try {
			PrintWriter out = response.getWriter();
			if (list.size() <= 0 || list == null) { // 不存在
				out.print(true);
			} else {
				out.print(false); // 存在
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void WorkLoadAjax() {
		try {
			response.setContentType("text/xml;charset=utf-8");
			PrintWriter out = response.getWriter();
			StringBuilder rtn = new StringBuilder();
			rtn.append("<datas>");

			WorkLoad workload = (WorkLoad) list.get(0);
			if (workload != null) {
				rtn.append(
						"<yearWorkSize>" + workload.getYearWorkSize()
								+ "</yearWorkSize>").append(
						"<monthWorkSize>" + workload.getMonthWorkSize()
								+ "</monthWorkSize>");
			}
			out.print(rtn.append("</datas>"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setHttpServletResponse(HttpServletResponse response) {
		this.response = response;
	}

	public static String[] getTimes() {
		return times;
	}
}
