package cn.jxqt.action.interceptor;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.web.dao.core.support.Page;
import org.web.exception.ActionExecuteException;
import org.web.framework.Constant;
import org.web.service.QueryService;

import tool.mastery.core.StringUtil;
import tool.mastery.log.Logger;
import cn.jxqt.action.QueryAction;
import cn.jxqt.service.DemandService;

public final class Helper {
	
	public static Logger LOG = Logger.getLogger(Helper.class);
	
	/**
	 * 当是删除时,得到需要的list
	 * @param request
	 * @param list
	 * @param allList
	 * @param viewName
	 * @param operate
	 * @param page
	 * @return
	 * @throws ActionExecuteException
	 */
	public static <T> List<T> getMorePageList(HttpServletRequest request,
			List<T> list, List<T> allList, String viewName,
			String operate, Page page) throws ActionExecuteException {
		if (!Constant.DELETE.equalsIgnoreCase(operate)) {
			LOG.debug("already commit list data to verify is list :" + list);
			return list;
		}
		// 当存在delete参数时则代表是删除全部！
		if (request.getParameter("delete") != null) {
			LOG.debug("already commit list data to verify is allList:" + allList);
			return allList;
		}
		List<T> retList = new ArrayList<T>();
		String begin = request.getParameter("begin");
		if (!StringUtil.StringIsNull(begin)) {
			int intBegin = Integer.parseInt(begin);
			int intEnd = Integer.parseInt(request.getParameter("end"));
			int end = 0;
			// 如果是最后一页
			if (intEnd == page.getLastPage()) {
				end = allList.size();
			} else {
				end = intEnd * QueryAction.SHOW_NUM;
			}
			for (int i = (intBegin - 1) * QueryAction.SHOW_NUM; i < end; i++) {
				retList.add(allList.get(i));
			}
		} else {
			for (int i = 0; i < list.size(); i++) {
				T bean = list.get(i);
				for (T obj : allList) {
					if (bean.equals(obj)) {
						retList.add(obj);
						break;
					}
				}
			}
		}
		LOG.debug("already commit list data to verify is retList :" + retList);
		return retList;
	}
	
	public static List<Object> getAllList(String category_id, ServletRequest request, String viewName) {
		List<Object> allList = null;
		String lab_id = request.getParameter("lab_id");
		if (category_id == null && lab_id == null) {
			allList = QueryService.getCurrentMementoList(viewName);
			if(allList == null && viewName.equalsIgnoreCase("laboratory")){
				allList = DemandService.getAllList(viewName);
			}
		} else if (category_id != null) {
			allList = DemandService.getAllList(viewName + category_id);
		} else if (lab_id != null) {
			if(viewName.equalsIgnoreCase("laboratory")) {
				allList = DemandService.getAllList(viewName);
			}else {
				allList = DemandService.getAllList(viewName + lab_id);
			}
		}
		return allList;
	}
}
