package cn.jxqt.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web.dao.core.support.Page;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.framework.action.AutoWire;
import org.web.service.QueryService;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.HttpServletResponseAware;

import cn.jxqt.po.User;
import cn.jxqt.util.StorageData;
import cn.jxqt.vo.UserInfo;
import cn.jxqt.vo.WorkLoad;

public class BackQueryAction extends ActionSupport implements
		HttpServletRequestAware, HttpServletResponseAware {

	private HttpServletRequest request;

	private List<Object> list = null;
	private String viewName;
	private static String[] times;
	@AutoWire
	private WorkLoad workload;
	@AutoWire
	private UserInfo userinfo;

	@Override
	public String execute() throws BeanInitializationException {

		viewName = this.action;
		Object vo = null;

		if (viewName.equals("WorkLoad") && workload != null
				&& workload.getU_name() != null) { // 进入workLoad查询
			vo = workload;
			// 构建查询的时间 这里是查询全年的
			String year = request.getParameter("compareTime");
			if (year != null) {
				String endTime = year + "-" + "12" + "-31";
				String beginTime = year + "-" + "1" + "-00";
				times = new String[2];
				times[0] = beginTime;
				times[1] = endTime;
				User user = (User) this.request.getSession().getAttribute(
						"user");
				StorageData.sotrage("qitc", times);
			}
		}
		if (viewName.equals("UserInfo") && userinfo != null
				&& userinfo.getU_name() != null) { // 进入userinfo查询
			vo = userinfo;
		}
		try {
			this.executeQuery(viewName, vo);
		} catch (ErrorException e) {
			e.printStackTrace();
			this.setResponseMessage(e.getMessage());
			return ERROR;
		}
		return SUCCESS;
	}

	public void executeQuery(String viewName, Object bean)
			throws ErrorException, BeanInitializationException {
		QueryService service = new QueryService(viewName);
		Page page = getPage();
		list = service.getResult(bean, page);
		this.request.setAttribute("list", list);
		this.request.setAttribute("page", page);
	}

	private Page getPage() {
		Page page = new Page();
		// 获得从页面中传递过来的数据
		String firstIndex = this.request.getParameter("firstIndex");
		if (firstIndex != null) {
			int temp = Integer.parseInt(firstIndex);
			page.setPage(temp);
		}
		return page;
	}

	@Override
	public void setHttpServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	@Override
	public void setHttpServletResponse(HttpServletResponse response) {
	}

	public static String[] getTimes() {
		return times;
	}
}
