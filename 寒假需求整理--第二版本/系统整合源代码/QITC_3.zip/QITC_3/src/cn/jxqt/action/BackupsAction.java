package cn.jxqt.action;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web.exception.ErrorException;
import org.web.servlet.ActionSupport;
import org.web.servlet.HttpServletRequestAware;
import org.web.servlet.HttpServletResponseAware;

import cn.jxqt.service.backups.AbstractBackupsService;
import cn.jxqt.service.backups.HandBackupsService;
import cn.jxqt.util.HandleFileUtil;
import cn.jxqt.util.dynamo.DataBaseBackups;
import cn.jxqt.util.dynamo.FileBackups;
import cn.jxqt.util.dynamo.IBackups;

public class BackupsAction extends ActionSupport implements
		HttpServletRequestAware, HttpServletResponseAware {
	private HttpServletRequest request;
	private HttpServletResponse response;

	@Override
	public String execute() {
		// 如果为get方法提交则 是属于对系统的备份否则为还原

		// 所得到是该项目的根目录
		String prjPath = request.getRealPath("/");
		FileInputStream in = null;
		ServletOutputStream out = null;
		try {
			// bakReoreService = new BakReoreService("backups", prjPath, null);
			// bakReoreService.executeOperate();
			// 备份数据库文件的名字
			String bakDaBaseName = "data.sql";
			// 在服务器下要备份的文件夹名
			String bakFileName = "JxQtData";
			// 备份之前压缩后的名字
			String zipName = bakFileName + ".zip";
			// 存放备份数据库文件
			String databaseFile = prjPath + bakFileName + "/" + bakDaBaseName;

			// 存放备份的数据库文件和上传的文档文件路径
			String sourcePath = prjPath + bakFileName + "/";

			// 存放压缩后zip文件(包括数据库文件和上传文件)的路径
			String destPath = prjPath + "temp/" + zipName;

			IBackups backupsDataBase = new DataBaseBackups();
			IBackups backupsFile = new FileBackups();
			// 对数据库文件备份 (手动)
			AbstractBackupsService abstractBakDataBase = new HandBackupsService(
					backupsDataBase);
			// 对上传文档文件的备份 (手动)
			AbstractBackupsService abstractBakFile = new HandBackupsService(
					backupsFile);
			abstractBakDataBase.handleBack("", databaseFile);
			abstractBakFile.handleBack(sourcePath, destPath);

			response.setContentType("application/x-msdownload");
			response.setHeader("Content-Disposition", "attachment; filename="
					+ zipName);
			in = new FileInputStream(destPath);
			out = response.getOutputStream();
			out.flush();
			int aRead = 0;
			while ((aRead = in.read()) != -1 & in != null) {
				out.write(aRead);
			}
			out.flush();
			//压缩完了文件后把sourcePath文件中的名为backupsName文件删除
			//例如压缩完了文件后把JxQtData文件中的data.sql文件删除
			HandleFileUtil.deleteFile(sourcePath+bakDaBaseName);
		} catch (ErrorException e) {
			
			this.setResponseMessage(e.getMessage());
			request.setAttribute("message", this.getResponseMessage()); // 错误返回消息
			
		} catch (Exception e) {
			
			request.setAttribute("message", "没找到文件,备份失败"); // 错误返回消息

		} finally {
			if (in != null && out != null) {
				try {
					in.close();
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					request.setAttribute("message", "没找到文件,备份失败"); // 错误返回消息
				}

			}

		}
		return "back";

	}


	@Override
	public void setHttpServletRequest(HttpServletRequest request) {

		this.request = request;
	}

	@Override
	public void setHttpServletResponse(HttpServletResponse response) {
		// TODO Auto-generated method stub
		this.response = response;
	}




}
