package cn.jxqt.dao.file;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.cache.framework.Cache;
import org.cache.framework.LRUCache;

import tool.mastery.log.Logger;
import cn.jxqt.vo.FileVo;

public class FileSystem {

	private static final Logger LOG = Logger.getLogger(FileSystem.class);
	
	private static final Cache<String, FileSystem> fileMap = new LRUCache<String, FileSystem>(
			5, 1000 * 300 , new FileSystemInterceptor());

	private String fileName;

	private ListStatus ls;

	private boolean reading;

	private boolean writing;

	private FileSystem() {
		reading = false;
		writing = false;
	}

	
	/** 
	
	* @Title: fecth 
	
	* @Description: 抓取到当前的list 
	
	* @param @return   
	
	* @return List<FileVo>    返回类型 
	
	* @throws 
	
	*/ 
	List<FileVo> fecth() {
		return this.ls.getList();
	}
	
	/**
	 * 将对应的对象集合加载至内存
	 * 
	 * @param name
	 * @throws IOException
	 */
	public static FileSystem load(String filePath) throws IOException {
		// 如果内存中尚不存在此集合
		FileObjectManager fom = null;
		try {
			if (fileMap.get(filePath) == null) {
				FileSystem fs = new FileSystem();
				fom = FileObjectManager.open(filePath);
				fs.fileName = fom.getFileName();
				List<FileVo> list = fom.read();
				if (list == null) {
					list = new ArrayList<FileVo>();
				}
				ListStatus ls = new ListStatus(list);
				fs.ls = ls;
				fileMap.put(filePath, fs);
			}
		} finally {
			// 再将此流关闭
			if (fom != null) {
				fom.close();
			}
		}
		return fileMap.get(filePath);
	}

	public String getFileName() {
		return fileName;
	}

	public synchronized List<FileVo> getList() throws IOException {
		startRead();
		List<FileVo> list = ls.getList();
		if (!ls.isOrdered()) {
			Collections.sort(list);
			ls.setOrdered(true);
		}
		return ls.getList();
	}

	public synchronized int getSize() throws IOException {
		startRead();
		int size = ls.getList().size();
		return size;
	}

	public synchronized void save(List<FileVo> fileVos) throws IOException {
		startWrite();
		ls.getList().addAll(fileVos);
	}

	public synchronized FileVo query(FileVo fileVo) throws IOException {
		if (fileVo == null) {
			return null;
		}
		startRead();
		List<FileVo> fileVos = ls.getList();
		int index = getIndex(fileVos, fileVo);
		if (index != -1) {
			return fileVos.get(index);
		}
		return null;
	}

	private int getIndex(List<FileVo> list, FileVo fileVo) {
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).equals(fileVo)) {
				return i;
			}
		}
		return -1;
		/*
		 * return BinarySearch.search(list, list.size(), fileVo.getFileVoId());
		 */
	}

	public synchronized void save(FileVo fileVo) throws IOException {
		startWrite();
		ls.getList().add(fileVo);
	}

	public boolean contains(FileVo fileVo) throws IOException {
		List<FileVo> list = ls.getList();
		if (list == null || list.size() == 0) {
			return false;
		}
		if (getIndex(list, fileVo) != -1) {
			return true;
		}
		return false;
	}

	public synchronized List<FileVo> delete(List<FileVo> list)
			throws IOException {
		startRead();
		// 获得此文件中所有的对象集合
		List<FileVo> cloneList = new ArrayList<FileVo>();
		List<FileVo> objectList = ls.getList();
		if(list.size() == objectList.size()) {
			ls.setList(cloneList);
			return objectList;
		}
		List<FileVo> retList = new ArrayList<FileVo>();
		cloneList.addAll(objectList);
		int index = -1;
		// 删除对应的对象
		for (int i = 0; i < list.size(); i++) {
			if ((index = this.getIndex(objectList, list.get(i))) != -1) {
				// 添加得到的数据
				retList.add(objectList.get(index));
				cloneList.remove(index);
			}
		}
		ls.setList(cloneList);
		// 将list状态转变为可读
		return retList;
	}

	private synchronized void startRead() throws IOException {
		while (writing) {
			this.waiting();
		}
		reading = true;
	}

	private synchronized void startWrite() throws IOException {
		while (reading) {
			this.waiting();
		}
		this.writing = true;
	}

	public synchronized void stopRead() {
		this.notify();
		reading = false;
	}

	public synchronized void stopWrite() {
		this.writing = false;
		this.notify();
	}

	private void waiting() throws IOException {
		try {
			this.wait();
		} catch (InterruptedException e) {
			throw new IOException("系统繁忙，请稍后！");
		}
	}

}
