package cn.jxqt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.web.dao.annotation.AnnotationUtil;
import org.web.dao.core.support.AbstractVoDaoAdvice;
import org.web.dao.core.support.VoResolve;
import org.web.exception.DBException;

import cn.jxqt.po.Dete;
import cn.jxqt.po.Laboratory;
import cn.jxqt.po.Mbr;
import cn.jxqt.po.Product;
import cn.jxqt.po.Sta;
import cn.jxqt.vo.LabApt;
import cn.jxqt.vo.LabTest;

public class LabTestDao extends AbstractVoDaoAdvice {

	public void save(Object labTestObject) throws DBException {
		// DAO.setAutoCommit(false);
		Object[] poValue = this.initVoResolveToGetPoValue(labTestObject);
		Map<String, Object> valueMaps = new HashMap<String, Object>();

		int index = 0;

		int i = 0;
		for (Object po : poValue) {
			if (!(po instanceof Dete) && !(po instanceof Sta)) {
				try {
					List<Object> list = DAO.query(po.getClass(), po, null,
							false);
					if (list.size() == 0) {
						DAO.save(po);
						list = DAO.query(po.getClass(), po, null, false);
						System.out.println(list);
					}
					Object bean = list.get(0);
					String primaryKeyName = AnnotationUtil.ANNOTAION_UTIL
							.getPrimaryKey(po.getClass())[0];
					valueMaps.put(primaryKeyName, bean);
				} catch (Exception e) {
					throw new DBException("插入Mbr Product PO对象失败！");
				}
			} else if (po instanceof Sta) {
				System.out.println("conme on ==>" + po);

				try {
					List<Object> bean = DAO.query(po.getClass(), po, null,
							false);
					// System.out.println(bean.size() + " bean");
					if (bean.size() == 0) {
						DAO.save(po);
						bean = DAO.query(po.getClass(), po, null, false);
						//System.out.println(bean);
					}
					Object beanValue = bean.get(0);

					String primaryKeyName = AnnotationUtil.ANNOTAION_UTIL
							.getPrimaryKey(po.getClass())[0];
					valueMaps.put(primaryKeyName, beanValue);
				} catch (Exception e) {
					throw new DBException(
							"LabTestDao类中Mbr Product PO对象 设置外键对象失败！");
				}
			} else if (po instanceof Dete) {
				index = i;
			}
			i++;
		}

		for (Iterator<String> it = valueMaps.keySet().iterator(); it.hasNext();) {
			String primaryKeyName = it.next();
			try {
				PropertyUtils.setProperty(poValue[index], primaryKeyName,
						PropertyUtils.getProperty(
								valueMaps.get(primaryKeyName), primaryKeyName));
			} catch (Exception e) {
				e.printStackTrace();
				// throw new DBException("LabTestDao类中Dete PO对象 设置外键对象失败！");
			}
			System.out.println(poValue[index]);
		}
		try {
			Integer sta_id = (Integer) PropertyUtils.getProperty(
					poValue[index], "sta_id");
			if (sta_id == null || sta_id == 1) {
			} else {
				// List<Object> detes = DAO.query(poValue[index].getClass(),
				// poValue[index], null, false);
				// if (detes.size() == 0) {
				DAO.save(poValue[index]);
				/*
				 * } else { throw new DBException("数据库中存在此条数据！"); }
				 */
			}
		} catch (Exception e) {
			throw new DBException("LabTestDao类中Dete PO对象 插入失败！");
		}
		// DAO.commit();
	}
	
	@Override
	public void delete(Object entity) throws DBException {
		Object[] poValue = this.initVoResolveToGetPoValue(entity);
		System.out.println("delete :k ");
		for (Object po : poValue) {
			if (po instanceof Dete) {
				DAO.delete(po);
				break;
			}
		}
	}
	
	@Override
	protected VoResolve buildVoResolve() {
		Class<?>[] allPo = new Class<?>[] { Dete.class, Mbr.class,
				Product.class, Sta.class,Laboratory.class};
		Class<?> voClass = LabTest.class;
		return helpAdvice.getVoResolve(allPo, voClass, null);

	}

	@Override
	protected boolean operateCondition(Object obj) {
		// TODO Auto-generated method stub
		return false;
	}

}
