package cn.jxqt.dao;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.web.dao.annotation.AnnotationUtil;
import org.web.dao.core.support.AbstractVoDaoAdvice;
import org.web.dao.core.support.VoResolve;
import org.web.exception.DBException;
import org.web.service.VoProcessor;

import tool.mastery.core.BeanUtil;

import cn.jxqt.po.Mbr;
import cn.jxqt.po.Product;
import cn.jxqt.po.Slink;
import cn.jxqt.po.Sta;
import cn.jxqt.vo.Standard;

public class StandardDao extends AbstractVoDaoAdvice {

	@Override
	protected VoResolve buildVoResolve() {
		// TODO Auto-generated method stub
		Class<?>[] allPo = new Class<?>[] { Mbr.class, Product.class,
				Slink.class, Sta.class };
		Class<?> voClass = Standard.class;
		Class<?>[] needPoObjectClass = new Class<?>[] { Mbr.class,
				Product.class, Slink.class, Sta.class };
		return helpAdvice.getVoResolve(allPo, voClass, needPoObjectClass);
	}

	@Override
	public void delete(Object entity) throws DBException {
		Object[] poValue = this.initVoResolveToGetPoValue(entity);
		
		 Object standard = DAO.get(poValue[3]);
		 if(standard != null) {
			 
			 DAO.delete(poValue[3]);
		 }
		                    
		 
	}

	@Override
	public void update(Object entity) throws DBException {
		Object[] poValue = this.initVoResolveToGetPoValue(entity);
		Map<String, Object> valueMaps = new HashMap<String, Object>();
		Slink oldSlink = (Slink) poValue[2];
		
		for (int i = 0; i < poValue.length ; i ++) {
			Object po = poValue[i];
			if (po instanceof Sta) {
				DAO.update(po);
			} else if ( po instanceof Product) {
				// 将主键存下来！
				String primaryKeyName = AnnotationUtil.ANNOTAION_UTIL
						.getPrimaryKey(po.getClass())[0];
				
				try {
					if(PropertyUtils.getProperty(po, "p_name") == null) {
						DAO.delete(oldSlink);
						return ;
					}
					PropertyUtils.setProperty(po, primaryKeyName, null);
				} catch (Exception e) {
					LOG.debug(e);
				}
				Object bean = DAO.saveBeforeQuery(po);
				valueMaps.put(primaryKeyName, bean);
			}
		}
		Slink newSlink = (Slink) oldSlink.clone();
		boolean flag = false;
		for (Iterator<String> it = valueMaps.keySet().iterator(); it.hasNext();) {
			String primaryKeyName = it.next();
			try {
				if (PropertyUtils.getProperty(oldSlink, primaryKeyName) == null) {
					
					flag = true;
					BeanUtil.setProperty(oldSlink,
							valueMaps.get(primaryKeyName), primaryKeyName);
				}
				BeanUtil.setProperty(newSlink, valueMaps.get(primaryKeyName),
						primaryKeyName);
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println(" and oldSlink is : " + oldSlink);
		System.out.println(" and newSlink is : " + newSlink);
		if (DAO.get(newSlink) == null) {
			if (!flag) {
				DAO.delete(oldSlink);
			} else {
				DAO.save(oldSlink);
			}
		} else {
			DAO.update(oldSlink);
		}

	}

	@Override
	public void save(Object entity) throws DBException {
		// TODO Auto-generated method stub
		Object[] poValue = this.initVoResolveToGetPoValue(entity);

		Sta sta = (Sta) poValue[3];
		Slink slink = (Slink) poValue[2];
		Product product = (Product) poValue[1];
		Mbr mbr = (Mbr) poValue[0];

		if (DAO.query(sta.getClass(), sta, null, false).size() == 0) {
			DAO.save(sta);
		} else {
			DAO.update(sta);
		}

		List listSta = DAO.query(sta.getClass(), sta, null, false);
		List listProduct = DAO.query(Product.class, product, null, false);
		List listMbr = DAO.query(Mbr.class, mbr, null, false);
		if (listProduct.size() == 0)
			DAO.save(product);

		if (listMbr.size() == 0)
			DAO.save(mbr);

		slink.setP_id(((Product) DAO.query(Product.class, product, null, false)
				.get(0)).getP_id());
		slink.setMbr_id(((Mbr) DAO.query(Mbr.class, mbr, null, false).get(0))
				.getMbr_id());
		slink.setSta_id(((Sta) listSta.get(0)).getSta_id());

		DAO.save(poValue[2]);
	}

	@Override
	protected boolean operateCondition(Object obj) {
		// TODO Auto-generated method stub
		return false;
	}

}
