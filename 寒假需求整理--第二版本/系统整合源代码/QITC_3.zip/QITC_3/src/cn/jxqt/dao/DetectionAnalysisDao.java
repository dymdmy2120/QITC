package cn.jxqt.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.web.dao.core.support.AbstractVoDaoAdvice;
import org.web.dao.core.support.VoResolve;
import org.web.exception.DBException;

import cn.jxqt.po.Alarm;
import cn.jxqt.po.Bounds;
import cn.jxqt.po.Laboratory;
import cn.jxqt.service.deteanaly.support.DetectionAnalysisDBQuery;
import cn.jxqt.service.deteanaly.support.SqlConstant;
import cn.jxqt.vo.OperDetectAbility;

/**
 * 专门对于信息统计分析的Dao类
 * 
 * @author antsmarth
 * 
 */
public class DetectionAnalysisDao extends AbstractVoDaoAdvice {

	private DetectionAnalysisDao() {

	}

	private static class DetectionAnalysisDaoHelper {
		final static DetectionAnalysisDao deteDao = new DetectionAnalysisDao();
	}

	public static DetectionAnalysisDao getInstance() {
		return DetectionAnalysisDaoHelper.deteDao;
	}

	/**
	 * 通过传入的信息分析的查询条件得到Map<String,List<OperDetectAbility>>集合
	 * 
	 * @param beaninfo
	 * 
	 * @param voClass
	 * @param boundsInfo
	 * @param searchInfo
	 * @return
	 * @throws DBException
	 */
	public Map<String, List<OperDetectAbility>> getDetectAnalysisInfo(
			Class<?> voClass, List<List<Object>> beaninfo,
			Map<String, List<String>> boundsInfo, String searchInfo,
			Map<String, String> chooseUnionTable) throws DBException {

		String chooseFromSql = SqlConstant.chooseSql(chooseUnionTable);

		// 定义全局数据存储对象,HashMap集合,key为String是限量库名称,value为List<OperDetectAbility>是查询的数据对象集合
		Map<String, List<OperDetectAbility>> resultMaps = new HashMap<String, List<OperDetectAbility>>();
		// 拿到统一的SQL语句,连接表的语句
		StringBuilder firstSearchSql = getSqlForDetectAnalysis(voClass,
				beaninfo, boundsInfo, searchInfo, chooseFromSql);

		for (Entry<String, List<String>> boundEntry : boundsInfo.entrySet()) {
			// 为查询对象组装加上限量库名称
			List<List<Object>> conditionInfo = getBeanInfoOfaddBoundName(
					boundEntry.getKey(), beaninfo);

			List<List<OperDetectAbility>> results = new ArrayList<List<OperDetectAbility>>(
					conditionInfo.size());

			List<OperDetectAbility> resultsData = new ArrayList<OperDetectAbility>();
			// 遍历查询条件,来查询数据
			for (List<Object> searchInfo1 : conditionInfo) {

				StringBuffer finalSql = new StringBuffer(firstSearchSql);

				String[] searchCondition = searchInfo.split(",");
				List<String> listTypes = new ArrayList<String>();
				int count = 0;
				StringBuilder searchSql = new StringBuilder(" ");
				for (Object searchValue : searchInfo1) {
					if (searchValue == null || searchValue.equals("")) {

					} else {
						// System.out.println("searchValue : " + searchValue);
						if(chooseUnionTable.get("limit") == null){
							if(count == searchInfo1.size() - 1){
								searchInfo1.set(searchInfo1.size() - 1, null);
								continue;
							}
						}
						searchSql.append(searchCondition[count]).append(
								" = ? and ");
						listTypes.add("String");
					}
					count++;
				}
				List<OperDetectAbility> list = null;

				
				
				if(!searchSql.toString().equals(" ")){
					finalSql.append(searchSql.substring(0,
							searchSql.lastIndexOf("and")));
					System.out.println(finalSql.toString());
					list = DetectionAnalysisDBQuery
							.getInstance().query(finalSql.toString(),
									removeNullValueForParames(searchInfo1),
									listTypes, OperDetectAbility.class);
				}else{
					String finalSqlS = finalSql.substring(0, finalSql.lastIndexOf("and"));
					System.out.println(finalSqlS);
					list = DetectionAnalysisDBQuery
							.getInstance().query(finalSqlS,
									removeNullValueForParames(searchInfo1),
									listTypes, OperDetectAbility.class);
				}
				
				/*
				 * List<OperDetectAbility> list = daoOptemplate .getInstance()
				 * .query(finalSql.toString(), EntitySearchHelper
				 * .removeNullValueForParames(searchInfo1), listTypes,
				 * voElement, voClass);
				 */
				
				// System.out.println("list size L : " + list.size());
				// List<Object> list = getResult(finalSql.toString(), voClass);
				results.add(list);

			}

			for (List<OperDetectAbility> vo : results) {
				if (vo == null || vo.size() == 0) {
					// System.out.println("111");
				} else {
					for (OperDetectAbility bean : vo)
						resultsData.add(bean);
				}
			}
			
			resultMaps.put(boundEntry.getKey(), resultsData);
		}
		// for (Entry<String, List<OperDetectAbility>> entry : resultMaps
		// .entrySet()) {
		// for (OperDetectAbility oper : entry.getValue()) {
		// System.out.println("hazards : " + entry.getKey() + " ::: "
		// + oper.toString());
		// }
		// }
		return resultMaps;
	}

	private StringBuilder getSqlForDetectAnalysis(Class<?> voClass,
			List<List<Object>> beaninfo, Map<String, List<String>> boundsInfo,
			String searchInfo, String chooseFromSql) {
		StringBuilder conditionSqlInfo = new StringBuilder();

		for (Entry<String, List<String>> boundEntry : boundsInfo.entrySet()) {

			conditionSqlInfo.append(SqlConstant.firstSqlInfo);
			StringBuffer selectFieldNames = new StringBuffer();

			for (String selectInfo : boundEntry.getValue()) {
				if (selectInfo.equals("noticeCount")) {
					continue;
				}
				selectFieldNames.append(selectInfo).append(",");
			}

			conditionSqlInfo.append(selectFieldNames.substring(0,
					selectFieldNames.lastIndexOf(",")));
			conditionSqlInfo.append(chooseFromSql);

			break;
		}

		return conditionSqlInfo;
	}

	public List<String> getAlarmSubQuality() {

		List<Alarm> alarms = null;
		String querySql = "select reject_des from t_alarm";

		alarms = DetectionAnalysisDBQuery.getInstance().query(querySql,
				Alarm.class);

		List<String> alarmNames = new ArrayList<String>(alarms.size());

		for (Alarm alarm : alarms) {
			if (null == alarm.getReject_des()
					|| alarm.getReject_des().equals("")) {
				continue;
			}
			alarmNames.add(alarm.getReject_des());
		}

		return alarmNames;
	}

	public List<String> getLabNames() {
		List<Laboratory> labs = null;
		String querySql = "select lab_name from t_laboratory";

		labs = DetectionAnalysisDBQuery.getInstance().query(querySql,
				Laboratory.class);
		List<String> labNames = new ArrayList<String>(labs.size());
		for (Laboratory lab : labs) {
			if (null == lab.getLab_name() || lab.getLab_name().equals("")) {
				continue;
			}
			labNames.add(lab.getLab_name());
		}

		return labNames;
	}

	public List<String> getBoundName() {
		List<Bounds> bounds = null;

		String querySql = "select b_name from t_bounds";

		bounds = DetectionAnalysisDBQuery.getInstance().query(querySql,
				Bounds.class);

		List<String> boundNames = new ArrayList<String>();

		for (Bounds bound : bounds) {
			boundNames.add(bound.getB_name());
		}

		return boundNames;

	}

	/**
	 * 根据限量库的名称，来进行组成查询条件的值的集合
	 * 
	 * @param boundsName
	 *            ： 限量库名称集合
	 * @param beaninfo
	 *            ：原先查询条件的值的集合
	 * @return conditionInfo : 新组成的查询条件值的集合
	 */
	private static List<List<Object>> getBeanInfoOfaddBoundName(
			Object boundName, List<List<Object>> beaninfo) {
		List<List<Object>> conditionInfo = new ArrayList<List<Object>>(
				beaninfo.size());

		for (List<Object> bean : beaninfo) {

			List<Object> rbean = new ArrayList<Object>(bean);
			rbean.add(boundName);
			conditionInfo.add(rbean);
		}

		return conditionInfo;
	}

	/**
	 * 对传入的List<Object>集合中，空值进行remove，返回新的集合
	 * 
	 * @param parames
	 * @return List<Object> relList
	 */
	public List<Object> removeNullValueForParames(List<Object> parames) {
		List<Object> relList = new ArrayList<Object>();
		for (Object parame : parames) {
			if (parame == null || "".equals(parame)) {

			} else {
				relList.add(parame);
			}

		}
		return relList;
	}

	@Override
	protected VoResolve buildVoResolve() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected boolean operateCondition(Object obj) {
		// TODO Auto-generated method stub
		return false;
	}

}
