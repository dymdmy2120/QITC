package cn.jxqt.dao.file;

import java.util.List;

import cn.jxqt.vo.FileVo;

class ListStatus {
	
	/**
	 *  加载进内存时的时间
	 */
	private long time;
	
	private List<FileVo> list;
	
	private boolean isOrdered;

	public ListStatus(List<FileVo> list) {
		this.time = System.currentTimeMillis();
		this.list = list;
		isOrdered = false;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public List<FileVo> getList() {
		return list;
	}

	public void setList(List<FileVo> list) {
		this.list = list;
	}

	public boolean isOrdered() {
		return isOrdered;
	}

	public void setOrdered(boolean isOrdered) {
		this.isOrdered = isOrdered;
	}
	
}
