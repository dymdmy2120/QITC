package cn.jxqt.dao.file;

import java.util.List;

import cn.jxqt.vo.FileVo;

class BinarySearch {

	public static int search(List<FileVo> list , int len , int value) {
		int low = 0;
		int high = len - 1;
		while(low <= high) {
			int middle = (low + high) / 2;
			if(list.get(middle).getFileVoId() == value) {
				return middle;
			}else if(list.get(middle).getFileVoId() > value) {
				low = middle + 1;
			}else {
				high = middle - 1;
			}
		}
		return -1;
	}
	
}	
