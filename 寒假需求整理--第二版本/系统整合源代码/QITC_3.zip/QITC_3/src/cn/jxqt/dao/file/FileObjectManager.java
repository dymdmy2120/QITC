package cn.jxqt.dao.file;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.web.framework.action.support.InitOperations;

import cn.jxqt.vo.FileVo;

/**
 * 文件对象管理类
 * 
 * @author mastery
 * 
 */
public class FileObjectManager {
	public static String ProjectPath = InitOperations.ServicesPath;

	private String filePath;

	private String fileName;

	private ObjectOutputStream oos;
	private ObjectInputStream ois;

	public FileObjectManager() {
	}

	private FileObjectManager(String filePath) {
		init(filePath);
	}

	public String getFileName() {
		return fileName;
	}

	private void init(String fileName) {
		this.fileName = fileName;
		// 对文件名分割，当分割长度为1时，则代表输入的是没有后缀的文件名，若输入的有后缀，则将后缀替换为txt
		String[] splitPath = fileName.split("\\.");
		if (splitPath.length == 1) {
			fileName += ".txt";
		} else {
			fileName = splitPath[0] + ".txt";
		}
		this.filePath = ProjectPath + "JxQtData\\FileObject\\" + fileName;
		try {
			open();
		} catch (IOException e) {
		}
	}
	
	/**
	 * 打开该流的输入输出
	 * 
	 * @throws IOException
	 */
	public static FileObjectManager open(String filePath) throws IOException {
		return new FileObjectManager(filePath);
	}

	/**
	 * 
	 * @param filePath
	 *            文件路径
	 * @param fileVoList
	 *            对象集合
	 * @param flag
	 *            是否追加添加
	 * @throws IOException
	 */
	public synchronized void save(List<FileVo> fileVoList, boolean flag)
			throws IOException {
		// 改变输出文件的流的具体方式
		changeObjectOutputStream(flag);

		for (int i = 0; i < fileVoList.size(); i++) {
			save0(fileVoList.get(i));
		}
	}

	/**
	 * 将对象输出到对应的流中
	 * 
	 * @param fileVo
	 */
	private synchronized void save0(FileVo fileVo) {
		try {
			oos.writeObject(fileVo);
			oos.flush();
		} catch (IOException e1) {
		}
	}

	/**
	 * 保存单个FileVo对象
	 * 
	 * @param filePath
	 * @param fileVo
	 * @param flag
	 *            // 允许对象添加到之后而不是覆盖
	 * @throws IOException
	 */
	public synchronized void save(FileVo fileVo, boolean flag)
			throws IOException {
		// 改变输出文件的流的具体方式
		changeObjectOutputStream(flag);

		save0(fileVo);
	}

	public synchronized FileVo readAObject() throws IOException {
		FileVo fileVo = null;
		try {
			fileVo = (FileVo) ois.readObject();
		} catch (ClassNotFoundException e) {
			throw new IOException("读取对象出错");
		}
		return fileVo;
	}

	/**
	 * 读出对应文件中的所有对象
	 * 
	 * @param filePath
	 * @return
	 * @throws IOException
	 */
	public synchronized List<FileVo> read() throws IOException {
		List<FileVo> objectList = new ArrayList<FileVo>();
		FileVo fileVo = null;
		try {
			if (ois == null) {
				return objectList;
			}
			while ((fileVo = (FileVo) ois.readObject()) != null) {
				objectList.add(fileVo);
			}
		} catch (EOFException e) {
		} catch (IOException e1) {
			// throw e1;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return objectList;
	}

	/**
	 * 查询此FileVo对象是否存在
	 * 
	 * @param filePath
	 * @param fileVo
	 * @return
	 * @throws IOException
	 */
	public synchronized FileVo query(FileVo fileVo) throws IOException {
		List<FileVo> list = this.read();
		int index = this.query0(list, fileVo);
		if (index != -1) {
			return list.get(index);
		}
		return null;
	}

	public synchronized boolean contains(FileVo fileVo) throws IOException {
		List<FileVo> list = this.read();
		int index = this.query0(list, fileVo);
		if (index != -1) {
			return true;
		}
		return false;
	}

	/**
	 * 查询此对象在此集合中的下标
	 * 
	 * @param list
	 * @param fileVo
	 * @return
	 */
	private synchronized int query0(List<FileVo> list, FileVo fileVo) {
		for (int i = 0; i < list.size(); i++) {
			if (fileVo.equals(list.get(i))) {
				// System.out.println(fileVo.getVo().getUsername());
				return i;
			}
		}
		return -1;
	}

	/**
	 * 删除一个存放了FileVo对象的list集合中的所有对象,并且返回对应数据库中的对象集合
	 * 
	 * @param filePath
	 * @param list
	 * @return
	 * @throws IOException
	 */
	public synchronized List<FileVo> delete(List<FileVo> list)
			throws IOException {
		// 获得此文件中所有的对象集合
		List<FileVo> newList = new ArrayList<FileVo>();
		List<FileVo> objectList = this.read();
		int index = -1;
		boolean flag = false;
		// 删除对应的对象
		for (int i = 0; i < list.size(); i++) {
			if ((index = this.query0(objectList, list.get(i))) != -1) {
				flag = true;
				// 添加得到的数据
				newList.add(objectList.get(index));
				objectList.remove(index);
			}
		}
		// 再对对象进行重新保存在文件中
		if (flag) {
			try {
				this.save(objectList, false);
			} catch (IOException e) {
				throw e;
			}
		}
		return newList;
	}

	/**
	 * 获取对象文件的输入流
	 * 
	 * @param filePath
	 * @return
	 * @throws IOException
	 */
	private synchronized ObjectInputStream getObjectInputStream() {
		File file = new File(filePath);
		if (!file.exists()) {
			File directions = new File(file.getAbsolutePath().substring(0,
					file.getAbsolutePath().lastIndexOf("\\")));
			directions.mkdirs();
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		try {
			InputStream is = new FileInputStream(file);
			ois = new ObjectInputStream(is);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
		}
		return ois;
	}

	/**
	 * 获取对象文件的输出流
	 * 
	 * @param filePath
	 * @param flag
	 * @return
	 * @throws IOException
	 */
	private synchronized ObjectOutputStream getObjectOutputStream(boolean flag)
			throws IOException {
		File file = new File(filePath);
		OutputStream os = new FileOutputStream(file, flag);
		try {
			oos = FileObjectOutputStream.newInstance(file, os);
		} catch (IOException e) {
			throw new IOException("获取文件输出流错误！");
		}
		return oos;
	}

	/**
	 * 若flag传入为false时则认为需要改变文件的输出方式，为不追加的添加数据
	 * 
	 * @param flag
	 * @throws IOException
	 */
	private void changeObjectOutputStream(boolean flag) throws IOException {
		// flag不为true时，则需要的是不追加的流对象
		if (!flag) {
			if (oos != null) {
				oos.close();
			}
			oos = getObjectOutputStream(flag);
		}
	}

	public void close() throws IOException {
		if (ois != null) {
			ois.close();
			ois = null;
		}
		if (oos != null) {
			oos.close();
			oos = null;
		}
	}

	/**
	 * 打开该流的输入输出
	 * @throws IOException
	 */
	public void open() throws IOException {
		ois = getObjectInputStream();
		oos = getObjectOutputStream(true);
	}

	/**
	 * 判断流是否打开 
	 * @return
	 * @throws IOException
	 */
	public boolean isOpen() throws IOException{
		if(ois == null && oos == null) {
			return true;
		}
		return false;
	}
	
}
