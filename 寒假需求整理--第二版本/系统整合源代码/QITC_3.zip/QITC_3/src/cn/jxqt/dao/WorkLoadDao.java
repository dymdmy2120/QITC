package cn.jxqt.dao;

import org.web.dao.core.support.AbstractVoDaoAdvice;
import org.web.dao.core.support.VoResolve;
import org.web.service.VoProcessor;

import cn.jxqt.adapter.WorkLoadProcessor;
import cn.jxqt.po.Laboratory;
import cn.jxqt.po.Operate;
import cn.jxqt.po.User;
import cn.jxqt.vo.WorkLoad;

/**
 * 注：此dao须配置在beans.xml当中
 * 
 * @author mastery
 * @Time 2015-3-17 下午6:57:12
 * 
 */
public class WorkLoadDao extends AbstractVoDaoAdvice {

	public VoProcessor getVoProcessor() {

		return new WorkLoadProcessor();
	}

	@Override
	protected VoResolve buildVoResolve() {
		Class<?>[] allPo = new Class<?>[] { User.class, Operate.class };
		Class<?> voClass = WorkLoad.class;
		Class<?>[] needPoObjectClass = new Class<?>[] { User.class,
				Operate.class };
		return helpAdvice.getVoResolve(allPo, voClass, needPoObjectClass);
	}

	@Override
	protected boolean operateCondition(Object obj) {
		// 注意这里只是为了演示作用才写的，实际情况实际运用
		if (obj instanceof Laboratory) {
			return false;
		}
		return true;
	}

}
