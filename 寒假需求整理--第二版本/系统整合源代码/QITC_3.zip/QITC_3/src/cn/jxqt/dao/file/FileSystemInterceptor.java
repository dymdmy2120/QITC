package cn.jxqt.dao.file;

import java.io.IOException;

import org.cache.interceptor.Interceptor;
import org.cache.interceptor.InterceptorException;

public class FileSystemInterceptor implements Interceptor {

	@Override
	public <V> void proceed(V value) throws InterceptorException {
		if (value instanceof FileSystem) {
			FileObjectManager fom = null;
			FileSystem fs = (FileSystem) value;
			try {
				fom = FileObjectManager.open(fs.getFileName());
				fom.save(fs.fecth(), false);
			} catch (IOException e) {
				throw new InterceptorException(e);
			} finally {
				// 再将此流关闭
				if (fom != null) {
					try {
						fom.close();
					} catch (IOException e) {
						throw new InterceptorException(e);
					}
				}
			}

		}
	}

}
