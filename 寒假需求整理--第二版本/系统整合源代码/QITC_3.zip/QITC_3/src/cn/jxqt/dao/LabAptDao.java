package cn.jxqt.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.web.dao.annotation.AnnotationUtil;
import org.web.dao.core.support.AbstractVoDaoAdvice;
import org.web.dao.core.support.VoResolve;
import org.web.exception.DBException;
import org.web.util.ExceptionUtil;

import tool.mastery.core.BeanUtil;
import tool.mastery.log.Logger;
import cn.jxqt.po.Apt;
import cn.jxqt.po.Laboratory;
import cn.jxqt.po.Mbr;
import cn.jxqt.po.Product;
import cn.jxqt.po.Sta;
import cn.jxqt.vo.LabApt;

public class LabAptDao extends AbstractVoDaoAdvice {

	public static final Logger LOG = Logger.getLogger(LabAptDao.class);

	@Override
	public void save(Object entity) throws DBException {
		Map<String, Object> valueMaps = new HashMap<String, Object>();
		Object[] poValue = this.initVoResolveToGetPoValue(entity);
		int index = 0;
		for (int i = 0; i < poValue.length; i++) {
			if (poValue[i] instanceof Sta || poValue[i] instanceof Mbr
					|| poValue[i] instanceof Product) {
				if (poValue[i] instanceof Sta) {
					Sta sta = (Sta) poValue[i];
					sta.setCategory_id(null);
				}
				Object bean = DAO.saveBeforeQuery(poValue[i]);
				String primaryKeyName = AnnotationUtil.ANNOTAION_UTIL
						.getPrimaryKey(poValue[i].getClass())[0];
				valueMaps.put(primaryKeyName, bean);
			} else if (poValue[i] instanceof Apt) {
				index = i;
			}
		}
		for (Iterator<String> it = valueMaps.keySet().iterator(); it.hasNext();) {
			String primaryKeyName = it.next();
			try {
				BeanUtil.setProperty(poValue[index],
						valueMaps.get(primaryKeyName), primaryKeyName);
			} catch (Exception e) {
				LOG.debug(ExceptionUtil.formatStackTrace(e), e);
				throw new DBException(e.getMessage(), e);
			}
		}

		DAO.save(poValue[index]);
		// 提交
	}

	@Override
	public void update(Object entity) throws DBException {
		Map<String, Object> valueMaps = new HashMap<String, Object>();
		Object[] poValue = this.initVoResolveToGetPoValue(entity);
		Apt apt = null;
		for (Object po : poValue) {
			if (po instanceof Sta || po instanceof Mbr || po instanceof Product) {
				String primaryKeyName = AnnotationUtil.ANNOTAION_UTIL
						.getPrimaryKey(po.getClass())[0];
				try {
					PropertyUtils.setProperty(po, primaryKeyName, null);
				} catch (Exception e) {
					LOG.debug(e);
					throw new DBException(e);
				}
				Object bean = DAO.saveBeforeQuery(po);
				valueMaps.put(primaryKeyName, bean);
			} else if (po instanceof Apt) {
				apt = (Apt) po;
			}
		}
		for (Iterator<String> it = valueMaps.keySet().iterator(); it.hasNext();) {
			String primaryKeyName = it.next();
			try {
				BeanUtil.setProperty(apt, valueMaps.get(primaryKeyName),
						primaryKeyName);
			} catch (Exception e) {
				LOG.debug(ExceptionUtil.formatStackTrace(e), e);
				throw new DBException(e.getMessage(), e);
			}
		}
		DAO.update(apt);
	}

	@Override
	public void delete(Object entity) throws DBException {
		Object[] poValue = this.initVoResolveToGetPoValue(entity);
		for (Object po : poValue) {
			if (po instanceof Apt) {
				DAO.delete(po);
				break;
			}
		}
	}

	@Override
	protected VoResolve buildVoResolve() {
		Class<?>[] allPo = new Class<?>[] { Laboratory.class, Product.class,
				Mbr.class, Sta.class, Apt.class };
		Class<?> voClass = LabApt.class;
		Class<?>[] needObjectClass = new Class<?>[] { Product.class, Mbr.class,
				Sta.class, Apt.class };
		return helpAdvice.getVoResolve(allPo, voClass, needObjectClass);
	}

	@Override
	protected boolean operateCondition(Object obj) {
		// TODO Auto-generated method stub
		return false;
	}

}
