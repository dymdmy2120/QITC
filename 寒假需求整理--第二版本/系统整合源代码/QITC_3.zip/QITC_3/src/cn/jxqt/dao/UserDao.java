package cn.jxqt.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.web.dao.core.support.AbstractVoDaoAdvice;
import org.web.dao.core.support.VoResolve;
import org.web.exception.DBException;
import org.web.service.VoProcessor;
import org.web.util.ExceptionUtil;

import tool.mastery.db.DBUtil;
import cn.jxqt.adapter.UserInfoProcessor;
import cn.jxqt.po.Power;
import cn.jxqt.po.User;
import cn.jxqt.po.UserPower;
import cn.jxqt.vo.UserInfo;

public class UserDao extends AbstractVoDaoAdvice {
	private boolean temp = true;

	public VoProcessor getVoProcessor() {

		return new UserInfoProcessor();
	}

	@Override
	protected VoResolve buildVoResolve() {
		Class<?>[] allPo = new Class<?>[] { User.class, Power.class,
				UserPower.class, };
		Class<?> voClass = UserInfo.class;
		Class<?>[] needPoObjectClass = new Class<?>[] { UserPower.class,
				User.class, };
		return helpAdvice.getVoResolve(allPo, voClass, needPoObjectClass);
	}

	@Override
	public void save(Object entity) throws DBException {
		DAO.save(entity);
	}

	@Override
	public void update(Object entity) throws DBException {
		DAO.update(entity);

	}

	@Override
	public void delete(Object entity) throws DBException {
		DAO.delete(entity);
	}

	@Override
	protected boolean operateCondition(Object obj) {
		return true;
	}

}
