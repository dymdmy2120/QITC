package cn.jxqt.service;


import java.util.List;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.exception.ErrorException;

import cn.jxqt.po.User;

public class AnswerQueService {
	public AnswerQueService(){
	}
	
	public User answerQue(User user) throws ErrorException{
		User retUser = null;
		try{
			retUser = this.findUser(user);
		}catch(ErrorException e){
			User tempUser = new User();
			tempUser.setU_id(user.getU_id());
			User tempResultUser = this.findUser(tempUser);
			StringBuffer errorInfo = new StringBuffer("密保问题");
			if(!tempResultUser.getAnswer1().equals(user.getAnswer1())){
				errorInfo.append("1、");
			}
			if(!tempResultUser.getAnswer2().equals(user.getAnswer2())){
				errorInfo.append("2、");
			}
			if(!tempResultUser.getAnswer3().equals(user.getAnswer3())){
				errorInfo.append("3、");
			}
			errorInfo.append("回答错误！");
			throw new ErrorException(errorInfo.toString());
		}
		return retUser;
	}
	
	private  User findUser(User user) throws ErrorException{
		User retUser = null;
		try {
			DaoAdvice sd = DaoAdviceFactory.getDao("User");
			List<Object> list = sd.query(User.class, user, null, false);
			if(list.size()> 0){
				retUser = (User)list.get(0);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
		if(retUser == null){
			throw new ErrorException("系统不存在该用户！");
		}
		return retUser;
	}
}
