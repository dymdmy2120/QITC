package cn.jxqt.service.login;

public class HandlerControler {
	
	private Handler rootHandler;
	private Handler lastHandler;
	public void add(Handler handler) {
		if(rootHandler == null) {
			rootHandler = handler;
			lastHandler = handler;
		}else{
			lastHandler.setNextHandler(handler);
			lastHandler = handler;
		}
	}
	
	public Handler getRootHandler() {
		return this.rootHandler;
	}
}
