package cn.jxqt.service.login;

import java.util.List;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;

import cn.jxqt.po.User;

public abstract class Handler {
	private Handler nextHandler;
	
	public void setNextHandler(Handler nextHandler){
		this.nextHandler = nextHandler;
	}
	public Handler getNextHandler(){
		return this.nextHandler;
	}
	protected  User findUser(User user) throws ErrorException{
		User retUser = null;
		try {
			DaoAdvice sd = DaoAdviceFactory.getDao("User");
			List<Object> list = sd.query(User.class, user, null, false);
			if(list.size()> 0){
				retUser = (User)list.get(0);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("============登录查询用户失败============");
		}
		if(retUser == null){
			throw new ErrorException("系统不存在该用户！");
		}
		return retUser;
	}
	protected void updateUser(User user) throws ErrorException {
		try {
			DaoAdvice sd = DaoAdviceFactory.getDao("User");
			sd.update(user);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new ErrorException("操作失败！");
		}
	}
	public abstract User respone(String operation,User user) throws ErrorException  , BeanInitializationException;
}
