package cn.jxqt.service.Detection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import cn.jxqt.vo.statisticsalaysis.ComparisonInfor;
import cn.jxqt.vo.statisticsalaysis.ComparisonResult;

/**
 * 
 * @author Administrator
 * 农药残留检出水平与最大残留限量标准对比分析情况关键字
 */
public class ComparisonResultAnaylse {
	
	
	public static List<ComparisonResult> getComparisonResult(
			List<ComparisonInfor> list, String[] selects) {
		List<ComparisonResult> resultList = new ArrayList<ComparisonResult>();
		ComparisonResult result = new ComparisonResult();
		ComparisonResult cResult = null;
		int selectSize = selects.length;
		for (int i = 0; i < selectSize; i++) {
			Iterator<ComparisonInfor> it = list.iterator();
			cResult = (ComparisonResult) result.clone();
			Map<String, String> map = new HashMap<String, String>();
			while (it.hasNext()) {
				ComparisonInfor infor = it.next();
				List<String> inforList = infor.getList();
				for (int j = 0; j < inforList.size(); j++) {
					if (inforList.get(i * 2 + 1).equals("是")) {
						cResult.setSum(cResult.getSum() + 1);
						map.put(infor.getPro_name(), infor.getMbr_cname());
						break;
					}
				}

			}
			cResult.setMap(map);
			cResult.setSta(selects[i]);
			cResult.setProper((1 - ((double) cResult.getSum() / list.size())) * 100);
			resultList.add(cResult);

		}

		return resultList;
	}
}
