package cn.jxqt.service.restore;

import org.web.exception.ErrorException;

import cn.jxqt.util.dynamo.IRestore;


public class HandRestoresService extends AbstractRestoreService {

	public HandRestoresService() {
		super();
	}
	public HandRestoresService(IRestore handle) {
		// TODO Auto-generated constructor stub
		super(handle);
	}

	@Override
	public boolean handleRestore(String sourcePath, String destPath) throws ErrorException {
		// TODO Auto-generated method stub
		return super.handleRestore(sourcePath, destPath);
	}

	

}
