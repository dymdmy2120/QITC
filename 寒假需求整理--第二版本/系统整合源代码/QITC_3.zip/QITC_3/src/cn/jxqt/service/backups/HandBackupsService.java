package cn.jxqt.service.backups;

import org.web.exception.ErrorException;

import cn.jxqt.util.dynamo.IBackups;


public class HandBackupsService extends AbstractBackupsService {

	public HandBackupsService() {
		super();
	}
	public HandBackupsService(IBackups handle) {
		super(handle);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean handleBack(String sourcePath, String destPath) throws ErrorException {
		// TODO Auto-generated method stub
		return this.hand(sourcePath, destPath);
	}

	

}
