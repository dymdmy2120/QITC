package cn.jxqt.service;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import org.web.exception.ErrorException;

import cn.jxqt.util.InsertMiddle;
import cn.jxqt.util.JavaMailUtil;

/**
 * 负责密码重置的一系列操作
 * 
 * @author Administrator
 * 
 */
public class MailSendService {

	public static Boolean SendEmail(HttpServletRequest req, String email,
			String psword, String u_id) throws ErrorException {

		String path = req.getRealPath("/") + "/WEB-INF/classes/"; // 邮件模板存放地址

		// 构建邮件中的超链接(网址+登陆页面)
		StringBuffer url = req.getRequestURL();
		String urlPath = new String(url);
		urlPath = urlPath.substring(0, urlPath.lastIndexOf("/"));
		Boolean bool = true;
		try {
			InsertMiddle.InsertPsword("template.txt", psword, path, urlPath,
					u_id); // 将密码和模板地址 已经邮件中超
		} catch (Exception e1) {
			bool = false;
			new RuntimeException("发送邮件，读取邮件模板失败");
			e1.printStackTrace();
		}
		try {
			JavaMailUtil.SetMail(email, null, path + "PaswordUpdateMail.txt");
			String file = path + "PaswordUpdateMail.txt";
			File f = new File(file);
			if (f.exists()) { // 删除临时文件。
				f.delete();
			} else {
				new RuntimeException("文件不存在");
			}
		} catch (Exception e) {
			bool = false;
			// new RuntimeException("");
			e.printStackTrace();
			throw new ErrorException("密码重置，邮件发送操作失败");

		}
		return bool;
	}
}
