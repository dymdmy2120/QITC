package cn.jxqt.service;

import java.util.List;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.dao.core.support.Page;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.service.QueryService;

import cn.jxqt.po.Admin;
import cn.jxqt.po.User;
import cn.jxqt.po.UserPower;
import cn.jxqt.util.MD5Util;
/**
 * 用户登录
 * @author Administrator
 *
 */
public class LoginService {
	public LoginService(){
		
	}
	/**
	 * action调用执行登录操作
	 * @param user
	 * @param operation
	 * @return
	 * @throws ErrorException
	 */
	public User performLogin(User user,String operation)throws ErrorException {
		if(user == null){
			throw new ErrorException("请登录！");
		}
		if(user.getPassword() != null){
			user.setPassword(MD5Util.EncoderByMd5(user.getPassword()));
		}
		if(operation.equals("userLogin")){
			return this.userLogin(user);
		}
		if(operation.equals("adminLogin")){
			return this.adminLogin(user);
		}
		throw new ErrorException("系统错误！");
	}
	/**
	 * 用户登录
	 * @param user
	 * @return
	 * @throws ErrorException
	 */
	private User userLogin(User user) throws ErrorException {
		String errorInfo = null;
		try {
			DaoAdvice sd = DaoAdviceFactory.getDao("User");
			List<Object> list = sd.query(User.class, user, null, false);
			if(list.size()> 0){
				
				
				return (User)list.get(0);
			}else{
				errorInfo = "用户名或密码错误！";
			}
		} catch (Exception e) {
		}
		throw new ErrorException(errorInfo);
	}
	/**
	 * 管理员登录
	 * @param user
	 * @return
	 * @throws ErrorException
	 */
	private User adminLogin(User user) throws ErrorException {
		Admin admin = new Admin();
		admin.setU_id(user.getU_id());
		if(user.getPassword() != null){
			admin.setPassword(user.getPassword());
		}
		Admin retAdmin = this.findAdmin(admin);
		
		if(retAdmin == null){
			throw new ErrorException("用户名或密码错误！");
		}
		User retUser = new User();
		retUser.setU_id(retAdmin.getU_id());
		retUser.setPassword(retUser.getPassword());
		return retUser;
	}
	/**
	 * 查找管理员
	 * @param admin
	 * @return
	 */
	private Admin findAdmin(Admin admin){
		Admin retAdmin = null;
		try {
			DaoAdvice sd = DaoAdviceFactory.getDao("Admin");
			List<Object> list = sd.query(Admin.class, admin, null, false);
			if(list.size()> 0){
				retAdmin = (Admin)list.get(0);
			}
		} catch (Exception e) {
		}
		return retAdmin;
	}
	
	public boolean checHasVerify(User user){
		if(checkPower(user)){
			System.out.println("he has verify power!");
			VerifyDataGeter vdg = new VerifyDataGeter();
			return VerifyDataGeter.checkVerifyData(vdg.getResult());
		}
		return false;
	}
	private boolean checkPower(User user){
		UserPower userpower = new UserPower();
		userpower.setU_id(user.getU_id());
		
		QueryService service = new QueryService("UserPower");
		List list = null;
		try {
			Page page = new Page();
			page.setMaxSize(20);
			 list = service.getResult(userpower,page);
		} catch (BeanInitializationException e) {
			e.printStackTrace();
		} catch (ErrorException e) {
			e.printStackTrace();
		}
		UserPower up = null;
		for(Object obj : list ) {
			up = (UserPower)obj;
			if("2".equals(up.getP_id())){
				return true;
			}
		}
		return false;
	}
}
