package cn.jxqt.service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder.In;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.exception.BeanInitializationException;
import org.web.exception.DBException;
import org.web.exception.ErrorException;
import org.web.service.QueryService;

import cn.jxqt.po.Alarm;
import cn.jxqt.util.JFreeChartUtil;
import cn.jxqt.vo.AlarmSta;
import cn.jxqt.vo.Standard;

public class EWBSAService {
	/**
	 * 得到一个存放照片路径的字符数组
	 * 
	 * @param session
	 *            从控制层传来一个session
	 * @param staticNam
	 *            一个以逗号隔开的对象属性字段 countries,mechanism 表示要得到通报国家和发布的机构
	 * @return
	 * @return String[] 返回一个生成的柱状图的路径字符数组
	 */
	private String staticNam;
	private AlarmSta alarmSta;
	// 预警通报某分类或全部分类数据
	private List<Object> objRet = null;
	// 某一全年的数据
	List<Object> objWhYear = null;

	private EWBSAService() {
	}

	// 单例模式
	private static class EWBSAServiceHodler {

		private static EWBSAService instance = new EWBSAService();
	}

	public static EWBSAService getInstance() {
		return EWBSAServiceHodler.instance;
	}

	/**
	 * 函数功能说明
	 * 
	 * @param alarmSta
	 *            是一个接受前台用户输入的数据 包括 通报的时间 ，通报的地区 ，通报的月份范围和通报的标题
	 * @return
	 * @throws ErrorException
	 * @return String[]
	 */
	public String[] getPicNamArry(String staticNam, HttpSession session,
			String index1, Object alarmSta) throws ErrorException {

		String[] staticNamList = staticNam.split(","); // 拆分字段
		this.staticNam = staticNam;
		this.alarmSta = (AlarmSta) alarmSta;
		objRet = getStatData();
		// 当数据位空的时 直接返回不再做进一步的处理
		if (objRet.size() == 0)
			return null;
		// 得到某一全年的数据
		objWhYear = getWholYe();
		if (objWhYear.size() == 0)
			return null;

		List<Map<String, Integer>> mapArray = getMap(staticNam, objWhYear);
		// java.util.Date date1 = new java.util.Date();
		// Long time1 = date1.getTime();
		// picIndex为要显示的柱状图序号
		int picIndex = Integer.valueOf(index1).intValue();
		String[] picNamArry = new String[mapArray.size()];
		String[] titleArray = { "食品发布了产品通报的通报国情况", "各月份通报情况", "通报的产品分类",
				"不合格项目分类", "不合格项目", "食品通报采取的主要措施" };
		// 遍历mapArray集合
		for (int i = 0; i <= (picIndex / 6) * 5; i++) {
			int index = picIndex;
			if (picIndex == 6) // 当显示全部时
				index = i;
			Map<String, Integer> map = mapArray.get(i);
			String district = ((AlarmSta) alarmSta).getDistrict();
			if ("0".equals(district)) {

				district = "境外";
			} else if ("1".equals(district)) {

				district = "境内";
			} else {
				district = "境内外";
			}

			picNamArry[i] = JFreeChartUtil.getPicName(map, district
					+ titleArray[index], session);
		}
		// java.util.Date date2 = new java.util.Date();
		// Long time2 = date2.getTime();
		// System.out.println("所用时间为："+(time2-time1));
		return picNamArry;
	}

	/**
	 * 通过此方法从数据库中得到所需要的数据
	 * 
	 * @throws BeanInitializationException
	 * @throws ErrorException
	 */
	public List<Object> getStatData() {

		DaoAdvice dao = DaoAdviceFactory.getDao("Alarm");
		try {
			// 当不为境内外时需要进行条件查询否则 就查询全部
			String category_id = alarmSta.getDistrict();

			if (!"2".equals(category_id)) {
				Alarm alarm = new Alarm();
				alarm.setCategory_id(category_id);
				objRet = dao.query(Alarm.class, alarm, null, false);
			} else {
				objRet = dao.query(Alarm.class, null, null, false);
			}

		} catch (BeanInitializationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return objRet;

	}

	/**
	 * 通过传入一个对象中所有的属性字段 得一个存放字段值和该字段值出现的次数集合
	 * 
	 * @param staticNam
	 *            一个以逗号隔开的对象属性字段 countries,measures 表示要得到通报国家和发布的机构
	 * @return
	 * @return List<Map<String,Integer>> 返回的是一个map集合 map中存放的是字段值和出现的次数 例如要得到通报国家
	 *         以及通报的频次 map<中国,80>
	 * 
	 *         Dynamo 2015/2/7 把split方法替换成有indexOf方法和sustring方法
	 *         StringBuffer替换成了StringBuilder 前者线程安全而后者线程不安全，故节约了锁资源的开销
	 * 
	 */
	public List<Map<String, Integer>> getMap(String staticNam, List<Object> obj) {

		// List<Alarm> obj=getAlarmData(); //得到存放Alarm对象的集合
		// mapArray是一个放入所有字段值和对应此字段值出现的次数map集合


		List<Map<String, Integer>> mapArray = new ArrayList<Map<String, Integer>>();

		String[] staticNamList = staticNam.split(","); // 拆分字段

		for (String name : staticNamList) {

			if ("rel_date".equals(name)) {
				// 当是对月份统计时 obj集合中的对象的月份都在此范围之内
				obj = getScaleMon(obj);
			}

			// map 是放入某个字段值和对应此字段值出现的次数
			// LinkedHashMap 取数据是按照put的数据的顺序

			// 原来StringBuffer替换成StrinBuilder由于StringBuffer是线程安全的
			// 而StringBuilder内方法没有同步故节省了锁的资源开销
			StringBuilder strTemp = new StringBuilder();
			// StringBuffer strTemp = new StringBuffer();
			Map<String, Integer> map = new LinkedHashMap<String, Integer>();

			// fieldValue是一个存放所有Alarm对象中某个属性的值的集合
			Set<String> fieldArray = new HashSet<String>();
			Set tempSet = new HashSet();
			strTemp.append(",");
			int size = obj.size();
			for (int i = 0; i < size; i++) {
				// tempSet是暂存时间的临时Set集合目的为了使Set数据是按顺序排列
				// Set中的数据必须是Integer类型才可以字段排序
				// 但传入的字段是rel_date时才用此临时Set集合让数据按
				// 1,2,3,4,5,6,7,8,9,10,11,12有序的存储

				Alarm alarm = (Alarm) obj.get(i);
				String field = null;
				try {
					if ("rel_date".equals(name)) {
						Date date = (Date) JFreeChartUtil.getFieldValue(
								Alarm.class, alarm, name);
						if (date != null)
							field = date.toLocaleString();
					} else {
						field = (String) JFreeChartUtil.getFieldValue(
								Alarm.class, alarm, name);
						if (field != null)
							field = field.replaceAll("\\s+", "");
					}

					// 当name=rel_date是发布日期时
					if ("rel_date".equals(name)) {
						// 以-格式拆分字段
						if (field != null) {

							// 把原来的split方法实现的功能由indexOf和sustring方法共同完成效率提高了
							field = field.substring(field.indexOf("-", 1) + 1,
									field.indexOf("-", 5));
							// String[] fieldArry = field.split("-");
							// field = fieldArry[1];
							tempSet.add(Integer.valueOf(field));
						}
					}

				} catch (ErrorException e) {
					e.printStackTrace();
				} catch (NumberFormatException e) {

					e.printStackTrace();
				}

				strTemp.append(field);
				if (field != null && !field.equals("")) {
					// 当临时Set集合不为空时才将tempSet赋值给fieldArray
					if (tempSet.size() != 0) {
						fieldArray = tempSet;

					} else {

						fieldArray.add(field);
					}

				}
				strTemp.append(",");
			}
			Iterator it = fieldArray.iterator(); // 遍历fieldArray集合
			while (it.hasNext()) {
				Object object = it.next();
				String fieldStr = String.valueOf(object);

				String tempStr = strTemp.toString().replace(
						"," + fieldStr + ",", ",");
				while (true) { // 循环进一步把要替换的字段替换为, 设fieldStr=1经过上面的replace把
								// ,1,1,6,7,替换为 ,1,6,7那么需要经过循环再一次替换
					// 进一步替换字符串 ,7,要替换的字符串,5, 把要替换的字符串替换为,
					// regex就是匹配字符串为 ,5,中国,要替换的字段,6,9, 其中 .代表的是任意字符
					if (fieldStr != null)
						fieldStr = fieldStr.replaceAll("\\?+", "");
					String regex = ",*.*," + fieldStr + ",.*,*";
					if (tempStr.matches(regex)) {
						tempStr = tempStr.replace("," + fieldStr + ",", ",");
					} else {
						break;
					}
				}
				int length = strTemp.toString().length() - tempStr.length();// length是属性字段总的字符串长度
				int count = length / (fieldStr.length() + 1);// count是属性字段值出现的次数
				if (name.equals("rel_date")) {// 当统计发布日期时需后在数字后加一个月
					fieldStr += "月";
				}
				map.put(fieldStr, count);

			}

			mapArray.add(map);

		}


		return mapArray;

	}

	/**
	 * 通过某一年的预警通报对中国出口食品(原产地是中国)通报的比例 和对中国出口产品通报的次数
	 * 
	 * @return
	 * @return
	 */
	public List<Object> retChiaOri() {

		// 用于保存所需要的数据
		List<Object> ret = new ArrayList<Object>();
		// 只是得到一个某一年的通过数据
		List wholYe = objWhYear;
		// 得到一个某一年并且原产地为中国的所有通报数据
		List chinYe = getChiaOri(wholYe);
		Integer wholItem = wholYe.size();
		Integer chinItem = chinYe.size();
		ret.add(wholItem);
		ret.add(chinItem);
		ret.add(Float.valueOf(getProportion(wholItem, chinItem)));
		// 对某个字段(国家)英国对原产地是中国的统计预警的次数最多的国家
		List<Map<String, Integer>> map = getMap(staticNam, chinYe);
		// chinField 当查看某个字段时字符串数组中存放的是某个字段对中国产品通报次数最多的，
		// 当全部时存放的多个字段对中国产品通报的次数做多的
		String[] chinField = new String[map.size()];
		int i = 0;
		for (Map<String, Integer> temp : map) {
			Map<String, Integer> retMap = sort(temp);
			Set set = retMap.keySet();

			if (set.size() == 0)
				chinField[i] = "无针对中国的食品通报项";
			for (Iterator it = set.iterator(); it.hasNext();) {
				chinField[i] = (String) it.next();
				break;
			}
			i++;
		}

		ret.add(chinField);
		return ret;
	}

	/**
	 * 统计占全年的比例
	 * 
	 * @param whole
	 *            全年总的通报项数
	 * @param propor
	 *            算出某个字段的项数
	 * @return
	 * @return Float
	 */
	public Float getProportion(Integer whole, Integer propor) {
		float result = 0;
		try {
			result = ((float) (propor.intValue() / (float) whole.intValue()) * 100);
			BigDecimal b = new BigDecimal(result);
			result = b.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return Float.valueOf(result);
	}

	/**
	 * 对map集合中的键值对进行排序 以逆序排序 {克罗地亚=1, 俄罗斯=1, 香港=4, 澳大利亚=71, 日本=313, 爱尔兰=7 }]
	 * 
	 * @param map
	 * @return void
	 */
	private static Map<String, Integer> sort(Map<String, Integer> map) {
		List list = new LinkedList(map.entrySet());
		Collections.sort(list, new Comparator() {
			public int compare(Object o1, Object o2) {
				return -((Comparable) ((Map.Entry<String, Integer>) (o1))
						.getValue())
						.compareTo(((Map.Entry<String, Integer>) (o2))
								.getValue());
			}
		});

		Map result = new LinkedHashMap();
		for (Iterator it = list.iterator(); it.hasNext();) {
			Map.Entry<String, Integer> entry = (Map.Entry<String, Integer>) it
					.next();
			result.put(entry.getKey(), entry.getValue());
		}
		return result;
	}

	/**
	 * 统计各个字段通报次数位于前三的数据
	 * 
	 * @return
	 * @return Map<String,Map<String,List>> map集合其中键代表的是六个字段值代表的是所需统计的结果
	 */
	public Map<String, Map<String, List>> getStatResu() {

		List<Object> obj = objWhYear;
		List<Map<String, Integer>> list = getMap(staticNam, obj);
		Map<String, Map<String, List>> reMap = new LinkedHashMap();
		String[] fieldStat = staticNam.split(",");

		for (int i = 0; i < list.size(); i++) {
			Map mapTemp = list.get(i);
			Map<String, Integer> map = sort(mapTemp);
			map = getRankMap(map, 3);

			int flag = 1;
			Map<String, List> retMap = new LinkedHashMap();
			for (Iterator it = map.keySet().iterator(); it.hasNext();) {
				List retList = new ArrayList();
				String key = (String) it.next();
				Integer value = map.get(key);
				Float propor = getProportion(obj.size(), value);
				retList.add(obj.size());// 存放的是全年的通报的项数
				retList.add(mapTemp.size());// 存放的是某个字段的(通报国家)的个数
				retList.add(key);
				retList.add(value);
				retList.add(propor);
				retMap.put("rank" + flag, retList);
				flag++;
			}
			reMap.put(fieldStat[i], retMap);
		}

		return reMap;

	}

	/**
	 * 得到map集合中前几个对象
	 * 
	 * @param map
	 *            起始map集合
	 * @param index
	 *            要得到前几个对象
	 * @return
	 * @return Map
	 */
	private Map getRankMap(Map map, int index) {

		Map<String, Integer> retMap = new LinkedHashMap();
		Set<Entry<String, Integer>> entry = map.entrySet();
		int count = 0;
		for (Iterator it = entry.iterator(); it.hasNext();) {
			if (count == index)
				break;
			Entry<String, Integer> e = (Entry<String, Integer>) it.next();
			retMap.put(e.getKey(), e.getValue());
			count++;
		}

		return retMap;
	}

	/**
	 * 得到全年的通报项数
	 * 
	 * @param origiChin
	 * @return
	 * @return List<Object> 装入的是某一年的所有Alarm对象
	 */
	public List<Object> getWholYe() {


		List<Object> obj = new ArrayList<Object>();
		for (int i = 0; i < objRet.size(); i++) {
			// 刷选出通报的年份与用户输入的相符
			if (((Alarm) objRet.get(i)).getRel_date() != null) {
				String time = ((Alarm) objRet.get(i)).getRel_date()
						.toLocaleString();
				String[] timeArray = time.split("-");
				String gyear = alarmSta.getYear();
				if (gyear.equals(timeArray[0]))
					obj.add(objRet.get(i));
			}
		}

		return obj;
	}

	/**
	 * 得到出产地是中国的对象集合 原产地是中国
	 * 
	 * @param obj
	 * @return
	 * @return List<Object>
	 */
	public List<Object> getChiaOri(List<Object> obj) {
		List<Object> obj1 = new ArrayList<Object>();
		for (Object ob : obj) {
			String orgin = ((Alarm) ob).getOrigin();
			String compStr = null;
			if (orgin != null)
				compStr = orgin.replaceAll("\\s+", "");
			if ("中国".equals(compStr)) {
				obj1.add(ob);
			}
		}
		return obj1;
	}

	/**
	 * 得到某个月份范围内的对象集合
	 * 
	 * @param obj
	 * @return
	 * @return List<Object>
	 */
	public List<Object> getScaleMon(List<Object> obj) {
		List<Object> obj1 = new ArrayList<Object>();
		for (Object ob : obj) {
			Date date = ((Alarm) ob).getRel_date();
			String time = null;
			if (date == null)
				continue;
			time = date.toLocaleString();
			String[] month = time.split("-");
			Integer commonth = Integer.valueOf(month[1]);
			Integer bmonth = Integer.valueOf(alarmSta.getBmonth());
			Integer emonth = Integer.valueOf(alarmSta.getEmonth());
			if (bmonth <= commonth && commonth <= emonth) {
				obj1.add(ob);
			}
		}
		return obj1;
	}

	/*	*//**
	 * 测试数据
	 * 
	 * @return
	 * @return List
	 * @throws ErrorException
	 * @throws BeanInitializationException
	 * @throws DBException
	 * @throws FileNotFoundException
	 */

	public static void main(String[] aths) throws ErrorException,
			BeanInitializationException, DBException, FileNotFoundException {
		/*
		 * AlarmSta a = new AlarmSta(); a.setStas_year("2013");
		 * a.setStas_bmonth("1"); a.setStas_emonth("12");
		 */
		// countries,rel_date,category,mbrsort,reject_des,measures
		/*
		 * e.getMap("countries", objRet);
		 * 
		 * String str = "2014-02-3"; str = str.substring(str.indexOf("-", 1) +
		 * 1, str.indexOf("-", 5)); System.out.println(str);
		 * 
		 * Map m = e.getStatResu(); Set<Entry<String, Map>> set = m.entrySet();
		 * List l = e.retChiaOri(); String[] s = (String[]) l.get(3); for
		 * (String s1 : s) // System.out.println(s1);
		 * 
		 * for (Iterator it = set.iterator(); it.hasNext();) { Entry<String,
		 * Map> ee = (Entry<String, Map>) it.next();
		 * System.out.println(ee.getKey()); for (Iterator i =
		 * ee.getValue().entrySet().iterator(); i .hasNext();) { Entry<String,
		 * List> eee = (Entry<String, List>) i.next();
		 * System.out.println(eee.getKey()); for (int k = 0; k <
		 * eee.getValue().size(); k++) {
		 * System.out.println(eee.getValue().get(k)); } }
		 * 
		 * }
		 */

		long beginTime = System.currentTimeMillis();
		EWBSAService e = EWBSAService.getInstance();
		// AlarmSta a = new AlarmSta();
		// a.setYear("2014");
		// a.setBmonth("1");
		// a.setEmonth("12");
		// a.setDistrict("2");
		// countries,mechanism,rel_date,reject_des,measures,mbrsort
		// String[] fileName = e.getPicNamArry("countries", null, "0", a);
		//
		// e.getStatResu();
		// e.retChiaOri();

		DaoAdvice dao = DaoAdviceFactory.getDao("Alarm");
		Alarm alarm = new Alarm();
		alarm.setCategory_id("2");
		List objRet = dao.query(Alarm.class, null, null, false);

		long endTime = System.currentTimeMillis();
		System.out.println("The Final Time " + (endTime - beginTime));

		// CollectionUtil.printList(service.getResult(alarm, null));
		// System.out.println(service.getResult(alarm, null).get(0).getClass());
		// System.out.println(e.getMap("measures",service.getResult(alarm,
		// null)));
	}

}
