package cn.jxqt.service.Detection;

import cn.jxqt.vo.statisticsalaysis.ClientInfoKeyVo;
import cn.jxqt.vo.statisticsalaysis.DatectionSampleKeyVo;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmountKeyVo;
import cn.jxqt.vo.statisticsalaysis.DetectionVarietiesKeyVo;

abstract class AbstractKey implements FatherKey{
	public ClientInfoKeyVo getClientInforKey() {
		return null;
	}
	public DetectionVarietiesKeyVo getDectionVarietiesOrAmountKey() {
		return null;
	}
	public DatectionSampleKeyVo getDectionSampleOr25Key() {
		return null;
	}
	public DectionMethodAmountKeyVo getDectionMethodOrAmountKey() {
		return null;
	}
}
