package cn.jxqt.service.Detection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import cn.jxqt.util.ManangerUtil;
import cn.jxqt.util.QuickSortUtil;
import cn.jxqt.vo.statisticsalaysis.CountData;
import cn.jxqt.vo.statisticsalaysis.ZBTest;

public class ZBCountUtil {
	private List<ZBTest> tableZB_mmt;
	private List<ZBTest> tableNotZB_mmt;
	private CountData keyWord_mmt;
	private ManangerUtil mu;
	public ZBCountUtil(ManangerUtil mu){
		this.mu = mu;
		exceutCount();
	}
	
	public void exceutCount(){
		this.tableZB_mmt = this.getZBCountResult(mu.getTableZB());
		this.tableNotZB_mmt = this.getZBCountResult(this.mu.getTableNotZB());
		this.keyWord_mmt = this.getReadKeyword(tableZB_mmt);
	}
	
	public List<ZBTest> getTableZB_mmt() {
		return tableZB_mmt;
	}
	public List<ZBTest> getTableNotZB_mmt() {
		return tableNotZB_mmt;
	}
	public CountData getKeyWord_mmt() {
		return keyWord_mmt;
	}

	
	
	
	
	public static boolean itemIsZB(String inspection_id){
		boolean result = false;
		if (inspection_id == null) {
		} else {
			result = inspection_id.startsWith("25");
		}
		return result;
	}
	
	public List<ZBTest> getZBCountResult(Map<String, ZBTest> resultMap) {
		List<ZBTest> countList = new ArrayList<ZBTest>();
		ZBTest item = null;
		String strOutPercent = null;
		String outPercent = null;
		
		Set<Entry<String, ZBTest>> set = resultMap.entrySet();
		Iterator<?> itor = set.iterator();
		Entry<String, ZBTest> entry = null;
		while (itor.hasNext()) {
			entry = (Entry<String, ZBTest>) itor.next();
			item = entry.getValue();
			//if(item.getTestOutCounts()>0){
				float testOutPercent = item.getTestOutCounts() / item.getTypeCounts() * 100;
				strOutPercent = String.valueOf(testOutPercent);
				outPercent = "0"; // 检测比率；
				if (strOutPercent.length() > 5) {
					outPercent = strOutPercent.substring(0, 5);
				} else {
					outPercent = strOutPercent;
				}
				item.setTestOutPercent(outPercent);
				countList.add(item);
		}
		return countList;
	}
	
	public CountData getReadKeyword(List<ZBTest> tableZB_mmt){
		CountData result = new CountData();
		result.setKind(tableZB_mmt.size());
		for(ZBTest o : tableZB_mmt){
			result.setTimes(result.getTimes()+(int)o.getTypeCounts());
			if(o.getTestOutCounts() > 0){
				result.setTestOutTimes(result.getTestOutTimes()+(int)o.getTestOutCounts());
				result.setTestOutKind(result.getTestOutKind()+1);
			}
		}
		List<ZBTest> list = QuickSortUtil.anyProperSort4(tableZB_mmt, "testOutCounts", true);
		String[] firstFive = new String[5];
		int listSize = 0;
		if(list.size()>=5){
			firstFive = new String[5]; 
			listSize = 5;
		}else{
			firstFive = new String[list.size()];
			listSize = list.size();
		}
		for(int j = list.size() -1,n = 0 ;  j >= list.size() - listSize; j--,n++ ){
			firstFive[n] = list.get(j).getName();
		}
		result.setFirstFive(firstFive);
		result.setFirstTestOutTimes((int)list.get(list.size()-1).getTestOutCounts());
		return result;
	}
}
