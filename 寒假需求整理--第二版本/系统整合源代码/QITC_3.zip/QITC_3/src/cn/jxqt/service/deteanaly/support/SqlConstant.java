package cn.jxqt.service.deteanaly.support;

import java.util.Map;

public final class SqlConstant {

	public static final String tableInfoNotChoose = " from (t_mbr,t_product,t_sta,t_slink) left join(t_bounds,t_bslink) on(t_bounds.b_id=t_bslink.b_id and t_bslink.sta_id=t_sta.sta_id) "
			+ "left join(t_apt,t_laboratory) on(t_apt.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_apt.lab_id) "
			+ "left join(t_dete) on(t_dete.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_dete.lab_id) "
			+ "where (t_slink.mbr_id=t_mbr.mbr_id and t_product.p_id=t_slink.p_id and t_sta.sta_id=t_slink.sta_id) and ";

	public static final String TableInfoForChooseBounds = " from (t_mbr,t_product,t_sta,t_slink,t_bounds,t_bslink) "
			+ "left join(t_apt,t_laboratory) on(t_apt.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_apt.lab_id) "
			+ "left join(t_dete) on(t_dete.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_dete.lab_id) "
			+ "where (t_slink.mbr_id=t_mbr.mbr_id and t_product.p_id=t_slink.p_id and t_sta.sta_id=t_slink.sta_id) and t_bounds.b_id=t_bslink.b_id and t_bslink.sta_id=t_sta.sta_id and ";

	public static final String TableInfoForChooseApt = " from (t_mbr,t_product,t_sta,t_slink,t_apt,t_laboratory) left join(t_bounds,t_bslink) on(t_bounds.b_id=t_bslink.b_id and t_bslink.sta_id=t_sta.sta_id) "
			+ "left join(t_dete) on(t_dete.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_dete.lab_id) "
			+ "where (t_slink.mbr_id=t_mbr.mbr_id and t_product.p_id=t_slink.p_id and t_sta.sta_id=t_slink.sta_id) and t_apt.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_apt.lab_id and ";

	public static final String TableInfoForChooseDete = " from (t_mbr,t_product,t_sta,t_slink,t_dete,t_laboratory) left join(t_bounds,t_bslink) on(t_bounds.b_id=t_bslink.b_id and t_bslink.sta_id=t_sta.sta_id) "
			+ "left join(t_apt) on(t_apt.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_apt.lab_id) "
			+ "where (t_slink.mbr_id=t_mbr.mbr_id and t_product.p_id=t_slink.p_id and t_sta.sta_id=t_slink.sta_id) and t_dete.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_dete.lab_id and ";

	public static final String TableInfoForChooseBoundsAndApt = " from (t_mbr,t_product,t_sta,t_slink,t_bounds,t_bslink,t_apt,t_laboratory) "
			+ "left join(t_dete) on(t_dete.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_dete.lab_id) "
			+ "where (t_slink.mbr_id=t_mbr.mbr_id and t_product.p_id=t_slink.p_id and t_sta.sta_id=t_slink.sta_id) and "
			+ "t_bounds.b_id=t_bslink.b_id and t_bslink.sta_id=t_sta.sta_id and t_apt.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_apt.lab_id and ";

	public static final String TableInfoForChooseBoundsAndDete = " from (t_mbr,t_product,t_sta,t_slink,t_bounds,t_bslink,t_dete,t_laboratory) "
			+ "left join(t_apt) on(t_apt.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_apt.lab_id) "
			+ "where (t_slink.mbr_id=t_mbr.mbr_id and t_product.p_id=t_slink.p_id and t_sta.sta_id=t_slink.sta_id) "
			+ "and t_bounds.b_id=t_bslink.b_id and t_bslink.sta_id=t_sta.sta_id and t_dete.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_dete.lab_id and ";

	public static final String TableInfoForChooseAptAndDete = " from (t_mbr,t_product,t_sta,t_slink,t_apt,t_dete,t_laboratory) "
			+ "left join(t_bounds,t_bslink) on(t_bounds.b_id=t_bslink.b_id and t_bslink.sta_id=t_sta.sta_id) "
			+ "where (t_slink.mbr_id=t_mbr.mbr_id and t_product.p_id=t_slink.p_id and t_sta.sta_id=t_slink.sta_id) "
			+ "and t_apt.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_apt.lab_id and t_dete.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_dete.lab_id and ";

	public static final String TableInfoForChooseAptAndDeteAndBounds = " from (t_mbr,t_product,t_sta,t_slink,t_bounds,t_bslink,t_apt,t_dete,t_laboratory) "
			+ "where (t_slink.mbr_id=t_mbr.mbr_id and t_product.p_id=t_slink.p_id and t_sta.sta_id=t_slink.sta_id) "
			+ "and t_apt.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_apt.lab_id and t_dete.sta_id=t_sta.sta_id and t_laboratory.lab_id=t_dete.lab_id "
			+ "and t_bounds.b_id=t_bslink.b_id and t_bslink.sta_id=t_sta.sta_id and ";

	/*
	 * private static final String tableInfo =
	 * " from t_bounds ,t_sta ,t_slink ,t_product ,t_mbr ,t_laboratory ,t_apt ,t_dete,t_bslink where "
	 * +
	 * " t_mbr.mbr_id=t_bounds.mbr_id and t_slink.mbr_id=t_mbr.mbr_id and t_apt.mbr_id=t_mbr.mbr_id and t_dete.mbr_id=t_mbr.mbr_id"
	 * +
	 * " and t_product.p_id=t_slink.p_id and t_product.p_id=t_bounds.p_id and t_product.p_id=t_apt.p_id and t_product.p_id=t_dete.p_id "
	 * +
	 * "	and t_sta.sta_id=t_slink.sta_id and t_bslink.sta_id=t_sta.sta_id and t_apt.sta_id=t_sta.sta_id and t_dete.sta_id=t_sta.sta_id "
	 * +
	 * "	and t_laboratory.lab_id=t_apt.lab_id and t_laboratory.lab_id=t_dete.lab_id and t_bounds.b_id = t_bslink.b_id and "
	 * ;
	 */
	public static final String firstSqlInfo = " select p_name,line,mbr_cname,m_id,residue,b_name,";

	

	public static final String searchInfo = "p_name,line,mbr_cname,m_id,residue,lab_name,b_name";
	
	public static final String searchInfoNotBname = "p_name,line,mbr_cname,m_id,residue,lab_name";
	
	public static final String searchInfoNotLab = "p_name,line,mbr_cname,m_id,residue,b_name";
	
	public static final String chooseSql(Map<String, String> chooseUnionTable) {

		String chooseFromSql = null;

		if (chooseUnionTable.get("limit") != null
				&& chooseUnionTable.get("apt") != null
				&& chooseUnionTable.get("dete") != null) {
			chooseFromSql = SqlConstant.TableInfoForChooseAptAndDeteAndBounds;
		} else if (chooseUnionTable.get("limit") == null
				&& chooseUnionTable.get("apt") == null
				&& chooseUnionTable.get("dete") == null) {
			chooseFromSql = SqlConstant.tableInfoNotChoose;
		} else if (chooseUnionTable.get("limit") != null
				&& chooseUnionTable.get("apt") == null
				&& chooseUnionTable.get("dete") == null) {
			chooseFromSql = SqlConstant.TableInfoForChooseBounds;
		} else if (chooseUnionTable.get("limit") == null
				&& chooseUnionTable.get("apt") != null
				&& chooseUnionTable.get("dete") == null) {
			chooseFromSql = SqlConstant.TableInfoForChooseApt;
		} else if (chooseUnionTable.get("limit") == null
				&& chooseUnionTable.get("apt") == null
				&& chooseUnionTable.get("dete") != null) {
			chooseFromSql = SqlConstant.TableInfoForChooseDete;
		} else if (chooseUnionTable.get("limit") != null
				&& chooseUnionTable.get("apt") != null
				&& chooseUnionTable.get("dete") == null) {
			chooseFromSql = SqlConstant.TableInfoForChooseBoundsAndApt;
		} else if (chooseUnionTable.get("limit") != null
				&& chooseUnionTable.get("apt") == null
				&& chooseUnionTable.get("dete") != null) {
			chooseFromSql = SqlConstant.TableInfoForChooseBoundsAndDete;
		} else if (chooseUnionTable.get("limit") == null
				&& chooseUnionTable.get("apt") != null
				&& chooseUnionTable.get("dete") != null) {
			chooseFromSql = SqlConstant.TableInfoForChooseAptAndDete;
		}
		return chooseFromSql;

	}
}
