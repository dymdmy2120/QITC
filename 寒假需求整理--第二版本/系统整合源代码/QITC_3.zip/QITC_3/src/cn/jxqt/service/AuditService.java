package cn.jxqt.service;

import java.util.List;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.dao.core.support.Page;
import org.web.exception.BeanInitializationException;
import org.web.exception.DBException;
import org.web.exception.ErrorException;
import org.web.service.QueryService;

public class AuditService {
	public void deleteAll(String viewName,Page page) throws BeanInitializationException, ErrorException, DBException{
		QueryService qs = new QueryService(viewName);
		List<Object> list = qs.getResult(null, null);
		int listSize = list.size();
		for(int i=0;i<listSize;i++){
			DaoAdvice sd = DaoAdviceFactory.getDao("Audit");
				sd.delete(list.get(i));
		}
	}
	
}
