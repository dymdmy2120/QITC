package cn.jxqt.service;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import tool.mastery.core.ToolKit;
import cn.jxqt.dao.file.FileObjectManager;
import cn.jxqt.dao.file.FileSystem;
import cn.jxqt.vo.FileVo;

public class VerifyDataGeter {
	private final static String dataPackgePath = "JxQtData/FileObject";
	private String workBeachPath = null;
	
	
	private static FileFilter filefilter = new FileFilter() {
        public boolean accept(File file) {
            if (file.getName().endsWith(".txt")) {
                return true;
            }
            return false;
        }
    };
	
	public VerifyDataGeter(){
	}
	
	public Map<String,Boolean> getResult(){
		List<File> fileList = getFileSystemData();
		MyMap m = new MyMap();
		
		String fileName = null;
		FileSystem fs = null;
		FileObjectManager fom = null;
		if(fileList != null){
			System.out.println("fileList size:"+fileList.size());
			for(File f : fileList){
				System.out.println(f);
				fileName = f.getName();
				fileName = fileName.substring(0, fileName.lastIndexOf("."));
				try {
					fs = FileSystem.load(fileName);
					if(fs.getList() == null || fs.getList().size() == 0){
						fom =  FileObjectManager.open(fileName);
						List<FileVo> list = fom.read();
						if(list != null && list.size() != 0){
							m.getMap().put(fileName, Boolean.TRUE);
						}
						
					}else{
						m.getMap().put(fileName, Boolean.TRUE);
					}
					fs.stopRead();
				} catch (IOException e) {
					e.printStackTrace();
				}finally{
					if(fom != null){
						try {
							fom.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		System.out.println("m.getMap():"+m.getMap());
		return m.getMap();
	}
	
	private List<File> getFileSystemData(){
		List<File> result = null;
		try {
			workBeachPath = VerifyDataGeter.class.getClassLoader().getResource("db.properties").toString();
			workBeachPath = workBeachPath.toString().substring(0, workBeachPath.toString().indexOf("WEB-INF"));
			workBeachPath = workBeachPath.replace("\\", "/");
			workBeachPath = workBeachPath.substring(6, workBeachPath.length())+dataPackgePath;
			
			File fileDataDir = new File(workBeachPath);
			if(!fileDataDir.isDirectory()){
				System.out.println("文件系统包不存在！"+fileDataDir);
			}else{
				File[] poFiles = fileDataDir.listFiles(filefilter);
				result = new ArrayList<File>();
				for(File f : poFiles){
					result.add(f);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	private class MyMap {
		private Map<String,Boolean> resultMap = null;
		private SAXReader saxReader = new SAXReader();
		public MyMap(){
			init();
		}
		
		public Map<String,Boolean> getMap(){
			return resultMap;
		}
		
		private void init(){
			InputStream is = ToolKit.getResourceAsStream("VerifyDirConf.xml");
			try {
				Document document = saxReader.read(is);
				Element rootNode = document.getRootElement();
				Element leafNode = null;
				resultMap = new HashMap<String,Boolean>();
				for(Iterator i = rootNode.elementIterator();i.hasNext();){
					leafNode = (Element)i.next();
					resultMap.put(leafNode.getData().toString(), false);
				}
			} catch (DocumentException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static boolean checkVerifyData(Map<String,Boolean> verifyDataMap){
		for (String key : verifyDataMap.keySet()) {
		    if(verifyDataMap.get(key)){
		    	return true;
		    }
		}
		return false;
	}
	
	public static void main(String[] args){
		VerifyDataGeter t = new VerifyDataGeter();
		System.out.println(t.getResult());
	}
}
