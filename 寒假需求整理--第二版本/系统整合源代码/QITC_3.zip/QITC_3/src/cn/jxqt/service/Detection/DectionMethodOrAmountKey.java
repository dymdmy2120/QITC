package cn.jxqt.service.Detection;

import java.util.List;

import cn.jxqt.util.QuickSortUtil;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmount;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmountKeyVo;

public class DectionMethodOrAmountKey extends AbstractKey{
	List<DectionMethodAmount> dectionMethodOrAmount = null;
	DectionMethodAmountKeyVo dectionMethodAmountKeyVo = new DectionMethodAmountKeyVo();
	public DectionMethodOrAmountKey(List<DectionMethodAmount> dectionMethodOrAmount){
		this.dectionMethodOrAmount = dectionMethodOrAmount;
	}
	public DectionMethodAmountKeyVo getDectionMethodOrAmountKey(){
		QuickSortUtil.anyProperSort3(dectionMethodOrAmount, "methodNumber", true);
		dectionMethodAmountKeyVo.setMethodNumber(dectionMethodOrAmount.size());
		dectionMethodAmountKeyVo.setMainMethod(dectionMethodOrAmount.get(dectionMethodOrAmount.size()-1).getDetectionMethod());
		dectionMethodAmountKeyVo.setMainMethodNumber(dectionMethodOrAmount.get(dectionMethodOrAmount.size()-1).getMethodNumber());
		return dectionMethodAmountKeyVo;
	}
}
