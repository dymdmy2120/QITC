package cn.jxqt.service.Detection;



import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.web.service.QueryService;

import cn.jxqt.util.ManangerUtil;
import cn.jxqt.vo.Hazards;
import cn.jxqt.vo.TestResult;
import cn.jxqt.vo.statisticsalaysis.StandardComparsionInfor;

/**
 * 
 * @author Administrator
 * 检测农药与限量标准对照表
 */
public class StandardComparison extends AbstractDetection{
	
	private ManangerUtil manager;
	
	public StandardComparison(ManangerUtil manager) {
		this.manager = manager;
	}
	
	public List<StandardComparsionInfor> getComparisonResultInfor(String[] selects) {
		List<StandardComparsionInfor> infors = null;
		int id = 0;
		try {
			infors = new ArrayList<StandardComparsionInfor>();
			Set<String> mbrNames = manager.getMbrNames();
			Hazards hazards = new Hazards();
			QueryService queryResult = new QueryService("Hazards");
			List<String> list = null;
			Iterator<String> it = mbrNames.iterator();
			while(it.hasNext()) {
				list = new ArrayList<String>();
				StandardComparsionInfor i = new StandardComparsionInfor();
				StandardComparsionInfor infor = null;
				String mbrName = it.next();
				for(int j=0; j<selects.length; j++) {
					hazards.setB_name(selects[j]);
					hazards.setMbr_cname(mbrName);
					infor = (StandardComparsionInfor) i.clone();
					infor.setMbr_cname(mbrName);
					List<Object> queryList = queryResult.getResult(hazards, null);
					if(queryList.size() != 0) {
						Hazards result = (Hazards) queryList.get(0);
						list.add(result.getLimited());
					} else {
						list.add("");
					}
System.out.println("my det " + list);
					id ++;
					infor.setId(id);
					infor.setList(list);
				}
				infors.add(infor);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return infors;
	}
	
}
