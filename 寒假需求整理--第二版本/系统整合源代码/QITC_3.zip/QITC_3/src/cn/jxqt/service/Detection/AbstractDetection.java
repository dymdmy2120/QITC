package cn.jxqt.service.Detection;
import java.util.List;

import cn.jxqt.vo.statisticsalaysis.ClientInfoSituation;
import cn.jxqt.vo.statisticsalaysis.ComparisonInfor;
import cn.jxqt.vo.statisticsalaysis.DatectionSample;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmount;
import cn.jxqt.vo.statisticsalaysis.DetectionVarieties;
import cn.jxqt.vo.statisticsalaysis.StandardComparsionInfor;
import cn.jxqt.vo.statisticsalaysis.StatisticalComparison;
import cn.jxqt.vo.statisticsalaysis.ZBTest;
//模板型模式
abstract class AbstractDetection implements IStrategy{
// 测试表1 食品室2013年（1月至12月）受检茶叶数量与项次数
	public  List<DetectionVarieties>getDectionVarietiesOrAmount() {
		return null;
	}
//送检客户情况
	public  List<ClientInfoSituation>getClientInfoSituation() {
		return null;
	}
//	样品检出情况(非自报检+自报检)
	public  List<DatectionSample>getDectionSample() {
		return null;
	}
//	检测方法使用种类及频次
	public  List<DectionMethodAmount>getDectionMethodOrAmount() {
		return null;
	}
	public  List<ZBTest> getZBCountResults(){
		return null;
		
	};
//	检测农药与限量标准对照表
	public List<StatisticalComparison> getDectionMatchLimitedLibrary() {
		return null;
	}
//	张晨辉
	public List<StandardComparsionInfor> getComparisonResultInfor(String[] selects) {
		return null;
	}
//	表九
	public List<ComparisonInfor> getDectionCheckLimitedLibrary(String[] selects) {
		return null;
	}
}
