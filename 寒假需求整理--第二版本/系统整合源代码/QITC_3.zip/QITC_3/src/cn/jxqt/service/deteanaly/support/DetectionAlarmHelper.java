package cn.jxqt.service.deteanaly.support;


import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import cn.jxqt.dao.DetectionAnalysisDao;
import cn.jxqt.vo.DCAssessment;
import cn.jxqt.vo.OperDetectAbility;

public class DetectionAlarmHelper {
	private DetectionAlarmHelper() {

	}

	private static class DetectionAlarmHelperI {
		final static DetectionAlarmHelper helper = new DetectionAlarmHelper();
	}

	public static DetectionAlarmHelper getInstance() {
		return DetectionAlarmHelperI.helper;
	}

	public Map<DCAssessment, Set<OperDetectAbility>> convertAlarmCount(
			Map<DCAssessment, Set<OperDetectAbility>> data) {
		List<String> rej_names = DetectionAnalysisDao.getInstance()
				.getAlarmSubQuality();

		Set<Entry<DCAssessment, Set<OperDetectAbility>>> dcaEntrys = data
				.entrySet();

		for (Entry<DCAssessment, Set<OperDetectAbility>> dcaEntry : dcaEntrys) {
			DCAssessment dca = dcaEntry.getKey();
			convertAlarmSingle(dca, rej_names);
		}

		return data;
	}

	public void convertAlarmSingle(DCAssessment dca, List<String> rej_names) {

		long noticeCount = 0;

		for (String rej_name : rej_names) {
			if (judgeIsNotice(dca.getMbr_cname(), rej_name)) {
				noticeCount++;
			}
		}
		dca.setNoticeCount(noticeCount);
	}

	/**
	 * 判断字符是否 被通报
	 * 
	 * @param mbr_cname
	 * @param rej_name
	 * @return Boolean flag
	 */
	public Boolean judgeIsNotice(String mbr_cname, String rej_name) {
		// char [] rejChars = rej_name.toCharArray();
		// char [] mbr_Chars = mbr_cname.toCharArray();

		if (rej_name.contains(mbr_cname)) {
			return true;
		} else {
			return false;
		}
	}

}
