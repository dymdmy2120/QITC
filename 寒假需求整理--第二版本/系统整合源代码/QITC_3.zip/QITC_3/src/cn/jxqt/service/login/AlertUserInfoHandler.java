package cn.jxqt.service.login;

import java.util.List;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.exception.BeanInitializationException;
import org.web.exception.DBException;
import org.web.exception.ErrorException;

import cn.jxqt.po.User;

public class AlertUserInfoHandler extends Handler {

	@Override
	public User respone(String operation, User user) throws ErrorException, BeanInitializationException {
		User retUser = null;
		
		try {
			DaoAdvice sd = DaoAdviceFactory.getDao("User");
			sd.update(user);
			System.out.println(user.getU_id());
			List<Object> list = sd.query(User.class, user, null, false);
			if(list.size()> 0){
				retUser = (User)list.get(0);
			}
		} catch (DBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return retUser;
	}

}
