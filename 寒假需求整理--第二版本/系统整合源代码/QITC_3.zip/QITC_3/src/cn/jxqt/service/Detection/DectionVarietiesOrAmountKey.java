package cn.jxqt.service.Detection;

import java.util.List;

import cn.jxqt.vo.statisticsalaysis.DetectionVarieties;
import cn.jxqt.vo.statisticsalaysis.DetectionVarietiesKeyVo;

//受检样品+项目次数
public class DectionVarietiesOrAmountKey extends AbstractKey{
	 private List<DetectionVarieties>DetectionVarieties = null;
	 DetectionVarietiesKeyVo detectionVarietiesKeyVo = new DetectionVarietiesKeyVo();
	
	 public DectionVarietiesOrAmountKey( List<DetectionVarieties> DetectionVarieties){
		 this.DetectionVarieties = DetectionVarieties;
	 }
	 
	 public DetectionVarietiesKeyVo getDectionVarietiesOrAmountKey() {
		 detectionVarietiesKeyVo.setCategory(DetectionVarieties.get(0).getCategory());
		 int a = DetectionVarieties.get(0).getSampleNumber()+DetectionVarieties.get(0).getSampleNumber23()+DetectionVarieties.get(0).getSampleNumber25();
		 detectionVarietiesKeyVo.setAmountCategory(a);
		 int b = DetectionVarieties.get(0).getTestingNumber()+DetectionVarieties.get(0).getTestingNumber23()+DetectionVarieties.get(0).getTestingNumber25();
		 detectionVarietiesKeyVo.setAmountTesting(b);
		 return detectionVarietiesKeyVo;
		}
}
