package cn.jxqt.service;

import org.web.exception.ErrorException;
import org.web.service.OperateService;

/**
 * 注：此service须配置在beans.xml当中,详情请查看beans.xml
 */
public class WorkLoadService extends OperateService {

	@Override
	public void save() throws ErrorException {
	}

	@Override
	public void update() throws ErrorException {
		System.out.println("execute update method");
	}

	@Override
	public void delete() throws ErrorException {
		System.out.println("execute delete method");
	}

}
