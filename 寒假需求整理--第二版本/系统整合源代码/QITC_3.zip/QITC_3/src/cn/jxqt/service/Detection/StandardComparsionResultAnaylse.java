package cn.jxqt.service.Detection;

import java.util.ArrayList;
import java.util.List;

import cn.jxqt.util.StatisticalAnalysisUtil;
import cn.jxqt.vo.statisticsalaysis.StandardComparsionInfor;
import cn.jxqt.vo.statisticsalaysis.StandardComparsionResult;

/**
 * 
 * @author Administrator
 *	检测农药与限量标准对照表 关键字
 */
public class StandardComparsionResultAnaylse {

	public static List<StandardComparsionResult> getStandardComparsionResult(
			List<StandardComparsionInfor> list, String[] selects) {
		List<StandardComparsionResult> resultList = new ArrayList<StandardComparsionResult>();
		StandardComparsionResult resultClone = new StandardComparsionResult();
		int selectsSize = selects.length;
		for(int i=0; i<selectsSize; i++) {
			StandardComparsionResult result = (StandardComparsionResult) resultClone.clone();
			result.setCount(list.size());
			int sum = 0;
			for(int j=0; j<list.size(); j++) {
				StandardComparsionInfor infor = list.get(j);
				if(!infor.getList().get(i).equals("")) {
					sum ++;
				}
			}
			String proper = StatisticalAnalysisUtil.getAfterTwo((float)sum / list.size());
			result.setSum(sum);
			result.setProper(Double.parseDouble(proper));
			resultList.add(result);
		}
		return resultList;
	}
}
