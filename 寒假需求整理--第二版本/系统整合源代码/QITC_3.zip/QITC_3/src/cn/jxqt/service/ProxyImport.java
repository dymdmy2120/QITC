package cn.jxqt.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.web.exception.ErrorException;

import cn.jxqt.util.ExcelException;
import cn.jxqt.util.ExcelToDbUtil;
import cn.jxqt.util.FileDelete;

public class ProxyImport {

	public static final String category_id = "category_id";
	
	private ExcelToDbUtil a;

	public ProxyImport(ExcelToDbUtil a) {
		this.a = a;
	}

	public List<Object> getAllByExcel(String voName, String filePath,
			String paramName , String paramValue) throws ErrorException {
		List<Object> list = null;
		Map<String , Object > map = new HashMap<String , Object>();
		try {
			map.put(paramName,paramValue);
			list = a.getAllByExcel(voName, filePath,map);
		} catch (ExcelException e1) {
			throw new ErrorException(e1.getMessage());
		} finally {
			FileDelete.deleteFile(filePath);
		}
		return list;
	}

}
