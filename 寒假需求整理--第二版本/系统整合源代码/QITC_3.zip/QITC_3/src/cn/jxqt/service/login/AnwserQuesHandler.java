package cn.jxqt.service.login;

import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;

import cn.jxqt.po.User;

public class AnwserQuesHandler extends Handler {

	@Override
	public User respone(String operation, User user) throws ErrorException, BeanInitializationException {
		User retUser = null;
		if(operation.equals("anwserQues")){
			try{
				retUser = this.findUser(user);
			}catch(ErrorException e){
				User tempUser = new User();
				tempUser.setU_id(user.getU_id());
				User tempResultUser = this.findUser(tempUser);
				StringBuffer errorInfo = new StringBuffer();
				if(!tempResultUser.getAnswer1().equals(user.getAnswer1())){
					errorInfo.append("密保问题1、");
				}
				if(!tempResultUser.getAnswer2().equals(user.getAnswer2())){
					errorInfo.append("2、");
				}
				if(!tempResultUser.getAnswer3().equals(user.getAnswer3())){
					errorInfo.append("3、");
				}
				errorInfo.delete(errorInfo.indexOf("、"), errorInfo.length());
				errorInfo.append("回答错误！");
				throw new ErrorException(errorInfo.toString());
			}
		}else{
			if(this.getNextHandler() != null){
				return this.getNextHandler().respone(operation, retUser);
			}else{
				System.out.println("无处理器=====");
			}
		}
		return retUser;
	}

}
