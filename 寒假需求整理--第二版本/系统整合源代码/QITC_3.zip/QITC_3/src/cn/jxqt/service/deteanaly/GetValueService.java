package cn.jxqt.service.deteanaly;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import org.web.exception.ErrorException;

import cn.jxqt.dao.DetectionAnalysisDao;

public class GetValueService {

	/**
	 * 函数功能说明 得到检测能力评估中选择的相应的字段
	 * 
	 * @param flag
	 * @return 当选择的是限量库则List集合就存字段的List集合 若实验室资质或检测经历则为存放字段和所有实验室的List集合
	 * @return List<String[]>
	 * @throws ErrorException
	 */
	public List<Map<String, String>> getVlues(String flag)
			throws ErrorException {
		List<Map<String, String>> lists = new ArrayList<Map<String, String>>();
		int index = Integer.valueOf(flag).intValue();
		Map<String, String> fileds = getFileds(index);// 获取字段
		lists.add(fileds);
		return lists;
	}

	/**
	 * 函数功能说明 通过一个英文属性字段得到对应的中文字段
	 * 
	 * @param param
	 *            一个英文字段名
	 * @return
	 * @throws ErrorException
	 * @return Map<String,String> 存放的是一个中英文字段的map集合
	 */
	public static Map<Long, String> getCorrespondMap(List<String> param)
			throws ErrorException {
		int count = 0;
		Map<Long, String> retValue = new TreeMap<Long, String>();
		Map<String, String> tempValue = new HashMap<String, String>();
		for (String list : param) {
			count = 0;
			while (true) {
				Map<String, String> map = getFileds(count);
				// 得到一个选择的字段与一个序号对应的属性文件
				Map<String, String> mapRes = getFileds(3);
				String value = map.get(list);
				if (value != null) {
					// 得到与之对应的序号
					String tempStr = mapRes.get(list);
					Long index = null;
					if (tempStr != null)
						index = Long.valueOf(tempStr);
					try {
						//System.out.println(index + " : " + value);
						retValue.put(index, value);
					} catch (NullPointerException e) {
					}
					break;
				} else {
					count++;
				}
				if (count == 3) {
					break;
				}
			}
		}

		return retValue;
	}

	/**
	 * 函数功能说明
	 * 
	 * @param index
	 *            表示要得第几个表中的字段 0代表是限量库 1代表检测经历 2实验室资质
	 * @return
	 * @throws ErrorException
	 * @return List<String[]>
	 */
	private static Map<String, String> getFileds(int index)
			throws ErrorException {
		String[] proNameArray = { "Hazards.properties", "LabTest.properties",
				"LabApt.properties", "ShowResult.properties" };
		File file = null;
		Map<String, String> fieldsMP = new HashMap<String, String>();
		String poSrc = "cn.jxqt.properties.analysis";
		String urlPath = GetValueService.class.getClassLoader()
				.getResource("action.xml").toString();
		try {
			urlPath = urlPath.substring(0, urlPath.lastIndexOf("/")) + "/"
					+ poSrc.replace(".", "/") + "/" + proNameArray[index];
			file = new File(new URI(urlPath));
			InputStream inputStream = new FileInputStream(file);
			Properties pro = new Properties();
			pro.load(inputStream);
			Set set = pro.keySet();
			Iterator<String> it = set.iterator();
			while (it.hasNext()) {
				String tempField = it.next();
				//System.out.println(pro.getProperty(tempField) + " : tempField : " + tempField);
				fieldsMP.put(pro.getProperty(tempField), tempField);
			}
		} catch (URISyntaxException e) {

		} catch (ArrayIndexOutOfBoundsException e) {
			// TODO Auto-generated catch block
			System.out.println("数组越界");
		} catch (Exception e) {
			throw new ErrorException("属性文件找不到!");
		}
		if (file == null) {
			throw new ErrorException("文件路径错误!");
		}

		return fieldsMP;

	}

	/**
	 * 函数功能说明 得到所有实验室的名称
	 * 
	 * @param index
	 * @return
	 * @throws ErrorException
	 * @return List<List<String>>
	 */
	public List<String> getLabNames() throws ErrorException {
		List<String> labNames = DetectionAnalysisDao.getInstance()
				.getLabNames();
		return labNames;
	}

	public List<String> getBoundNames() throws ErrorException {
		List<String> boundNames = DetectionAnalysisDao.getInstance()
				.getBoundName();
		return boundNames;
	}
	// private final static DefaultDaoAdvice daoAdvice = new DefaultDaoAdvice();
}
