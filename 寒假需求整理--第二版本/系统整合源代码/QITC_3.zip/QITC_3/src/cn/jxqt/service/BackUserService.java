package cn.jxqt.service;

import org.web.exception.ErrorException;
import org.web.service.OperateService;

public class BackUserService extends OperateService {

	@Override
	protected void save() throws ErrorException {

	}

	@Override
	protected void update() throws ErrorException {
		// TODO Auto-generated method stub

	}

	@Override
	protected void delete() throws ErrorException {
		// TODO Auto-generated method stub

	}

}
