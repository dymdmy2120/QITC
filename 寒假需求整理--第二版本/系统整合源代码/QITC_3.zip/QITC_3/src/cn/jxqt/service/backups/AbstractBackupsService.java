package cn.jxqt.service.backups;

import org.web.exception.ErrorException;

import cn.jxqt.util.dynamo.DataBaseBackups;
import cn.jxqt.util.dynamo.IBackups;


public abstract class AbstractBackupsService {

	protected IBackups handle;
	
	/**
	 * 默认的备份内容(备份数据库文件)
	 */
	public AbstractBackupsService() {
		
		this.handle = new DataBaseBackups();
	}
	
    public AbstractBackupsService(IBackups handle) {
		
		this.handle = handle;
	}
    public abstract boolean handleBack(String sourcePath,String destPath) throws ErrorException;

	public boolean hand(String sourcePath,String destPath) throws ErrorException {
		return handle.backups(sourcePath, destPath);
	}

}
