package cn.jxqt.service.deteanaly;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.web.exception.DBException;
import org.web.exception.ErrorException;

import cn.jxqt.dao.DetectionAnalysisDao;
import cn.jxqt.service.deteanaly.support.DetectionAlarmHelper;
import cn.jxqt.vo.DCAssessment;
import cn.jxqt.vo.OperDetectAbility;

public class DetectionAnalysisService {

	private DetectionAnalysisService() {

	}

	private static class DetectionAnalysisServiceHelper {
		final static DetectionAnalysisService deteService = new DetectionAnalysisService();
	}

	public static DetectionAnalysisService getInstance() {
		return DetectionAnalysisServiceHelper.deteService;
	}

	// 对检测情况servlet里面数据进行处理
	/**
	 * 根据前台页面得到的客户查询对象,选择匹配的限量库来进行检测能力评估的业务方法
	 * 
	 * @param beaninfo
	 * @param boundsInfo
	 * @param searchInfo
	 * @return
	 * @throws ErrorException
	 */
	public Map<DCAssessment, Set<OperDetectAbility>> convertDetectionNotRepeat(
			List<List<Object>> beaninfo, Map<String, List<String>> boundsInfo,
			String searchInfo, Map<String, String> chooseUnionTable)
			throws ErrorException {
		Map<String, List<OperDetectAbility>> deteInfo = null;
		try {
			// 调用DetectionAnalysisDao层的数据操作方法
			deteInfo = DetectionAnalysisDao.getInstance()
					.getDetectAnalysisInfo(OperDetectAbility.class, beaninfo,
							boundsInfo, searchInfo, chooseUnionTable);

			// System.out.println("dispathcer size L : " + deteInfo);
		} catch (DBException e) {
			throw new ErrorException("信息统计分析数据出现错误！");
		}

		Set<Entry<String, List<OperDetectAbility>>> deteInfoSet = deteInfo
				.entrySet();
		Set<OperDetectAbility> finalHazList = new HashSet<OperDetectAbility>();
		// 先遍历deteInfoMap集合，将所有的数据存入到finalHazList List集合中
		for (Entry<String, List<OperDetectAbility>> deteEntry : deteInfoSet) {

			// System.out.println("dete info : " + deteEntry.getValue().size());
			for (OperDetectAbility oper : deteEntry.getValue()) {
				finalHazList.add(oper);
			}
		}

		// System.out.println("finalSize : " + finalHazList.size());

		// 对finalHazList集合进行处理，以样品名称和检测项目来检测是否是重复的对象；
		Set<OperDetectAbility> copyList = new HashSet<OperDetectAbility>(
				finalHazList.size());
		Set<OperDetectAbility> copyListAll = new HashSet<OperDetectAbility>(
				finalHazList.size());
		copyList.addAll(finalHazList);
		copyListAll.addAll(finalHazList);
		/**
		 * 去掉样品名称,检测项目有名称，方法编号重复的对象
		 */
		long copyCount = 0;
		long copyCountAll = 0;

		for (OperDetectAbility copy : copyListAll) {
			long size = 0;
			for (OperDetectAbility copyall : copyList) {

				if (copyCount == copyCountAll) {
					copyCountAll++;
					continue;
				}
				if (copyall.getMbr_cname() == null
						|| copyall.getP_name() == null
						|| copyall.getM_id() == null) {
					copyCountAll++;
					continue;
				}
				if (copyall.getP_name().equals(copy.getP_name())
						&& copyall.getMbr_cname().equals(copy.getMbr_cname())
						&& copyall.getM_id().equals(copy.getM_id())) {
					// OperDetectAbility nullOper = new OperDetectAbility();
					size++;
					if (size > 1) {
						copyall.setP_name("");
					}
				} else {
					copyCountAll++;
					continue;
				}
				copyCountAll++;

			}
			copyCount++;
		}
		/*
		 * for (int j = 0; j < copyListAll.size(); j++) { for (int i = 0; i <
		 * copyList.size(); i++) { if (j == i) { continue; } else { if
		 * (copyList.get(i).getP_name() .equals(copyListAll.get(j).getP_name())
		 * && copyList.get(i).getMbr_cname()
		 * .equals(copyListAll.get(j).getMbr_cname()) &&
		 * copyList.get(i).getM_id() .equals(copyListAll.get(j).getM_id())) { //
		 * OperDetectAbility nullOper = new OperDetectAbility();
		 * copyListAll.get(i).setP_name(""); } else { continue; } } } }
		 */
		Set<OperDetectAbility> relCopyList = new HashSet<OperDetectAbility>(
				finalHazList.size());

		for (OperDetectAbility oper : copyList) {
			if (oper.getP_name() == null || oper.getP_name().equals("")) {
				continue;
			}
			relCopyList.add(oper);
		}

		// System.out.println("relCopt :" + relCopyList.size());

		// 拿到处理重复之后的List集合，将其转换成DCAssessment对象的集合
		Set<DCAssessment> dcaList = convertToDCAssessment(relCopyList);
		Map<DCAssessment, Set<OperDetectAbility>> mapDCAssessValue = new HashMap<DCAssessment, Set<OperDetectAbility>>();
		for (DCAssessment dcament : dcaList) {
			Set<OperDetectAbility> mapValue = new HashSet<OperDetectAbility>(
					finalHazList.size());
			for (OperDetectAbility operValue : finalHazList) {
				if (operValue.getP_name().equals(dcament.getP_name())
						&& operValue.getMbr_cname().equals(
								dcament.getMbr_cname())
						&& operValue.getM_id().equals(dcament.getM_id())) {
					mapValue.add(operValue);
				}
			}
			mapDCAssessValue.put(dcament, mapValue);
		}

		DetectionAlarmHelper.getInstance().convertAlarmCount(mapDCAssessValue);
		return mapDCAssessValue;
	}

	/**
	 * 将OperHazards对象集合转换成对应的DCAssessment对象集合的方法
	 * 
	 * @param relCopyList
	 *            ： OperHazards对象集合
	 * @return
	 */
	public Set<DCAssessment> convertToDCAssessment(
			Set<OperDetectAbility> relCopyList) {
		Set<DCAssessment> dcaList = new HashSet<DCAssessment>(
				relCopyList.size());
		for (OperDetectAbility oper : relCopyList) {
			// 调用单个对象转换的方法
			DCAssessment dca = convertToDCAssessmentSingle(oper);
			dcaList.add(dca);
		}
		return dcaList;
	}

	/**
	 * 将OperHazards对象转换成对应的DCAssessment对象集合，通过对比其属性字段；
	 * 
	 * @param oper
	 *            ： 所需转换的OperHazards对象集合
	 * @return
	 */
	public DCAssessment convertToDCAssessmentSingle(OperDetectAbility oper) {
		Field[] fields = oper.getClass().getDeclaredFields();
		Field[] fieldsForDCA = DCAssessment.class.getDeclaredFields();
		DCAssessment dca = new DCAssessment();
		for (Field field : fields) {
			for (Field dcaField : fieldsForDCA) {
				if (field.getName().equals(dcaField.getName())) {
					try {
						Method writeMethod = DCAssessment.class
								.getDeclaredMethod(
										"set"
												+ dcaField.getName()
														.substring(0, 1)
														.toUpperCase()
												+ dcaField.getName().substring(
														1,
														dcaField.getName()
																.length()),
										dcaField.getType());
						field.setAccessible(true);
						try {
							writeMethod.invoke(dca, field.get(oper));
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						} catch (IllegalArgumentException e) {
							e.printStackTrace();
						} catch (InvocationTargetException e) {
							e.printStackTrace();
						}
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					} catch (SecurityException e) {
						e.printStackTrace();
					}
				}
			}
		}
		return dca;
	}

}
