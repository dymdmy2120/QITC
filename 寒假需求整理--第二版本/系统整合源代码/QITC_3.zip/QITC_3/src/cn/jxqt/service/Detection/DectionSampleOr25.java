package cn.jxqt.service.Detection;


import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import cn.jxqt.util.ManangerUtil;
import cn.jxqt.util.StatisticalAnalysisUtil;
import cn.jxqt.vo.TestResult;
import cn.jxqt.vo.statisticsalaysis.DatectionSample;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmount;
import cn.jxqt.vo.statisticsalaysis.DetectionKey;

public class DectionSampleOr25 extends AbstractDetection {
	protected String operate;
	private ManangerUtil manger;
	public DectionSampleOr25(ManangerUtil manger, String operate) {
//		this.testResasult = testResasult;
		this.manger = manger;
		this.operate = operate;
	}
	@Override
	public List<DatectionSample> getDectionSample() {
		// TODO Auto-generated method stub
		List<DatectionSample> listInspection = new ArrayList<DatectionSample>();// 将多个统计结果数存放在这个双重list集合并返回（非自报检）
		List<String> PName1 = StatisticalAnalysisUtil
				.removeDuplicateWithOrder(manger.getPName());// 将重复有顺序的样品名称数据转换成有顺序不重复的集合
		int PName1Size = PName1.size();
		DatectionSample datectionSampleSuper = new DatectionSample();
		DatectionSample datectionSample = null;
		int PIDSize = manger.getPId2().size();
		for (int pname1 = 0; pname1 < PName1Size; pname1++) {
			String PName2 = PName1.get(pname1);// 样品名称
			List<String> pid = new ArrayList<String>();
			List<String> number1 = new ArrayList<String>();
			for (int i = 0;i<PIDSize;i++) {
				if (operate.equalsIgnoreCase("!25")) {
					if (manger.getPId2().get(i).getInspection_id().indexOf("25") != 0) {
						if (PName2.equalsIgnoreCase(manger.getPId2().get(i).getP_name())) {
							pid.add(manger.getPId2().get(i).getP_id());
							String pid2 = manger.getPId2().get(i).getP_id();
							Iterator it =manger.getMap().entrySet().iterator();
					        while(it.hasNext()){
					        	Map.Entry<String, String> entry = (Entry<String, String>) it.next();
					        	if (pid2.equalsIgnoreCase(entry.getKey())) {
									if (entry.getValue() == null) {
										continue;
									} else {
										if (entry.getValue().contains("阳性")) {
											number1.add(entry.getKey());
										}
									}
								}
					        }
						}
					}
				} else {
					if (operate.equalsIgnoreCase("25")) {
						if (manger.getPId2().get(i).getInspection_id().indexOf("25") == 0) {
							if (PName2.equalsIgnoreCase(manger.getPId2().get(i).getP_name())) {
								pid.add(manger.getPId2().get(i).getP_id());
								String pid2 = manger.getPId2().get(i).getP_id();
								Iterator it =manger.getMap().entrySet().iterator();
						        while(it.hasNext()){
						        	Map.Entry<String, String> entry = (Entry<String, String>) it.next();
						        	if (pid2.equalsIgnoreCase(entry.getKey())) {
										if (entry.getValue() == null) {
											continue;
										} else {
											if (entry.getValue().contains("阳性")) {
												number1.add(entry.getKey());
											}
										}
									}
						        }
							}
						}
					}
				}
			}
			datectionSample = (DatectionSample) datectionSampleSuper
					.clone();
			datectionSample.setSampleName(PName2);
			datectionSample.setSampleNumber(StatisticalAnalysisUtil
					.removeDuplicateWithOrder(pid).size());
			int amount = pid.size();
			// 由于一个样品只要有一个检测项目被检出，该样品就算被检测出，所以必须将该集合中重复的检测出的样品编号变成不重复
			List<String> DecMbrCnaNumber = new ArrayList<String>();
			DecMbrCnaNumber = StatisticalAnalysisUtil
					.removeDuplicateWithOrder(number1);
			int number = DecMbrCnaNumber.size();
			datectionSample.setSampleDetectionNumber(number);
			// 将计算出的double出样品检出率
			String Ratio;
			if(amount==0){
				 Ratio = "0";
			}else{
				double ratio = ((double) number / (double) amount) * 100;
			   Ratio = StatisticalAnalysisUtil.getAfterTwo(ratio);
			}
			datectionSample.setSampleDetectionRate(Ratio);
			listInspection.add(datectionSample);
//			list.clear();
		}
		return listInspection;
	}
}
