package cn.jxqt.service.login;

import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;

import cn.jxqt.po.User;

public class FogetPasHandler extends Handler {

	@Override
	public User respone(String operation, User user) throws ErrorException, BeanInitializationException {
		User retUser = null;
		if(operation.equals("forgetPas")){
			retUser = this.findUser(user);
		}else{
			if(this.getNextHandler() != null){
				return this.getNextHandler().respone(operation, user);
			}else{
				System.out.println("无处理器=====");
			}
		}
		if(retUser.getPspb1() == null){
			throw new ErrorException("该用户未设置密保，无法找回密码！");
		}
		
		return retUser;
	}

}
