package cn.jxqt.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.dao.core.support.Page;
import org.web.exception.DBException;
import org.web.exception.ErrorException;
import org.web.service.OperateService;
import cn.jxqt.action.BackOperateAction;
import cn.jxqt.po.User;
import cn.jxqt.po.UserPower;
import cn.jxqt.util.MD5Util;
import cn.jxqt.util.RandomChar;
import cn.jxqt.vo.UserInfo;

public class UserService extends OperateService {

	UserInfo userinfo = null;
	UserPower userpower = null;
	User user = null;
	String defaultpassword = null;

	@Override
	protected void save() throws ErrorException {

		user = (User) list.get(0); // 得到关于user对象 然后将生成的MD5加密后的密码写入
		try {
			this.dao.save(getByMD5User(user));
			for (int i = 1; i < list.size(); i++) {
				this.dao.save(list.get(i));
			}
			sendEmail(); // 保存完毕后发送邮件
			list.clear();
		} catch (Exception e) {
			delete(); // 如果出现异常 就删除原来插入进去的数据
			throw new ErrorException("用户添加失败!原因是:邮件发送失败,请检查网络设置");
		}

	}

	@Override
	protected void update() {
		user = (User) list.get(0);
		// 判断更新的类型 用户信息 更新或是用户邮件密码重置
		try {
			if (user.getU_name() == null) {
				updatePassword(); // 密码重置更新
			} else {
				updateUserinfo(); // 更新用户信息
			}
		}catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("用户信息更新失败!原因是邮件发送失败  请检查网络设置");
		}

	}

	@Override
	protected void delete() throws ErrorException {
		user = (User) this.list.get(0);
		try {
			if(user != null ) {
				this.dao.delete(user);
				list.clear();
			}
		} catch (DBException e) {
			e.printStackTrace();
			throw new RuntimeException("删除失败  请检查数据库!");
		}

	}

	/**
	 * 更新用户信息 权限+个人信息
	 * 
	 * @return
	 * @throws ErrorException
	 * @throws DBException
	 */
	public void updateUserinfo() throws ErrorException, DBException {

		DaoAdvice sd = DaoAdviceFactory.getDao("User");
		User temp = new User();
		user = (User) list.get(0);
		temp.setU_id(user.getU_id());

		User user_temp = (User) sd.query(User.class, temp, new Page(), false)
				.get(0); // 重新查询出数据

		user_temp.setU_id(user.getU_id());
		user_temp.setU_name(user.getU_name().trim());
		user_temp.setEmail(user.getEmail());
		user_temp.setPhone(user.getPhone());
		user_temp.setDepartment(user.getDepartment()); // 将原来对象进行缓存

		try {
			this.dao.delete(user); // 更新用户信息 方便重新更新用户权限
			this.dao.save(user_temp); // 重新保存用户信息
			for (int i = 1; i < list.size(); i++) { // 保存用户信息
				this.dao.save(list.get(i));
			}
			list.clear();
		} catch (DBException e1) {
			e1.printStackTrace();
			throw new DBException("用户信息更新失败,请检查数据库");
		}
	}

	/**
	 * 密码重置操作 的更新
	 * 
	 * @return
	 * @throws ErrorException
	 * @throws DBException
	 */
	private boolean updatePassword() throws ErrorException, DBException {
		boolean flag = false;
		user = (User) list.get(0); // 得到用户信息 写入加密后的密码
		if (user != null) {
			try {
				this.dao.update(getByMD5User(user));
				sendEmail(); // 发送邮件
				list.clear();
				flag = true;
			} catch (DBException e) {
				flag = false;
				e.printStackTrace();
				throw new DBException("用户信息更新失败!");
			} catch (ErrorException e) {
				throw new ErrorException("用户添加失败 ！ 原因是: 邮件发送失败,  请检查网络设置");
			}

		}
		return flag;
	}

	private boolean sendEmail() throws ErrorException {
		Boolean bool = false;
		// 设置发送邮件
		HttpServletRequest request = new BackOperateAction().getRequest();
		System.out.println("sun " + request);
		if (request != null) {
			try {
				bool = MailSendService.SendEmail(request, user.getEmail(),
						defaultpassword, user.getU_id());

			} catch (ErrorException e) {
				System.out.println("sun ");
				e.printStackTrace();
				throw new ErrorException("邮件发送失败，请检查网络设置");
			}
		}
		return bool;
	}

	private User getByMD5User(User user) {
		defaultpassword = RandomChar.getRandomString();// 生成8位随机字符串：数字+字母
		user.setPassword(MD5Util.EncoderByMd5(defaultpassword)); // 插入默认密码
		return user;
	}

}
