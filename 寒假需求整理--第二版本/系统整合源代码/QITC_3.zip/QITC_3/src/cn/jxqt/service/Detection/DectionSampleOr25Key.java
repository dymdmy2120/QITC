package cn.jxqt.service.Detection;

import java.util.ArrayList;
import java.util.List;

import cn.jxqt.util.QuickSortUtil;
import cn.jxqt.util.StatisticalAnalysisUtil;
import cn.jxqt.vo.statisticsalaysis.DatectionSample;
import cn.jxqt.vo.statisticsalaysis.DatectionSampleKeyVo;

public class DectionSampleOr25Key extends AbstractKey {

	
	DatectionSampleKeyVo datectionSampleKeyVo = new DatectionSampleKeyVo();
	private List<DatectionSample> datectionSample = null;

	public DectionSampleOr25Key(List<DatectionSample> datectionSample) {
		this.datectionSample = datectionSample;
	}

	public DatectionSampleKeyVo getDectionSampleOr25Key() {
		int amount = 0;
		int amount1 = 0;
		int amountFlag = 0;
		QuickSortUtil.anyProperSort1(datectionSample, "sampleNumber", true);
		// 检出情况品种数量关键字、主要检出显示
		List<String> RankingOneTofive = new ArrayList<String>();
		if (datectionSample.size() > 5) {
			for (int i = 1; i < 6; i++) {
				if (datectionSample.get(datectionSample.size() - i)
						.getSampleName() != null) {
					RankingOneTofive.add(datectionSample.get(
							datectionSample.size() - i).getSampleName());
				} else {
					RankingOneTofive.add("");
				}
			}
		} else {
			for (int i = 0; i < datectionSample.size(); i++) {
				String a=datectionSample.get(i).getSampleName();
				RankingOneTofive.add(a);
			}
		}
		datectionSampleKeyVo.setVarietiesNumber(datectionSample.size());// 样品的品种数量
		datectionSampleKeyVo.setRankingOneTofive(RankingOneTofive);// 排名前五的进行数据封装
		int tempFlag = 0;
		// 样品批次就是检测项目数 --》样品检出率：
		int datectionSampleSize = datectionSample.size();
		int flag = 0;
		int flag1 =0;
		for (int i = 0; i < datectionSampleSize; i++) {
			flag = datectionSample.get(i).getSampleDetectionNumber();
			flag1 = datectionSample.get(i).getSampleNumber();
			if (flag != 0) {
				amount = flag + amount;
			}
			if (flag1 != 0) {
				amount1 = flag1 + amount1;
			}
			if (flag >= amountFlag) {// 获得检出数量最多的值
				amountFlag = flag;
				tempFlag = i;
			} else {
				continue;
			}
		}
		// 样品总数
		datectionSampleKeyVo.setVarietiesAmount(amount1);
		// 样品检出数量
		datectionSampleKeyVo.setDetectionAmount(amount);
		// 样品检出率
		double ratio = ((double) amount / (double) amount1) * 100;
		String Ratio = StatisticalAnalysisUtil.getAfterTwo(ratio);
		datectionSampleKeyVo.setRatio(Ratio);
		// 最大检出数量的样品名称以及检出数量
		datectionSampleKeyVo.setLargeDetection(datectionSample.get(tempFlag)
				.getSampleName());
		datectionSampleKeyVo.setTempFlag(datectionSample.get(tempFlag)
				.getSampleDetectionNumber());
		return datectionSampleKeyVo;

	}
}
