package cn.jxqt.service.Detection;

import java.util.List;

import cn.jxqt.util.QuickSortUtil;
import cn.jxqt.vo.statisticsalaysis.ClientInfoKeyVo;
import cn.jxqt.vo.statisticsalaysis.ClientInfoSituation;

public class ClientInforKey extends AbstractKey{
	private List<ClientInfoSituation> ClientInfoSituation  = null;
	public ClientInforKey(List<ClientInfoSituation> ClientInfoSituation){
		this.ClientInfoSituation = ClientInfoSituation;
	}
	
	public ClientInfoKeyVo getClientInforKey(){
		ClientInfoKeyVo clientInfoKeyVo = new ClientInfoKeyVo();
		//对这个集合进行排序，并获得前2
		QuickSortUtil.anyProperSort(ClientInfoSituation,"inspectionNumber", true);
		clientInfoKeyVo.setFirstSupper(ClientInfoSituation.get(ClientInfoSituation.size()-1).getAddress());
        //		判断是否有排名第二，保证不报空指针
		if(ClientInfoSituation.get(ClientInfoSituation.size()-2).getAddress() == null){
			clientInfoKeyVo.setSecondSupper("");
		}else{
			clientInfoKeyVo.setSecondSupper(ClientInfoSituation.get(ClientInfoSituation.size()-2).getAddress());
		}
		return clientInfoKeyVo;
		
	}
}
