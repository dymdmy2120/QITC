package cn.jxqt.service.Detection;


import java.util.ArrayList;
import java.util.List;

import cn.jxqt.util.ManangerUtil;
import cn.jxqt.util.StatisticalAnalysisUtil;
import cn.jxqt.vo.ClientInfor;
import cn.jxqt.vo.statisticsalaysis.ClientInfoSituation;
import cn.jxqt.vo.statisticsalaysis.DetectionVarieties;

public class ClientInforSituation extends AbstractDetection{
	private ManangerUtil manger;
	public  ClientInforSituation(ManangerUtil manger){
		   this.manger=manger;
	 }
	@Override
	public List<cn.jxqt.vo.statisticsalaysis.ClientInfoSituation> getClientInfoSituation() {
		// TODO Auto-generated method stub
		List<ClientInfoSituation> list1 = new ArrayList<ClientInfoSituation>();// 将多个统计结果数存放在这个双重list集合并返回
		List<String> amount1 = StatisticalAnalysisUtil
				.removeDuplicateWithOrder(manger.getAmount());// 统计总的样品数量
		List<String> ClientName1 = StatisticalAnalysisUtil
				.removeDuplicateWithOrder(manger.getClientName());// 将重复有顺序的数据转换成有顺序不重复的集合
		ClientInfoSituation clientInfoSituationSuper = new ClientInfoSituation();
		ClientInfoSituation clientInfoSituation = null;
		int size1 = ClientName1.size();
		for (int clientname1 = 0; clientname1 < size1; clientname1++) {// 一个类别对应多个样品，一个样品对应多个检测项目，用三循环达到一对多的关系
			String Client_Name = ClientName1.get(clientname1);// 客户名称
			List<String> pid = new ArrayList<String>();
			List<String> clientAddress2 = new ArrayList<String>();
			for (List<String> pid1 : manger.getPId1()) {
				if (Client_Name.equalsIgnoreCase(pid1.get(0))) {
					pid.add(pid1.get(1));
					for (List<String> clientAddress1 : manger.getClientAddress()) {
						if (Client_Name.equalsIgnoreCase(clientAddress1.get(0))) {
							clientAddress2.add(clientAddress1.get(1));
						}
					}
				}
			}
			clientInfoSituation = (ClientInfoSituation) clientInfoSituationSuper.clone();
			clientInfoSituation.setId(clientname1 + 1);
			clientInfoSituation.setClientName(Client_Name);
			List<String> pid3 = StatisticalAnalysisUtil
					.removeDuplicateWithOrder(pid);// 将重复数据集合转换成有序不重复集合
			List<String> clientAddress3 = StatisticalAnalysisUtil
					.removeDuplicateWithOrder(clientAddress2);//
			int flag = pid3.size();
			double ratio = ((double) flag / (double) amount1.size()) * 100;
			String Ratio = StatisticalAnalysisUtil.getAfterTwo(ratio);
			clientInfoSituation.setInspectionRate(Ratio);
			// 样品数量
			clientInfoSituation.setInspectionNumber(flag);
			// 客户地址
			clientInfoSituation.setAddress(clientAddress3.get(0));
			list1.add(clientInfoSituation);
		}
		return list1;
	}
}
