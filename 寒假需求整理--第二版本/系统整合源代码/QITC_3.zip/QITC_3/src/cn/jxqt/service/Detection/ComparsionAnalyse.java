package cn.jxqt.service.Detection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.web.exception.ErrorException;
import org.web.service.QueryService;

import cn.jxqt.util.ManangerUtil;
import cn.jxqt.vo.Hazards;
import cn.jxqt.vo.TestResult;
import cn.jxqt.vo.statisticsalaysis.ComparisonInfor;

/**
 * 
 * @author Administrator
 *	农药残留检出水平与最大残留限量标准对比分析情况
 */
public class ComparsionAnalyse extends AbstractDetection{
	
	private ManangerUtil manager;
	
	public ComparsionAnalyse(ManangerUtil manager)  {
		this.manager = manager;
	}
	
	public List<ComparisonInfor> getDectionCheckLimitedLibrary(String[] selects) {
		List<ComparisonInfor> cis = null;
		try {
			cis = new ArrayList<ComparisonInfor>();
			QueryService query = new QueryService("Hazards");
			Hazards hazards = new Hazards();
			Set<String> mbrNames = manager.getMbrNames();		//得到不重复的危害物
			Map<String, String> resultMap = new HashMap<String, String>();
			List<TestResult> checkOutYs = manager.getCheckOutY();
			Set<String> diffCheckOut = new HashSet<String>();
			for(int i=0; i<checkOutYs.size(); i++) {
				TestResult testResult = checkOutYs.get(i);
				diffCheckOut.add(testResult.getP_name() + " " + testResult.getMbr_cname() + " " + testResult.getTest_reasult());	//	不重复的产品名称危害物名称和检测值的set空格隔开
			}
			for(int i=0; i<selects.length; i++) {		//循环所有的标准				
				String staName = selects[i];
				Iterator<String> it = mbrNames.iterator();
				while(it.hasNext()) {
					String mbrName = it.next();
					hazards.setMbr_cname(mbrName);
					hazards.setB_name(selects[i]);
					List<Object> queryList = query.getResult(hazards, null);
					if(queryList.size() != 0) {
						Hazards resultHazards = (Hazards) queryList.get(0);
						resultMap.put(hazards.getMbr_cname() + selects[i], resultHazards.getLimited());		//用危害物和标准为key，限量值为value
					} else {
						hazards.setMbr_cname(null);		//清除上面的影响
						hazards.setP_name(mbrName);
						hazards.setB_name(selects[i]);
						queryList = query.getResult(hazards, null);
						if(queryList.size() != 0) {
							Hazards resultHazards = (Hazards) queryList.get(0);
							resultMap.put(hazards.getMbr_cname() + selects[i], resultHazards.getLimited());
						}
						hazards.setP_name(null);	//消除影响
					}
				}
			}
			
			//比较检测的值和危害物限量库中值的大小，判断是否超标
			
			Iterator<String> everDiffCheckOut = diffCheckOut.iterator();	//遍历每个检出的产品
			ComparisonInfor ci = new ComparisonInfor();
			ComparisonInfor comparison = null;
			
			while(everDiffCheckOut.hasNext()) {
				String[] items = everDiffCheckOut.next().split(" ");
				comparison = (ComparisonInfor) ci.clone();
				comparison.setPro_name(items[0]);
				comparison.setMbr_cname(items[1]);
				comparison.setResult(items[2]);
				double testValue = Double.parseDouble(items[2]);
				List<String> InforList = new ArrayList<String>();
				for(int j=0; j<selects.length; j++) {
					String limited = resultMap.get(items[1] + selects[j]);
					if(limited != null) {
						limited = limited.trim();
						String Tesmplimited = limited.split("mg/kg")[0];
						double limit = 0;
						if(Tesmplimited.contains("*")) {
							limit = Double.parseDouble(Tesmplimited);
						} else {
							limit = Double.parseDouble(Tesmplimited);
						}
						if (limit < testValue) {
							InforList.add(limited);
							InforList.add("是");
						} else {
							InforList.add(limited);
							InforList.add("否");
						}
					} else {
						InforList.add(" ");
						InforList.add(" ");
					}
					comparison.setList(InforList);
System.out.println("limited" + limited);
				}
				cis.add(comparison);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		return cis;
	}
}
