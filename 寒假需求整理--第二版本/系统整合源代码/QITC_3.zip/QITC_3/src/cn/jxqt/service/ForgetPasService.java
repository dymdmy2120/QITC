package cn.jxqt.service;

import java.util.List;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.exception.ErrorException;

import cn.jxqt.po.User;

public class ForgetPasService {
	public ForgetPasService(){
	}
	
	public User retrievePassword(User user) throws ErrorException{
		User retUser = null;
		String errorInfo = null;
		try {
			DaoAdvice sd = DaoAdviceFactory.getDao("User");
			List<Object> list = sd.query(User.class, user, null, false);
			if(list.size() == 1){
				retUser = (User)list.get(0);
				if(retUser.getPspb1() == null){
					errorInfo = "您没有设置密保，无法使用此功能！";
				}
			}else{
				errorInfo = "用户名不存在！";
			}
		} catch (Exception e) {
		}
		if(errorInfo != null){
			throw new ErrorException(errorInfo);
		}
		return retUser;
	}
}
