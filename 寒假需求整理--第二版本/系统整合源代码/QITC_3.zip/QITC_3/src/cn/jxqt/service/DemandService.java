package cn.jxqt.service;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.dao.core.support.Page;
import org.web.exception.BeanInitializationException;
import org.web.exception.DBException;
import org.web.exception.ErrorException;
import org.web.service.QueryService;
import org.web.util.ExceptionUtil;

import tool.mastery.log.Logger;

public class DemandService extends QueryService {

	public static final Logger LOG = Logger.getLogger(DemandService.class);
	
	private String key;

	private String paramName;

	private List<Object> allList;

	public DemandService(String name, boolean flag, String paramName,
			String paramValue) {
		super(name, flag);
		this.paramName = paramName;
		this.key = name + paramValue;
		if(paramValue == null) {
			this.key = name;
		}else {
			this.key = name + paramValue;
		}
		allList = valueMap.get(key);
	}

	@Override
	protected List<Object> getList(Object vo, Page page, Class<?> voClass)
			throws ErrorException, BeanInitializationException {
		List<Object> list = null;
		// 如果是第一页则进行查询
		if (page.getPage() == 1) {
			try {
				DaoAdvice sd = DaoAdviceFactory.getDao(name);
				list = processList(sd.query(voClass, vo, page, flag));
			} catch (DBException e) {
				throw ExceptionUtil.initNewCause(e,
						new ErrorException(e.getMessage()));
			}
			allList = list;
			try {
				boolean flag = false;
				if(vo != null) {
					Field[] fields = vo.getClass().getDeclaredFields();
					for (Field field : fields) {
						String fieldName = field.getName();
						if (fieldName.equalsIgnoreCase(paramName)) {
							continue;
						}
						Object value = PropertyUtils.getProperty(vo, fieldName);
						if (value == null) {
							flag = true;
						} else {
							flag = false;
							break;
						}

					}
				}
				
				if (flag || vo == null) {
					valueMap.put(key, allList);
				}
			} catch (Exception e) {
			}
		} else {
			// 如果不是第一页则直接使用以前的查询结果
			list = allList;
		}
		page.setCount(allList.size());
		return list;
	}

	public static List<Object> getAllList(String name) {
		return valueMap.get(name);
	}

	protected static final Map<String, List<Object>> valueMap = new HashMap<String, List<Object>>();
}
