package cn.jxqt.service.Detection;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

import cn.jxqt.util.ManangerUtil;
import cn.jxqt.util.StatisticalAnalysisUtil;
import cn.jxqt.vo.TestResult;
import cn.jxqt.vo.statisticsalaysis.DetectionVarieties;

public class DectionVarietiesOrAmount extends AbstractDetection{
	private ManangerUtil manger;
	public  DectionVarietiesOrAmount(ManangerUtil manger){
		   this.manger=manger;
	   }
	@Override
	public List<DetectionVarieties> getDectionVarietiesOrAmount() {
		// 开始统计算法：
		List<DetectionVarieties> list1 = new ArrayList<DetectionVarieties>();// 将多个检测结果数存放在这个双重list集合并返回
		List<String> CateGory1 = StatisticalAnalysisUtil
				.removeDuplicateWithOrder(manger.getCateGory());// 将重复有顺序的数据转换成有顺序不重复的集合
		List<String> Pid = StatisticalAnalysisUtil
				.removeDuplicateWithOrder(manger.getPID());// 将重复有顺序的数据转换成有顺序不重复的集合
		int CateGory1Size = CateGory1.size();
		DetectionVarieties detectionVarietiesSuper = DetectionVarieties.getInstance();//单利模式
		DetectionVarieties detectionVarieties=null;
		for (int category1 = 0; category1 < CateGory1Size; category1++) {// 一个类别对应多个样品，一个样品对应多个检测项目，用三循环达到一对多的关系
			String category = CateGory1.get(category1);
			List<String> inspection_id25 = new ArrayList<String>();
			List<String> inspection_id23 = new ArrayList<String>();
			List<String> inspection_id = new ArrayList<String>();
			List<String> sampleNumber = new ArrayList<String>();
			List<String> sampleNumber23 = new ArrayList<String>();
			List<String> sampleNumber25 = new ArrayList<String>();
			for (List<String> bname1 : manger.getbName()) {
				if (category.equalsIgnoreCase(bname1.get(0))
						&& bname1.get(1).indexOf("25") == 0) {
					inspection_id25.add(bname1.get(1));
					sampleNumber25.add(bname1.get(2));
				}
				if (category.equalsIgnoreCase(bname1.get(0))
						&& bname1.get(1).indexOf("23") == 0) {
					inspection_id23.add(bname1.get(1));
					sampleNumber23.add(bname1.get(2));
				}
			}
			detectionVarieties = (DetectionVarieties) detectionVarietiesSuper
					.clone();
			detectionVarieties.setCategory(category);
			int TestingNumber23 = inspection_id23.size();
			int TestingNumber25 = inspection_id25.size();
			int TestingNumber =  manger.getTestResaultSize() - TestingNumber23
					- TestingNumber25;

			List<String> SampleNumber25 = StatisticalAnalysisUtil
					.removeDuplicateWithOrder(sampleNumber25);// 将重复数据集合转换成有序不重复集合
			List<String> SampleNumber23 = StatisticalAnalysisUtil
					.removeDuplicateWithOrder(sampleNumber23);// 将重复数据集合转换成有序不重复集合
			int SampleNumber = Pid.size() - SampleNumber25.size()
					- SampleNumber23.size();
			detectionVarieties.setSampleNumber(SampleNumber);
			detectionVarieties.setSampleNumber23(SampleNumber23.size());
			detectionVarieties.setSampleNumber25(SampleNumber25.size());
			// 检测项目数
			detectionVarieties.setTestingNumber(TestingNumber);
			detectionVarieties.setTestingNumber23(TestingNumber23);
			detectionVarieties.setTestingNumber25(TestingNumber25);
			list1.add(detectionVarieties);
//			list.clear();
		}
		return list1;
	}
}
