package cn.jxqt.service.backups;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.web.exception.ErrorException;

import cn.jxqt.util.dynamo.IBackups;

public class AutoBackupsService extends AbstractBackupsService  {
  private Date  date; //自动备份的时间
  private long period = 1000 * 60 *60*24;//定时的间隔时间(默认一天)
	public AutoBackupsService() {
		super();
	}

	public AutoBackupsService(IBackups handle) {
		super(handle);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean handleBack(final String sourcePath, final String destPath) throws ErrorException {
		boolean retFlag = false;
		Timer time = new Timer();
		
		TimerTask task = new TimerTask() {
			
			@Override
			public void run() {
				
				try {
					
					boolean retFlag = hand(sourcePath, destPath);
				} catch (ErrorException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		};
		time.schedule(task, date,period);
		return retFlag;
	}
	
	/**
	 * 得到当前系统时间
	 * @return 当前系统时间
	 */
	private Date getCurrentTime() {
		
		return new Date();
	}
	/**
	 * 设置要进行备份的时间
	 * @param date
	 * @param period //每隔多长时间进行备份(默认一天)
	 */
	public void setBackupsTime(Date date,Long period) {
		
		this.date = date;
		this.period = period;
	}

	
}
