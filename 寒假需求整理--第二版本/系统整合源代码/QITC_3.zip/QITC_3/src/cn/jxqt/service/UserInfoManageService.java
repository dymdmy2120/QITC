package cn.jxqt.service;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.exception.BeanInitializationException;
import org.web.exception.DBException;
import org.web.exception.ErrorException;

import cn.jxqt.po.User;

public class UserInfoManageService {
	public UserInfoManageService() throws BeanInitializationException{
		
	}
	
	public User execute( User user ) throws ErrorException, BeanInitializationException {
		DaoAdvice sd = DaoAdviceFactory.getDao("User");
		User retUser = null;
		try {
			sd.update(user);
			
			retUser = (User)sd.get(user);
		} catch (DBException e) {
			throw new ErrorException("操作失败！");
		}
		return retUser;
	}
	
}
