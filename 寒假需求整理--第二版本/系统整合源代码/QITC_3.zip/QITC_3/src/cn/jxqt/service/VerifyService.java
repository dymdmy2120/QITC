package cn.jxqt.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.web.access.factory.DaoAdviceFactory;
import org.web.access.factory.OperateServiceExecuteAdviceFactory;
import org.web.dao.annotation.Util;
import org.web.dao.core.DaoAdvice;
import org.web.dao.core.support.Page;
import org.web.exception.DBException;
import org.web.exception.ErrorException;
import org.web.service.OperateServiceExecuteAdvice;

import tool.mastery.core.CollectionUtil;
import tool.mastery.log.Logger;
import cn.jxqt.dao.file.FileSystem;
import cn.jxqt.po.Audit;
import cn.jxqt.po.User;
import cn.jxqt.vo.FileVo;
import cn.jxqt.vo.FileVoHelper;

/**
 * 审核service
 * 
 * @author mastery
 * 
 */
public class VerifyService {

	public static final Logger LOG = Logger.getLogger(VerifyService.class);

	private String viewName;

	private FileSystem fs;

	public VerifyService(String viewName, String category)
			throws ErrorException {
		this.viewName = viewName;
		if (category == null) {
			category = "";
		}
		try {
			fs = FileSystem.load(this.viewName + category);
		} catch (IOException e) {
			e.printStackTrace();
			throw new ErrorException(e.getMessage());
		}

	}

	/**
	 * 此处是用户提交的操作时调用的service方法
	 * 
	 * @return boolean值
	 */
	public void commitVerify(List<Object> list, String operate, User user,
			String reason) throws ErrorException {
		try {
			List<FileVo> listFileVo = this.wrapObject(list, operate, user,
					reason);
			if (listFileVo == null || listFileVo.size() == 0) {
				throw new ErrorException("需要操作的数据不存在！");
			}
			// 保存vo对象
			for (int i = 0; i < listFileVo.size(); i++) {
				FileVo fileVo = listFileVo.get(i);
				// 查询出此数据是否存在，若存在且执行的操作为添加时，不让其做插入！
				if (fileVo.getOperate().equals(FileVoHelper.ADD)
						&& fs.contains(fileVo)) {
					continue;
				}
				fs.save(fileVo);
			}
		} catch (IOException e) {
			throw new ErrorException("数据保存失败，请重新操作！");
		}
		fs.stopWrite();
	}

	/**
	 * 封装对象到FileVo中用于提交审核
	 * 
	 * @param list
	 * @param viewName
	 * @param operate
	 * @param fileObjectManager
	 * @return
	 * @throws IOException
	 */
	private List<FileVo> wrapObject(List<Object> list, String operate,
			User user, String reason) throws IOException {
		List<FileVo> fileVoList = new ArrayList<FileVo>(list.size());
		FileVo fileVo = null;
		for (int i = 0; i < list.size(); i++) {
			fileVo = new FileVo();
			fileVo.setVo(list.get(i));
			fileVo.setFileVoId(FileVoHelper.getCurrentId(fs));
			fileVo.setOperate(FileVoHelper.changeOperateToChinese(operate));
			fileVo.setReason(reason);
			fileVo.setTime(new Date());
			fileVo.setU_id(user.getU_id());
			fileVo.setU_name(user.getU_name());
			fileVoList.add(fileVo);
		}
		return fileVoList;
	}

	/**
	 * 此处是对在数据审核处提交的servlet调用的方法
	 * 
	 * @param verifyOperate
	 * @param ids
	 * @return
	 */
	public void verify(List<FileVo> listFileVo, String verifyInfo,
			boolean isAgree) throws ErrorException {
		List<FileVo> deleteFileVoList = null;
		try {
			// 将对应的数据删除
			deleteFileVoList = fs.delete(listFileVo);
			
		} catch (IOException e) {
			LOG.debug(e);
			throw new ErrorException("数据审核失败！");
		}
		fs.stopWrite();
		// 实例化审核po
		Audit audit = new Audit();
		// 用于存储添加出错的信息
		List<String> info = new ArrayList<String>();
		DaoAdvice dao = DaoAdviceFactory.getDao("Audit");
		// 若审核信息不存在，则证明为审核通过
		if (isAgree) {
			Util util = new Util();
			OperateServiceExecuteAdvice service = OperateServiceExecuteAdviceFactory
					.getService(viewName);
			List<Object> voList = new ArrayList<Object>();
			FileVo fileVo = null;

			for (int i = 0; i < deleteFileVoList.size(); i++) {
				// 先清空此集合
				voList.clear();
				fileVo = deleteFileVoList.get(i);
				LOG.debug("current " + fileVo.getOperate() + "'vo is "
						+ fileVo.getVo());
				voList.add(fileVo.getVo());
				try {
					service.execute(voList, FileVoHelper
							.changeOperateToEnglish(fileVo.getOperate()));
				} catch (ErrorException e) {
					e.printStackTrace();
					// 如果此处抛出异常，则认为数据未审核成功，
					verifyInfo = "第" + (i + 1) + "条数据审核失败，已自动为你提交未通过，错误信息为："
							+ e.getMessage() + "；";
					info.add(verifyInfo);
					continue;
				}
				// TODO 下一步是将审核信息添加到审核表中，反馈给用户
				verifyInfo = "恭喜您，用户" + fileVo.getU_name() + "在"
						+ util.transferDateToString(fileVo.getTime()) + "提交的数据"
						+ fileVo.getOperate() + "成功！";
				addAudit(verifyInfo, dao, audit, fileVo);
			}

		} else {
			for (int i = 0; i < deleteFileVoList.size(); i++) {
				addAudit(verifyInfo, dao, audit, deleteFileVoList.get(i));
			}
		}
		if (info.size() != 0) {
			String message = "";
			for (int i = 0; i < info.size(); i++) {
				message += info.get(i);
			}
			throw new ErrorException(message);
		}
	}

	public List<FileVo> getVerifyData(FileVo fileVo, Page page){
		List<FileVo> list = null;
		try {
			if (fileVo != null && fileVo.getFileVoId() != 0) {
				list = CollectionUtil.convertObjectToList(fs
						.query(fileVo));
				fs.stopRead();
			} else {
				list = new ArrayList<FileVo>();
				List<FileVo> listAllData = fs.getList();
				fs.stopRead();
				if (page == null) {
					return listAllData;
				}
				page.setCount(listAllData.size());
				for (int i = 0; i < listAllData.size(); i++) {
					if (i >= page.getFirstIndex()
							&& i < page.getFirstIndex() + page.getMaxSize()) {
						list.add(listAllData.get(i));
					}
				}
			}
		} catch (IOException e) {
			LOG.debug(e);
		}
		return list;
	}

	/**
	 * 将操作的数据添加到审核表中
	 * 
	 * @param verifyInfo
	 * @param addService
	 * @param audit
	 * @param fileVo
	 * @throws ErrorException
	 */
	private void addAudit(String verifyInfo, DaoAdvice dao, Audit audit,
			FileVo fileVo) throws ErrorException {
		audit.setU_id(fileVo.getU_id());
		// audit.setU_id("123");
		audit.setAudit_info(verifyInfo);
		// 将审核对象添加到数据库
		try {
			dao.save(audit);
		} catch (DBException e) {
			throw new ErrorException("保存审核信息失败！", e);
		}
	}

}
