package cn.jxqt.service.Detection;

import cn.jxqt.vo.statisticsalaysis.ClientInfoKeyVo;
import cn.jxqt.vo.statisticsalaysis.DatectionSampleKeyVo;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmountKeyVo;
import cn.jxqt.vo.statisticsalaysis.DetectionVarietiesKeyVo;

public interface FatherKey {
//客户分布情况关键字
	public ClientInfoKeyVo getClientInforKey();
//受检样品数量与项次数
	public DetectionVarietiesKeyVo getDectionVarietiesOrAmountKey();
//	样品检出情况
	public DatectionSampleKeyVo getDectionSampleOr25Key();
//	检测方法使用种类及频次
	public DectionMethodAmountKeyVo getDectionMethodOrAmountKey();
}
