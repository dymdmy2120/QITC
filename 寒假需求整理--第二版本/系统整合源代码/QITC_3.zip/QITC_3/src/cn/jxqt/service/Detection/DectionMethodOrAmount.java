package cn.jxqt.service.Detection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.text.StyledEditorKit.ItalicAction;

import cn.jxqt.util.ManangerUtil;
import cn.jxqt.util.StatisticalAnalysisUtil;
import cn.jxqt.vo.TestResult;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmount;
import cn.jxqt.vo.statisticsalaysis.DetectionKey;

public class DectionMethodOrAmount extends AbstractDetection{
	   private ManangerUtil manger;
		public  DectionMethodOrAmount(ManangerUtil manger){
			   this.manger=manger;
		   }
	private List<DectionMethodAmount> getDectionMethodOrAmount1() {
		// TODO Auto-generated method stub
		List<DectionMethodAmount> list1 = new ArrayList<DectionMethodAmount>();
		// 对检测方法进行排序不重复处理
		List<String> amountMethod1 = StatisticalAnalysisUtil
				.removeDuplicateWithOrder(manger.getAmountMethod());
		DectionMethodAmount dectionMethodAmountSuper =  DectionMethodAmount.getInstance();
		DectionMethodAmount dectionMethodAmount = null;
		// 得到单个检测方法的使用频次
		int amountMehodSize = amountMethod1.size();
		for (int i = 0; i < amountMehodSize; i++) {
			List<String> amount = new ArrayList<String>();
		    Iterator it = manger.getMap1().entrySet().iterator();
		        while(it.hasNext()){
		        	Map.Entry<String, String> entry = (Entry<String, String>) it.next();
		        	if(amountMethod1.get(i).equalsIgnoreCase(entry.getKey())){
						String date = entry.getValue().substring(0).split(" ")[0];
						amount.add(date);
					}
		        }
			List<String> amount1 = StatisticalAnalysisUtil
					.removeDuplicateWithOrder(amount);
			// 检测方法种类
			dectionMethodAmount = (DectionMethodAmount) dectionMethodAmountSuper
					.clone();
			dectionMethodAmount.setDetectionMethod(amountMethod1.get(i));
			dectionMethodAmount.setMethodNumber(amount1.size());
			list1.add(dectionMethodAmount);
		}
		return list1;

	}
	@Override
	public List<DectionMethodAmount> getDectionMethodOrAmount(){
		List<DectionMethodAmount> list1 = new ArrayList<DectionMethodAmount>();
		List<DectionMethodAmount> list = this.getDectionMethodOrAmount1();
		int listSize = list.size();
		int flag = 0;
		for(int i=0;i<listSize;i++){
			flag  = flag+list.get(i).getMethodNumber();
		}
		DectionMethodAmount dectionMethodAmountSuper =  DectionMethodAmount.getInstance();
		DectionMethodAmount dectionMethodAmount = null;
		for(int j=0;j<listSize;j++){
			dectionMethodAmount = (DectionMethodAmount) dectionMethodAmountSuper
					.clone();
			dectionMethodAmount.setDetectionMethod(list.get(j).getDetectionMethod());
			dectionMethodAmount.setMethodNumber(list.get(j).getMethodNumber());
			int amountNumber1 = list.get(j).getMethodNumber();
		    double ratio = ((double) amountNumber1 / (double) flag) * 100;
			String Ratio = StatisticalAnalysisUtil.getAfterTwo(ratio);
			dectionMethodAmount.setMethodRate(Ratio);
			list1.add(dectionMethodAmount);
		}
		return list1; 
	}

}
