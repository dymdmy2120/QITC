package cn.jxqt.service.login;

import java.util.List;

import org.web.access.factory.DaoAdviceFactory;
import org.web.dao.core.DaoAdvice;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;

import cn.jxqt.po.Admin;
import cn.jxqt.po.User;
import cn.jxqt.util.MD5Util;

public class LoginHandler extends Handler{
	@Override
	public User respone(String operation, User user) throws ErrorException, BeanInitializationException {
		if(user.getPassword() != null){
			user.setPassword(MD5Util.EncoderByMd5(user.getPassword()));
		}
		if(operation.equals("userLogin")){
			return this.userLogin(user);
		}
		if(operation.equals("adminLogin")){
			return this.adminLogin(user);
		}
		if(this.getNextHandler() != null){
			return this.getNextHandler().respone(operation, user);
		}else{
			System.out.println("无处理器=====");
		}
		return null;
	}
	
	private User userLogin(User user) throws ErrorException {
		return this.findUser(user);
	}
	
	private User adminLogin(User user) throws ErrorException {
		Admin admin = new Admin();
		admin.setU_id(user.getU_id());
		admin.setPassword(user.getPassword());
		Admin retAdmin = this.findAdmin(admin);
		if(retAdmin == null){
			throw new ErrorException("系统不存在该用户！");
		}
		User retUser = new User();
		retUser.setU_id(retAdmin.getU_id());
		retUser.setPassword(retUser.getPassword());
		
		return retUser;
	}
	
	private Admin findAdmin(Admin admin){
		Admin retAdmin = null;
		try {
			DaoAdvice sd = DaoAdviceFactory.getDao("Admin");
			List<Object> list = sd.query(Admin.class, admin, null, false);
			if(list.size()> 0){
				retAdmin = (Admin)list.get(0);
			}
		} catch (Exception e) {
		}
		return retAdmin;
	}
	
}
