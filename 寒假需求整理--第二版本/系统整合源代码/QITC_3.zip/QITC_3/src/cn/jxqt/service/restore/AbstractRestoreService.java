package cn.jxqt.service.restore;

import org.web.exception.ErrorException;

import cn.jxqt.util.dynamo.DataBaseRestore;
import cn.jxqt.util.dynamo.IRestore;


public abstract class AbstractRestoreService {

	protected IRestore handle;

	/**
	 * 默认的恢复内容(恢复数据库文件)
	 */
	public AbstractRestoreService() {

		this.handle = new DataBaseRestore();
	}

	public AbstractRestoreService(IRestore handle) {

		this.handle = handle;
	}

	/**
	 * @param sourcePath 要进行还原的文件的原路径
	 * @param destPath   还原后解压文件后的路径
	 * @return
	 * @throws ErrorException
	 */
	public boolean handleRestore(String sourcePath, String destPath) throws ErrorException {

		return handle.restore(sourcePath, destPath);
	}

}
