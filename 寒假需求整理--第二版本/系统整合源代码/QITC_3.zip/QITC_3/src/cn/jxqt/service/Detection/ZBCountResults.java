package cn.jxqt.service.Detection;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import cn.jxqt.util.ExcelException;
import cn.jxqt.util.ExcelToDbUtil;
import cn.jxqt.util.QuickSortUtil;
import cn.jxqt.vo.TestResult;
import cn.jxqt.vo.statisticsalaysis.CountData;
import cn.jxqt.vo.statisticsalaysis.ZBTest;

public class ZBCountResults extends AbstractDetection{
	private ExcelToDbUtil etd = null;
	private List<Object> testReasultList = null;
	private Set<String> PnameSetIsZB = new HashSet<String>();				//自报
	private Set<String> PnameSetNotZB = new HashSet<String>();				//非自报
	private Map<String,ZBTest> tableZB = new HashMap<String,ZBTest>();		//自报表格
	private Map<String,ZBTest> tableNotZB = new HashMap<String,ZBTest>();	//非自报表格
	
	private Set<String> pnameSetAll = new HashSet<String>();				//涉及所有农药名称；
	private Set<String> testOutPnameAll = new HashSet<String>();			//所有不合格农药
	private Map<String,Integer> testOutAll = new HashMap<String,Integer>();	//所有检测出不合格农药的名称及频次
	private CountData redKeyword = new CountData();							//概括文字段的红色关键字；
	
	/**
	 * 最后获取自报检表格和非自报检表格方法为：
	 * public List<ZBTest> getTableZB()；
	 * public List<ZBTest> getTableNotZB()；
	 **/
	
	public ZBCountResults(String filePath){
		etd = new ExcelToDbUtil();
		try {
			this.testReasultList = etd.getAllByExcel("TestResasult", filePath);
		} catch (ExcelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.scanExcel();
	}
	
	public ZBCountResults(List<Object> testReasultList){
		this.testReasultList = testReasultList;
		this.scanExcel();
	}

	private void scanExcel(){
		TestResult testReasult = null;
		ZBTest zbTestSuper = new ZBTest();
		ZBTest	zbTest=null;
		for(Object obj : testReasultList){
			testReasult = (TestResult)obj;
			pnameSetAll.add(testReasult.getMbr_cname());
			if(itemIsZB(testReasult.getInspection_id())){									//是自报检
				if(PnameSetIsZB.add(testReasult.getMbr_cname())){							//是否已经记录过；
					zbTest = (ZBTest) zbTestSuper.clone();
					zbTest.setName(testReasult.getMbr_cname());
					tableZB.put(testReasult.getMbr_cname(), zbTest);
					changItem(zbTest,testReasult.getEvaluation(),testReasult.getMbr_cname());
				}else{
					zbTest = tableZB.get(testReasult.getMbr_cname());
					changItem(zbTest,testReasult.getEvaluation(),testReasult.getMbr_cname());
				}
			}else{																			//非自报检
				if(PnameSetNotZB.add(testReasult.getMbr_cname())){
					zbTest = (ZBTest) zbTestSuper.clone();
					zbTest.setName(testReasult.getMbr_cname());
					tableNotZB.put(testReasult.getMbr_cname(), zbTest);
					changItem(zbTest,testReasult.getEvaluation(),testReasult.getMbr_cname());
				}else{
					zbTest = tableNotZB.get(testReasult.getMbr_cname());
					changItem(zbTest,testReasult.getEvaluation(),testReasult.getMbr_cname());
				}
			}
		}
	}
	private List<ZBTest> getZBCountResult(Map<String, ZBTest> resultMap) {
		List<ZBTest> countList = new ArrayList<ZBTest>();
		ZBTest item = null;
		String strOutPercent = null;
		String outPercent = null;
		
		Set<Entry<String, ZBTest>> set = resultMap.entrySet();
		Iterator<?> itor = set.iterator();
		Entry<String, ZBTest> entry = null;
		while (itor.hasNext()) {
			entry = (Entry<String, ZBTest>) itor.next();
			item = entry.getValue();
			//if(item.getTestOutCounts()>0){
				float testOutPercent = item.getTestOutCounts() / item.getTypeCounts() * 100;
				strOutPercent = String.valueOf(testOutPercent);
				outPercent = "0"; // 检测比率；
				if (strOutPercent.length() > 5) {
					outPercent = strOutPercent.substring(0, 5);
				} else {
					outPercent = strOutPercent;
				}
				item.setTestOutPercent(outPercent);
				countList.add(item);
			//}
		}
		return countList;
	}
	private boolean itemIsZB(String inspection_id){
		boolean result = false;
		if (inspection_id == null) {
		} else {
			result = inspection_id.startsWith("25");
		}
		return result;
	}
	
	private void changItem(ZBTest it, String evaluation,String Mbr_cname){
		it.setTypeCounts(it.getTypeCounts() + 1);
		if ("检出".equals(evaluation) || "阳性".equals(evaluation)) {
			it.setTestOutCounts(it.getTestOutCounts() + 1);
			//this.redKeyword.setTestOutTimes(this.redKeyword.getTestOutTimes()+1);//检测农药的总频次
			this.testOutPnameAll.add(Mbr_cname);
		}
	}
	
	public List<ZBTest> getTableZB() {
		return getZBCountResult(tableZB);
	}

	public List<ZBTest> getTableNotZB() {
		return getZBCountResult(tableNotZB);
	}
	public CountData getReadKeyword(){
		this.redKeyword.setTimes(this.testReasultList.size());//农药检测总频次
		this.redKeyword.setKind(pnameSetAll.size());//检测农药残留物种类数量；
		this.redKeyword.setTestOutKind(this.testOutPnameAll.size());//检测出不合格农药种类数目；
		
		List<ZBTest> zb = this.getTableZB();
		List<ZBTest> notzb = this.getTableNotZB();
		for(ZBTest objZB : zb){
			this.redKeyword.setTestOutTimes(this.redKeyword.getTestOutTimes()+(int)objZB.getTestOutCounts());
		}
		for(ZBTest objNotZB : notzb){
			this.redKeyword.setTestOutTimes(this.redKeyword.getTestOutTimes()+(int)objNotZB.getTestOutCounts());
		}
		
		Iterator<String> i = this.testOutPnameAll.iterator();//先迭代出来
		String name = null;
		float a,b;int sum;
		List<ZBTest> list = new ArrayList<ZBTest>();
		ZBTest temp = null;
		while(i.hasNext()){
			name = i.next();
			try{
				a = this.tableNotZB.get(name).getTestOutCounts();
			}catch(Exception e){
				a = 0;
			}
			try{
				b = this.tableZB.get(name).getTestOutCounts();
			}catch(Exception e){
				b = 0;
			}
			sum = (int)(a + b);
			temp = new ZBTest(name);
			temp.setTestOutCounts(sum);
			list.add(temp);
		}
		list = QuickSortUtil.anyProperSort4(list, "testOutCounts", true);
		String[] firstFive = new String[5];
		int listSize = 0;
		if(list.size()>=5){
			firstFive = new String[5]; 
			listSize = 5;
		}else{
			firstFive = new String[list.size()];
			listSize = list.size();
		}
		for(int j = list.size() -1,n = 0 ;  j >= list.size() - listSize; j--,n++ ){
//			System.out.println(list.get(j));
			firstFive[n] = list.get(j).getName();
		}
		this.redKeyword.setFirstFive(firstFive);
		this.redKeyword.setFirstTestOutTimes((int)list.get(list.size()-1).getTestOutCounts());
		return this.redKeyword;
	}
}
