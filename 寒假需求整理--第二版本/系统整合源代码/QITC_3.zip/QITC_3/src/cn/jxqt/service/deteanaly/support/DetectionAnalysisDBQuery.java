package cn.jxqt.service.deteanaly.support;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.web.dao.annotation.AnnotationUtil;
import org.web.dao.annotation.Util;
import org.web.exception.DBException;

import cn.jxqt.vo.OperDetectAbility;
import tool.mastery.db.DBUtil;

/**
 * Dao方法中数据库操作的模板类; 包括保存，更新的update(String sql, List<Object> objParams,
 * List<String> paramTypes, boolean flag)throws ErrorException 查询的query(String
 * sql, List<Object> objParams, List<String> paramTypes, Element entityElement,
 * Class<T> entityClass)
 * 
 * @author AntsMarch
 * 
 */
public class DetectionAnalysisDBQuery {

	/**
	 * 设计daoOptemplate类为单例
	 */
	private DetectionAnalysisDBQuery() {
	}

	private static class Optemplate {
		static final DetectionAnalysisDBQuery daoOpt = new DetectionAnalysisDBQuery();
	}

	public static DetectionAnalysisDBQuery getInstance() {
		return Optemplate.daoOpt;
	}

	/**
	 * 通过传入的查询SQL语句和需要查询实体类节点,对应的参数类型来执行数据库查询操作.
	 * 
	 * @param sql
	 * @param entity
	 * @param entityClass
	 * @return List<T> resultList
	 */
	public <T> List<T> query(String sql, Class<T> entityClass) {
		List<T> resultList = null;
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pstm = conn.prepareStatement(sql);

			rs = pstm.executeQuery();

			resultList = convertDataToObject(rs, entityClass);
			if (resultList.size() == 0)
				System.out.println("查询的数据为空！！！");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeDatabase(rs, pstm);
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return resultList;
	}

	/**
	 * 通过传入的查询SQL语句和参数集合,对应的参数类型来执行数据库更新操作！
	 * 
	 * @param sql
	 * @param objParams
	 * @param paramTypes
	 * @param entityElement
	 * @param entityClass
	 * @return List<String> reldata;
	 * @throws DBException
	 */
	public <T> List<T> query(String sql, List<Object> objParams,
			List<String> paramTypes, Class<T> entityClass) throws DBException {
		List<T> reldata = null;
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pstm = conn.prepareStatement(sql);
			if (null == objParams) {

			} else {

				for (int i = 0; i < objParams.size(); i++) {
					SetPreparedStatement.setPreparedStatementByPropertiesType(
							pstm, i + 1, paramTypes.get(i), objParams.get(i));
				}

			}
			rs = pstm.executeQuery();
			
			reldata = convertDataToObject(rs, entityClass);
			
			// System.out.println(reldata.get(0).toString());
			// System.out.println(reldata.size());
			if (reldata.size() == 0) {
				System.out.println("查询的数据为空！！！");

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBUtil.closeDatabase(rs, pstm);
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return reldata;
	}

	private <T> List<T> convertDataToObject(ResultSet rs, Class<T> entityClass)
			throws IllegalArgumentException, SQLException,
			InstantiationException, IllegalAccessException,
			InvocationTargetException, IntrospectionException {
	
		// 检索此ResultSetMetaData对象的列编号、类型和属性
		ResultSetMetaData rsmd = rs.getMetaData();
		// 获取所有列
		int columnCount = rsmd.getColumnCount();
	
		List<T> list = new ArrayList<T>();
		
		// 封装好的类型信息
		Map<String, PropertyDescriptor> beanMap = AnnotationUtil.getInstance()
				.getBeanInfo(entityClass);
		
		while (rs.next()) {
			T bean = entityClass.newInstance();
			
			for (int i = 1; i <= columnCount; i++) {
				// 获取列名
				String columnName = rsmd.getColumnName(i).toLowerCase();
				// 获取列的值
				Object columnValue = rs.getObject(columnName);

				// 获得属性描述对象
				PropertyDescriptor pd = beanMap.get(columnName);
				// 属性数据类型Integer,String,Float,Double(名称)
				String fieldType = pd.getPropertyType().getName();
				// 获取set方法
				Method writerMethod = pd.getWriteMethod();
				if (columnValue != null) {
					// 获取调用set方法的值
					Object args = new Util()
							.typeConvert(columnValue, fieldType);
					// 动态调用实体类的set方法，将值保存到实体类对象中
					try {
						writerMethod.invoke(bean, args);
					} catch (Exception e) {
						continue;
					}
				}
			}
			list.add(bean);
		}
		
		return list;
	}

	// public static final HelpAdvice helpAdvice = new DefaultHelpAdvice();
}
