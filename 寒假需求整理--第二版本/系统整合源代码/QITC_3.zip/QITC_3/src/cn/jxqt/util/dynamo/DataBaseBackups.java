package cn.jxqt.util.dynamo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import org.junit.Test;
import org.web.exception.ErrorException;

import tool.mastery.db.DBUtil;
import cn.jxqt.util.ReadDbProUtil;

/**
 * @author ASUS 对数据库的文件进行备份 destPath 要把数据库文件备份到的地方 backupsName 备份数据库文件的名字
 */
public class DataBaseBackups implements IBackups {
	private String DB_DBName = null;
	private String DB_Password = null;
	private String DB_DataBaseName = null;

	public DataBaseBackups() {

		DB_DBName = ReadDbProUtil.getDB_DBName();
		DB_Password = ReadDbProUtil.getDB_Password();
		DB_DataBaseName = ReadDbProUtil.getDB_DataBaseName();

	}

	public boolean backups(String sourcePath, String destPath) throws ErrorException {
		// TODO Auto-generated method stub
		if(DBUtil.getConnection() == null)
			throw new ErrorException("数据库服务还没开启");
		InputStream in = null;
		InputStreamReader inputStream = null;
		BufferedReader br = null;
		FileOutputStream fout = null;
		OutputStreamWriter writer = null;
		boolean flag = false;
		try {
			// 对所有的表进行加读锁
			// LockDbTableUtil.locktables();
			String tablesName = "t_apt t_bounds t_typical t_userpower t_user t_audit t_dete t_laboratory t_laws t_alarm t_sta t_mbr t_slink t_power t_product ";
			Runtime rt = Runtime.getRuntime();
			// 调用 mysql 的 cmd:
			String bacjTab = "mysqldump -h " + "localhost" + " -u" + DB_DBName
					+ " -p" + DB_Password + " --set-charset=utf8 "
					+ DB_DataBaseName + " ";

			Process child = rt.exec(bacjTab);
			in = child.getInputStream();

			inputStream = new InputStreamReader(in, "utf8");

			String inStr;

			StringBuffer sb = new StringBuffer("");

			String outStr;

			br = new BufferedReader(inputStream);

			while ((inStr = br.readLine()) != null) {

				sb.append(inStr + "\r\n");

			}
			outStr = sb.toString();

			// 要用来做导入用的sql目标文件：

			fout = new FileOutputStream(destPath);

			writer = new OutputStreamWriter(fout, "utf8");

			writer.write(outStr);

			// 注：这里如果用缓冲方式写入文件的话，会导致中文乱码，用flush()方法则可以避免

			writer.flush();
			flag = true;

		} catch (FileNotFoundException e) {

			throw new ErrorException("数据备份文件找不到");
		} catch (Exception e) {

			throw new ErrorException("数据备份失败");
		} finally {
			// 释放读锁
			// LockDbTableUtil.unlock();
			// 别忘记关闭输入输出流
			try {
				if (in != null)
					in.close();
				if (inputStream != null)
					inputStream.close();

				if (br != null)
					br.close();
				if (writer != null)
					writer.close();
				if (fout != null)
					fout.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				throw new ErrorException("数据备份失败");

			}

		}
		return flag;
	}

	@Test
	public void test() throws ErrorException {

		DataBaseBackups data = new DataBaseBackups();
		data.backups("", "F:/data.sql");
		
	}
}
