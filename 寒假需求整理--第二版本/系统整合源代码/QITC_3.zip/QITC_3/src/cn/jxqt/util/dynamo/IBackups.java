package cn.jxqt.util.dynamo;

import org.web.exception.ErrorException;

public interface IBackups {
	
	/**
	 * 备份数据
	 * @param path 具体要备份数据所在的位置
	 * @param destPath 把备份的文件放在哪里
	 * @return
	 * @throws ErrorException 
	 */
	
	public boolean backups(String sourcePath,String destPath) throws ErrorException; 

}
