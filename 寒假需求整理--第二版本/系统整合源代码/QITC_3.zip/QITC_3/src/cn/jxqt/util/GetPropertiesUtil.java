package cn.jxqt.util;


import java.io.InputStream;
import java.util.Properties;
/**
 * 根据传进的vo类名，获取配置文件，读取类在excel中对应的属性
 * @author zxb
 * time:2014/10/10
 */
public class GetPropertiesUtil {
	/**
	 * 根据类名获取属性
	 * @param className
	 * @return
	 */
	public static Properties getPropertiesInfo(String className){
		Properties props = new Properties();
		try {
			InputStream in = GetPropertiesUtil.getInputStream(className);
			props.load(in);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return props;
	}
	/**
	 * 根据类名找到文件
	 * @param className
	 * @return
	 */
	public static InputStream getInputStream(String className){
		InputStream in = null;
		in = GetPropertiesUtil.class.getClassLoader().getResourceAsStream("cn/jxqt/properties/"+className+".properties");
		return in;
	}
}
