package cn.jxqt.util;

import java.io.InputStream;
import java.util.Properties;

import org.junit.Test;

import cn.jxqt.util.dynamo.IBackups;

public class ReadDbProUtil {

	private static Properties prop = new Properties();
	private static String DB_SeverName = null;
	private static String DB_Password = null;
	private static String DB_DBName = null;
	private static String DB_DataBaseName = null;
	private static String URL = null;
	private static String[] urlArray = null;
	static {
		InputStream inPro = null;
		inPro = IBackups.class.getClassLoader().getResourceAsStream(
				"db.properties"); // 读取属性文件
		try {

			prop.load(inPro);
		} catch (Exception e1) {

			System.out.println("ERROR");
		}// 通过输入流对象加载Properties文件

		URL = prop.getProperty("url");
	    urlArray = URL.split("//")[1].split("/");
		System.out.println("static");

	}

	public static String getDB_SeverName() {

		
		return urlArray[0].split(":")[0];
	}

	public static String getDB_Password() {

		return prop.getProperty("password");
	}

	public static String getDB_DBName() {
		return prop.getProperty("username");
	}

	public static String getDB_DataBaseName() {

		return urlArray[1];
	}

	@Test
	public void test() {
		System.out.println(getDB_SeverName());
//		String url = "jdbc:mysql://localhost:3306/qitc";
//		String[] urlArray = url.split("//");
//		urlArray[1].split("/");
//		System.out.println(urlArray.length);
//		for(String ur:urlArray) 
//			System.out.println(ur);

	}

}
