package cn.jxqt.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.jxqt.action.AjaxQueryAction;
import cn.jxqt.action.WorkLoadQueryAction;
import cn.jxqt.vo.WorkLoad;

/**
 * 负责员工工作量统计排序 默认查出全部的
 * 
 * @author Administrator
 * 
 */
public class WorkLoadStatistics {

	private Date end = null, begin = null;
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Calendar cal = Calendar.getInstance();
	List operates = null;
	private Date yearBegin = null, yearEnd = null;
	private String endtime = null;

	/**
	 * 需要统计的起始时间
	 * 
	 * @param endTime
	 */
	public WorkLoadStatistics(List<Object> vos) {

		this.operates = vos;
		String starttime = null; // 开始日期
		String yearStartTime = null, yearEndTime = null;
		String[] times = (String[]) StorageData.getData("qitc");
		if (times == null) { // 前台没有指定查询的时间点 得到当前时间点
								// 作为查询的时间点
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH) + 1;
			int day = cal.get(Calendar.DATE) + 1;
			endtime = year + "-" + month + "-" + day;
			starttime = year + "-" + month + "-00";
		} else {
			starttime = times[0];
			endtime = times[1];
		}
		StorageData.remove("qitc"); // 移除查询信息
		// 得到当前年份开始时间
		String year = starttime.substring(0, starttime.indexOf("-"));
		yearStartTime = year + "-" + 1 + "-00";
		// 得到当前年份的截止比较时间点
		yearEndTime = year + "-" + 12 + "-32"; // 得到的是下年的1月1号

		try {
			begin = sdf.parse(starttime);
			end = sdf.parse(endtime);
			yearBegin = sdf.parse(yearStartTime);
			yearEnd = sdf.parse(yearEndTime);
		} catch (ParseException e) {
			throw new RuntimeException("工作量 查询时间格式不正确 请重新查询!");
		}

	}

	public List statistics() {
		List<WorkLoad> list = new ArrayList<WorkLoad>();
		Map<String, WorkLoad> map = new HashMap<String, WorkLoad>();
		for (int i = 0; i < operates.size(); i++) {

			WorkLoad workload = (WorkLoad) operates.get(i);
			String u_id = workload.getU_id();
			if (!map.containsKey(u_id)) { // 判断是否已经统计过 如果没有统计过就进入循环体

				int[] rtns = find(u_id, operates);
				workload.setYearWorkSize(rtns[1]);
				workload.setMonthWorkSize(rtns[0]);
				workload.setCreatetime(endtime);
				map.put(workload.getU_id(), null);
				list.add(workload);
			}
		}
		// 对查出来的list集合进行排序 按降序进行排序
		Collections.sort(list, new Comparator<WorkLoad>() {
			@Override
			public int compare(WorkLoad o1, WorkLoad o2) {
				return o2.getYearWorkSize() - o1.getYearWorkSize();
			}
		});
		return list;
	}

	/**
	 * 查找集合中 包含 指定workload对象的 且不是登录和注销操作的次数
	 * 
	 * @param workload
	 * @param operates
	 * @return
	 */
	private int[] find(String u_id, List operates) {
		int monthSize = 0, yearSize = 0;
		WorkLoad workload2;
		for (int i = 0; i < operates.size(); i++) {
			workload2 = (WorkLoad) operates.get(i);

			if (workload2.getU_id().equals(u_id)) { // 如果是指定的用户
				String msg = workload2.getLog_msg();

				// 如果包含“登录”、“注销”、在指定时间之间的(包括当天)
				if (msg.indexOf("登陆") == -1 && msg.indexOf("注销") == -1&& msg.indexOf("查看") == -1) {
					String time = workload2.getCreatetime();

					// 得到在指定月份中工作量
					if (isBetweenInMonth(time)) {
						monthSize++;
					}

					// 得到在指定年份中的工作量
					if (isBetweenInCurrentYear(time)) {
						yearSize++;
					}
				}
			}
		}
		int[] rtns = { monthSize, yearSize };
		return rtns;
	}

	/**
	 * 
	 * @param firsTime
	 * @param secondTime
	 * @return
	 * @throws Exception
	 */
	private boolean isBetweenInMonth(String createTime) {
		Date create = null;
		try {
			create = sdf.parse(createTime);
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		}
		return create.after(begin) && create.before(end);
	}

	/**
	 * 
	 * @param firsTime
	 * @param secondTime
	 * @return
	 * @throws Exception
	 */
	private boolean isBetweenInCurrentYear(String Time) {
		Date create = null;
		try {
			create = sdf.parse(Time);
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		}
		return create.after(yearBegin) && create.before(yearEnd);
	}

	public static void main(String[] args) throws ParseException {
		Date date1 = sdf.parse("2015-1-00");
		Date date2 = sdf.parse("2015-5-31");
		Date date3 = sdf.parse("2015-05-12");
	}
}
