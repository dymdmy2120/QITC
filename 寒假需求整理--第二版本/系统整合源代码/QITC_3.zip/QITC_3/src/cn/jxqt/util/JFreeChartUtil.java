package cn.jxqt.util;

import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis3D;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.BarRenderer3D;
import org.jfree.chart.renderer.category.StackedBarRenderer;
import org.jfree.chart.servlet.ServletUtilities;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.TextAnchor;
import org.web.exception.ErrorException;
import cn.jxqt.po.Alarm;
import cn.jxqt.util.dynamo.MethodAnno;

/**
 * 生成柱状图的
 * 
 * 
 * @author dynamo
 * @date 2014-10-2 下午1:56:34
 * @version V1.0
 */
public class JFreeChartUtil {
	/**
	 * 得到某个标题的柱状统计图
	 * 
	 * @param map
	 *            键值是要统计数据的某一列名 例如 预警通报的国家 中国或美国 与之对应的值就是各个国家出现的次数
	 * @param title
	 *            生成的柱状图的标题
	 * @param session
	 *            从控制层传入的session
	 * @return
	 * @return String 返回的是一个存放在服务器下的该柱状图片的路径
	 * @throws IOException
	 */
	// 注：ChartFactory.createBarChart3D()方法需要导入jfreechart.jar和jcommon.jar包
	public static String getPicName(Map<String, Integer> map, String title,
			HttpSession session) throws ErrorException {

		DefaultCategoryDataset dataset = new DefaultCategoryDataset();

		Set<String> set = map.keySet();
		Iterator<String> it = set.iterator();
		while (it.hasNext()) {
			String keyInfor = it.next();
			Integer valueInfor = map.get(keyInfor);
			dataset.addValue(valueInfor, "", keyInfor);
		}
		JFreeChart chart = ChartFactory.createBarChart3D(title, title, "次数",
				dataset, PlotOrientation.VERTICAL, false, false, false);
		TextTitle textTitle = chart.getTitle();
		textTitle.setFont(new Font("黑体", Font.BOLD, 15));

		CategoryPlot plot = chart.getCategoryPlot();
		// 设置横轴标题字体
		plot.getDomainAxis().setLabelFont(new Font("宋体", Font.BOLD, 20));
		plot.getDomainAxis().setCategoryLabelPositions(
				CategoryLabelPositions.UP_90);

		// 设置横轴标记的字体
		plot.getDomainAxis().setTickLabelFont(new Font("宋体", Font.BOLD, 12));
		// 设置横轴标记字体颜色
		plot.getDomainAxis().setTickLabelPaint(Color.black);

		// 设置纵轴标题字体
		plot.getRangeAxis().setLabelFont(new Font("宋体", Font.PLAIN, 14));

		// 设置纵轴标记字体
		NumberAxis3D numberAxis3D = (NumberAxis3D) plot.getRangeAxis();
		numberAxis3D
				.setStandardTickUnits(NumberAxis3D.createIntegerTickUnits());
		numberAxis3D.setTickLabelPaint(Color.black);

		// 设置图例字体
		BarRenderer3D renderer3D = (BarRenderer3D) plot.getRenderer();
		renderer3D.setBaseItemLabelFont(new Font("宋体", Font.PLAIN, 14));
		renderer3D.setSeriesPaint(0, Color.ORANGE);

		StackedBarRenderer renderer = new StackedBarRenderer();
		// 虚线色彩
		plot.setRangeGridlinesVisible(true);
		plot.setRangeGridlinePaint(Color.gray);
		renderer.setItemMargin(0.7);
		
		//显示每个柱的数值，并修改该数值的字体属性  
		renderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());  
		renderer.setBaseItemLabelsVisible(true);  
		  
		//默认的数字显示在柱子中，通过如下两句可调整数字的显示  
		//注意：此句很关键，若无此句，那数字的显示会被覆盖，给人数字没有显示出来的问题  
		renderer.setBasePositiveItemLabelPosition(new ItemLabelPosition(ItemLabelAnchor.OUTSIDE3, TextAnchor.BASELINE_RIGHT));  
		renderer.setItemLabelAnchorOffset(20D); 
		
		
		plot.setRenderer(renderer);
		String picName = null;
		try {
			picName = ServletUtilities.saveChartAsPNG(chart, 1000, 300, null,
					session);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new ErrorException("生成柱状图异常");
		}
		return picName;
	}

	/**
	 * 通过传入一个对象中属性的值 根据该属性值和Alarm上的注解调用相应的get方法返回一个Alarm对象中相应的属性值
	 * 
	 * @param c
	 *            Alarm的字节码
	 * @param field
	 *            是要得到alarm中对象的某个属性字段
	 * @return
	 * @return String 返回的是一个对象中某个属性的值
	 */
	public static Object getFieldValue(Class<Alarm> c, Alarm alarm, String field)
			throws ErrorException {
		Object retVal = null;
		Method[] methods = c.getMethods();
		for (Method method : methods) {
			if (method.isAnnotationPresent(MethodAnno.class)) {
				MethodAnno anno = method.getAnnotation(MethodAnno.class);

				if (field.equals(anno.value())) {
					try {
						retVal = method.invoke(alarm, null);

					} catch (Exception e) {
						throw new ErrorException("方法异常");
					}
				}

			}

		}
		return retVal;

	}

	public static void main(String[] atgs) throws ErrorException {
		Alarm alarm = new Alarm();
		alarm.setMbrsort("fd");
		String field = (String) JFreeChartUtil.getFieldValue(
				Alarm.class, alarm, "mbrsort");
		System.out.println(field);
	}

}
