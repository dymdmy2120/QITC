package cn.jxqt.util.dynamo;

import java.io.IOException;

import org.web.exception.ErrorException;

import cn.jxqt.util.ZipUtil;

/**
 * @author ASUS 对文件还原
 * 
 */
public class FileRestore implements IRestore {
	private static ZipUtil zipUtil = new ZipUtil();// 对文件进行解压和压缩工具类

	public boolean restore(String sourcePath, String destPath ) throws ErrorException {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			// zipUtil.UnZIP(path+"JxQtData/upload/"+uploadName,path);
			zipUtil.UnZIP(sourcePath, destPath);
			//得到还原后的文件夹路径
			flag = true;
		} catch (IOException e) {  
			flag = false;
			throw new ErrorException("上传的文件格式不正确,请上传zip压缩文件!");
		}

		return flag;
	}

}
