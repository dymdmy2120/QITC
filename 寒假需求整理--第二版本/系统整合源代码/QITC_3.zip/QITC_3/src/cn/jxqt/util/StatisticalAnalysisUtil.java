package cn.jxqt.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class StatisticalAnalysisUtil {
	/**
	 *@Author linhao007
	 *@Decration TODO获得小数点后两位
	 * @param ratio
	 * @return
	 */
	public static String getAfterTwo(double ratio) {
		String Ratio = null;
		BigDecimal bg = new BigDecimal(ratio);
		double f1 = bg.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
		Ratio = String.valueOf(f1);
		return Ratio;
	}
	/**
	 * @Author linhao007
	 * @Decration 将重复的数据转变为不重复的有序的List集合
	 * @param list
	 * @return
	 */
	public static List<String> removeDuplicateWithOrder(List<String> list) {
		Set set = new HashSet<String>();
		List<String> newList = new ArrayList();
		for (Iterator iter = list.iterator(); iter.hasNext();) {
			Object element = iter.next();
			if (set.add(element))
				newList.add((String) element);
		}
		list.clear();
		list.addAll(newList);
		return list;
	}

}
