package cn.jxqt.util.dynamo;

import java.io.File;
import java.io.IOException;

import org.web.exception.ErrorException;

import cn.jxqt.util.ZipUtil;

/**
 * @author ASUS
 * 对上传的各种文件进行备份
 * sourcePath 存放备份文件的源路径
 *destPath 备份文件的最终路径
 */
public class FileBackups implements IBackups {
	private static ZipUtil zipUtil=new ZipUtil();//对文件进行解压和压缩工具类
	public FileBackups() {
		
	}
	public boolean backups(String sourcePath, String destPath) throws ErrorException {
		// TODO Auto-generated method stub
		try {
			//得到除具体文件名(压缩后的zip文件)前面的文件夹名
			String fileName =destPath.substring(0, destPath.lastIndexOf("/"));
			File file=new File(fileName);
			if(!file.exists()){
				file.mkdir();
			}
			//从路径sourcePath压缩到destPath中   其中destPath包括具体文件名
			zipUtil.zip(sourcePath, destPath);
			
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ErrorException("备份失败");
		}
	}

}
