package cn.jxqt.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class InsertMiddle {

	String localPath = this.getClass().getClassLoader().getResource("/")
			.getPath();

	public static void InsertPsword(String filename, String ps, String path,
			String url, String u_id) throws Exception {
		/**
		 * 读取模板
		 */
		File file = new File(path + filename);
		FileInputStream fis = new FileInputStream(file);
		BufferedReader reader = new BufferedReader(new InputStreamReader(fis,
				"utf-8")); // 转换编码 解决乱码问题。
		String str = null;
		String[] sb = new String[14];
		int line = 0;
		while ((str = reader.readLine()) != null) {

			if (line == 7) {
				str = str.replace("temp2", u_id);
				str = str.replace("flag", ps);
				str = str.replace("temp", url + "/login.jsp");
			}
			sb[line] = str;

			line++;
		}
		/**
		 * 写入邮件中
		 */
		PrintWriter writer = new PrintWriter(new File(path
				+ "PaswordUpdateMail.txt"));
		for (String s : sb) {
			if (s != null) {
				writer.write(s);
				writer.write("\n");
			}
		}
		writer.flush();

	}
}