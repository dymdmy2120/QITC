package cn.jxqt.util.dynamo;

import org.web.exception.ErrorException;

public interface IRestore {
	
	/**
	 * 还原数据
	 * @param sourcePath 具体存放还原数据的路径
	 * @param destPath 把数据还原到地方
	 * @return
	 * @throws ErrorException 
	 */
	public boolean restore(String sourcePath,String destPath) throws ErrorException;

}
