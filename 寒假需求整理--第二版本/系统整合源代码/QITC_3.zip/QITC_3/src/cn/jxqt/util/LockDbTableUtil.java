package cn.jxqt.util;

import java.sql.Connection;

import tool.mastery.db.DBUtil;

/**
 * @author ASUS 当进行数据库备份时对数据表进行锁定 需要对数据库加入读锁 当备份时只能对数据进行读取，不可以操作
 * 
 */
public class LockDbTableUtil {

	/**
	 * 对数据库中所有的表进行锁定 加一把读锁 当进行备份时只能读取表中的数据 不能对表中的数据进行增删改
	 */
	private static Connection conn = DBUtil.getConnection();

	public static void locktables() {
		String tablesName = "t_apt read,t_laws read,t_bounds read,t_typical read,t_userpower read,t_user read,t_audit read,t_dete read,t_laboratory read,t_alarm read,t_mbr read,t_slink read,t_sta read,t_power read,t_product read";   
		String lockSql = "lock tables "+tablesName;
        System.out.println(lockSql);
		try {
			conn.prepareStatement(lockSql).executeQuery();
           System.out.println(1);
		} catch (Exception e) {
			unlock();
			System.out.println("异常" + e.getMessage());
		}
	}

	/**
	 * 释放所有表的读锁
	 */
	public static void unlock() {
		String unlockSql = "unlock tables";

		try {

			System.out.println(conn + "lock");
			conn.prepareStatement(unlockSql).executeQuery();

		} catch (Exception e) {
			System.out.println("异常" + e.getMessage());
		}
	}
public static void main(String[] ar){
	locktables();
}
}
