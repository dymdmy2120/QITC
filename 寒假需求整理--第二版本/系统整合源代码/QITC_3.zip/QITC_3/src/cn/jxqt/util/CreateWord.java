package cn.jxqt.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import cn.jxqt.vo.AlarmSta;
import cn.jxqt.vo.statisticsalaysis.ClientInfoKeyVo;
import cn.jxqt.vo.statisticsalaysis.ClientInfoSituation;
import cn.jxqt.vo.statisticsalaysis.ComparisonInfor;
import cn.jxqt.vo.statisticsalaysis.ComparisonResult;
import cn.jxqt.vo.statisticsalaysis.CountData;
import cn.jxqt.vo.statisticsalaysis.DatectionSample;
import cn.jxqt.vo.statisticsalaysis.DatectionSampleKeyVo;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmount;
import cn.jxqt.vo.statisticsalaysis.DectionMethodAmountKeyVo;
import cn.jxqt.vo.statisticsalaysis.DetectionVarieties;
import cn.jxqt.vo.statisticsalaysis.DetectionVarietiesKeyVo;
import cn.jxqt.vo.statisticsalaysis.StandardComparsionInfor;
import cn.jxqt.vo.statisticsalaysis.StandardComparsionResult;
import cn.jxqt.vo.statisticsalaysis.ZBTest;

import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.rtf.style.RtfParagraphStyle;

/**
 * 创建word文档 工具类
 */
public class CreateWord {

	private static CreateWord createWord;
	private String filePath = "";
	RtfParagraphStyle rtfGsBt1 = null;
	RtfParagraphStyle rtfGsBt2 = null;
	WordUtils wordUtils = new WordUtils();
	HttpServletRequest request;
	String picPath; // 图片链接地址
	String filename;

	public CreateWord(HttpServletRequest request) { // 资源的初始化工具
		this.request = request;

		filePath = request.getRealPath("/");

		// 第一级标题样式
		rtfGsBt1 = RtfParagraphStyle.STYLE_HEADING_1;
		rtfGsBt1.setAlignment(Element.ALIGN_LEFT);
		rtfGsBt1.setStyle(Font.BOLD);
		rtfGsBt1.setSize(15);

		// 第二级标题样式
		rtfGsBt2 = RtfParagraphStyle.STYLE_HEADING_2;
		rtfGsBt2.setAlignment(Element.ALIGN_LEFT);
		rtfGsBt2.setStyle(Font.BOLD);
		rtfGsBt2.setSize(13);
	}

	public static CreateWord getInstance() {
		return createWord;
	}

	public String createReport(Object[] objs) throws IOException,
			DocumentException {

		// 传递过来的参数
		String DocumentTitle = (String) objs[0];
		String DetectionItem = (String) objs[1];
		String TestDate = (String) objs[2];
		String Department = (String) objs[3];
		String[] selected = (String[]) objs[4];
		List<DetectionVarieties> dectionVarietiesOrAmount = (List) objs[5];
		DetectionVarietiesKeyVo getDectionVarietiesOrAmountKey = (DetectionVarietiesKeyVo) objs[6];
		List<ClientInfoSituation> getClientInfoSituation = (List<ClientInfoSituation>) objs[7];
		ClientInfoKeyVo getClientInforKey = (ClientInfoKeyVo) objs[8];
		List<DatectionSample> getDectionSample = (List<DatectionSample>) objs[9];
		DatectionSampleKeyVo getDectionSampleOr25Key = (DatectionSampleKeyVo) objs[10];
		List<DatectionSample> getDectionSampleOr25 = (List<DatectionSample>) objs[11];
		List<ZBTest> getTableZB = (List<ZBTest>) objs[12];
		CountData getReadKeyword = (CountData) objs[13];
		List<DectionMethodAmount> getDectionMethodOrAmount = (List<DectionMethodAmount>) objs[14];
		DectionMethodAmountKeyVo getDectionMethodOrAmountKey = (DectionMethodAmountKeyVo) objs[15];
		List<StandardComparsionInfor> comparisonResultInfor = (List<StandardComparsionInfor>) objs[16];
		List<StandardComparsionResult> getStandardComparsionResult = (List<StandardComparsionResult>) objs[17];
		List<ComparisonInfor> dectionCheckLimitedLibrary = (List<ComparisonInfor>) objs[18];
		List<ComparisonResult> getComparisonResult = (List<ComparisonResult>) objs[19];
		List<ZBTest> getTableNotZB = (List<ZBTest>) objs[20];

		// 这里动态生成word的名称
		filename = "Hazards";
		wordUtils.openDocument(createFile(filename));

		wordUtils.insertTitle(DocumentTitle, 17, Font.BOLD,
				Element.ALIGN_CENTER);

		/*
		 * 1.业务情况
		 */
		wordUtils.insertTitlePattern("1、业务情况", rtfGsBt1);
		wordUtils.insertTitlePatternSecond("1.1送检品种、数量与项次数", rtfGsBt2);
		wordUtils.insertContext("  " + TestDate + "江西出入境检验检疫局综合技术" + Department
				+ "受检" + getDectionVarietiesOrAmountKey.getCategory() + "样品"
				+ getDectionVarietiesOrAmountKey.getAmountCategory() + "批次，"
				+ "检测项目" + getDectionVarietiesOrAmountKey.getAmountTesting()
				+ "项。 具体情况见表1。", 12, Font.NORMAL, Element.ALIGN_LEFT);

		wordUtils.insertContext("表1 " + Department + TestDate + DetectionItem
				+ "数量与项次数", 12, Font.NORMAL, Element.ALIGN_CENTER);
		wordUtils.getDocument().add(new Phrase(""));// 为了解决在插入段落与表之间产生多余的空格
		new Paragraph();
		// 二维数组中每一维存放一个单元格 及其这个单元内部再分的小单元格内容
		String[][] ComplexTable = { { "样品类别" },
				{ "样品数量", "委托检验", "监控", "自报检" },
				{ "项目次数", "委托检验", "监控", "自报检" } };

		// 表一数据部分
		String[][] values = new String[dectionVarietiesOrAmount.size()][7];
		for (int i = 0; i < dectionVarietiesOrAmount.size(); i++) {
			DetectionVarieties temp = dectionVarietiesOrAmount.get(i);
			System.out.println(temp);
			values[i][0] = temp.getCategory();
			values[i][1] = temp.getSampleNumber() + "";
			values[i][2] = temp.getSampleNumber23() + "";
			values[i][3] = temp.getSampleNumber25() + "";
			values[i][4] = temp.getTestingNumber() + "";
			values[i][5] = temp.getTestingNumber23() + "";
			values[i][6] = temp.getTestingNumber25() + "";
		}
		wordUtils.insertComplexTableFood(values, ComplexTable);

		/*
		 * 2.送检客户情况 标题下 内容
		 */
		wordUtils.insertTitlePattern("2、送检客户情况", rtfGsBt1);
		wordUtils.insertContext("  " + Department + TestDate + DetectionItem
				+ "送检客户以 " + getClientInforKey.getFirstSupper() + "居多,"
				+ getClientInforKey.getSecondSupper() + "次之，具体见表2。", 12,
				Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("表2 送检客户分布情况", 12, Font.NORMAL,
				Element.ALIGN_CENTER);
		wordUtils.getDocument().add(new Phrase(""));// 为了解决在插入段落与表之间产生多余的空格
		new Paragraph();
		// 需要传入表头 数据 根据表头确定列数 根据数据确定行数

		values = new String[getClientInfoSituation.size()][5];
		for (int i = 0; i < getClientInfoSituation.size(); i++) {
			ClientInfoSituation temp = getClientInfoSituation.get(i);
			values[i][0] = i + 1 + "";
			values[i][1] = temp.getClientName();
			values[i][2] = temp.getInspectionNumber() + "";
			values[i][3] = temp.getInspectionRate();
			values[i][4] = temp.getAddress();

		}

		wordUtils.insertSimpleTable(values, "序号", "客户名称", "送检样品数量", "所占比例（%）",
				"送检部门");

		/*
		 * 3.样品检出情况
		 */
		wordUtils.insertTitlePattern("3、样品检出情况", rtfGsBt1);
		wordUtils.insertTitlePatternSecond("3.1样品检出情况--除自报检", rtfGsBt2);

		StringBuffer str = new StringBuffer();
		for (String s : getDectionSampleOr25Key.getRankingOneTofive()) {
			str.append(s + ",");
		}
		String tem = str.substring(0, str.lastIndexOf(","));
		wordUtils.insertContext(
				"  统计分析发现," + TestDate + "," + Department + "检测涉及"
						+ DetectionItem + "品种"
						+ getDectionSampleOr25Key.getVarietiesNumber()
						+ "种，主要有" + tem.toString() + "等。" + "受检"
						+ DetectionItem + "样品"
						+ getDectionSampleOr25Key.getVarietiesAmount()
						+ "批次，共检出农药样品"
						+ getDectionSampleOr25Key.getDetectionAmount() + "批次，"
						+ "样品检出率达" + getDectionSampleOr25Key.getRatio()
						+ "%。其中，" + getDectionSampleOr25Key.getLargeDetection()
						+ "的样品检出数量最高," + "为"
						+ getDectionSampleOr25Key.getTempFlag() + "次", 12,
				Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("表3 样品检出情况 (除自报检)", 12, Font.NORMAL,
				Element.ALIGN_CENTER);
		wordUtils.getDocument().add(new Phrase(""));// 为了解决在插入段落与表之间产生多余的空格
		new Paragraph();

		values = new String[getDectionSample.size()][4];
		for (int i = 0; i < getDectionSample.size(); i++) {
			DatectionSample temp = getDectionSample.get(i);
			values[i][0] = temp.getSampleName();
			values[i][1] = temp.getSampleNumber() + "";
			values[i][2] = temp.getSampleDetectionNumber() + "";
			values[i][3] = temp.getSampleDetectionRate();
		}
		wordUtils.insertSimpleTable(values, "样品名称", "样品总数", "样品检出数量",
				"样品检出率(%)");

		wordUtils.insertTitlePatternSecond("3.2自报检样品检出情况", rtfGsBt2);
		wordUtils.insertContext("表4 自报检样品检出情况", 12, Font.NORMAL,
				Element.ALIGN_CENTER);
		wordUtils.getDocument().add(new Phrase(""));// 为了解决在插入段落与表之间产生多余的空格
		new Paragraph();

		values = new String[getDectionSampleOr25.size()][4];

		for (int i = 0; i < getDectionSampleOr25.size(); i++) {
			DatectionSample temp = getDectionSampleOr25.get(i);
			values[i][0] = temp.getSampleName() + "";
			values[i][1] = temp.getSampleNumber() + "";
			values[i][2] = temp.getSampleDetectionNumber() + "";
			values[i][3] = temp.getSampleDetectionRate();
		}

		wordUtils.insertSimpleTable(values, "样品名称", "样品总数", "样品检出数量",
				"样品检出率（%）");

		/*
		 * 4、检出农药的种类与频次
		 */
		StringBuffer str4 = new StringBuffer(" ");
		for (int i = 0; i < getReadKeyword.getFirstFive().length; i++) {
			str4.append((getReadKeyword.getFirstFive())[i] + " ");
		}

		wordUtils.insertTitlePattern("4、检出农药的种类与频次", rtfGsBt1);
		wordUtils.insertTitlePatternSecond("4.1检出农药的种类与频次---除自报检", rtfGsBt2);
		wordUtils.insertContext("  经统计，共检测农药项次" + getReadKeyword.getTimes()
				+ "项，涉及农药残留物" + getReadKeyword.getKind() + "种。" + "其中，检出农药频次"
				+ getReadKeyword.getTestOutTimes() + "频次，涉及检出农药种类"
				+ getReadKeyword.getTestOutKind() + "种，主要为" + str4 + "等。"
				+ getReadKeyword.getFirstFive()[0] + "检出频次最高，共"
				+ getReadKeyword.getFirstTestOutTimes() + "次。", 12,
				Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("表5 检出农药的频次与种类(除自报检)", 12, Font.NORMAL,
				Element.ALIGN_CENTER);
		wordUtils.getDocument().add(new Phrase(""));// 为了解决在插入段落与表之间产生多余的空格
		new Paragraph();

		values = new String[getTableNotZB.size()][4];
		for (int i = 0; i < getTableNotZB.size(); i++) {
			ZBTest temp = getTableNotZB.get(i);
			values[i][0] = temp.getName();
			values[i][1] = temp.getTypeCounts() + "";
			values[i][2] = temp.getTestOutCounts() + "";
			values[i][3] = temp.getTestOutPercent();
		}

		wordUtils.insertSimpleTable(values, "农药名称(检测项目)", "项目总数", "项目检出频次",
				"项目检出率(%)");
		wordUtils.insertTitlePatternSecond("4.2自报检检出农药的种类与频次", rtfGsBt2);
		wordUtils.insertContext("表6 自报检检出农药的频次与种类", 12, Font.NORMAL,
				Element.ALIGN_CENTER);
		wordUtils.getDocument().add(new Phrase(""));// 为了解决在插入段落与表之间产生多余的空格
		new Paragraph();

		// 表5 检出农药的频次与种类(除自报检)
		values = new String[getTableZB.size()][4];
		for (int i = 0; i < getTableZB.size(); i++) {
			ZBTest temp = getTableZB.get(i);
			values[i][0] = temp.getName();
			values[i][1] = temp.getTypeCounts() + "";
			values[i][2] = temp.getTestOutCounts() + "";
			values[i][3] = temp.getTestOutPercent();
		}

		wordUtils.insertSimpleTable(values, "农药名称(检测项目)", "项目总数", "项目检出频次",
				"项目检出率(%)");

		/**
		 * 5、检测方法使用种类及频次
		 */
		wordUtils.insertTitlePattern("5、检测方法使用种类及频次", rtfGsBt1);
		wordUtils.insertContext(
				"  " + Department + "检测" + DetectionItem + "农药残留所用的检测方法有"
						+ getDectionMethodOrAmountKey.getMethodNumber() + "种，"
						+ "主要是" + getDectionMethodOrAmountKey.getMainMethod()
						+ "。共使用"
						+ getDectionMethodOrAmountKey.getMainMethodNumber()
						+ "次。"
						+ "（去除自报检，以结果登记时间计算，同一天登记的样品，所使用方法相同时，则该方法使用计为1次）", 12,
				Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("表7 检测方法使用种类及频次", 12, Font.NORMAL,
				Element.ALIGN_CENTER);
		wordUtils.getDocument().add(new Phrase(""));// 为了解决在插入段落与表之间产生多余的空格
		new Paragraph();

		values = new String[getDectionMethodOrAmount.size()][3];
		for (int i = 0; i < getDectionMethodOrAmount.size(); i++) {
			DectionMethodAmount temp = getDectionMethodOrAmount.get(i);
			values[i][0] = temp.getDetectionMethod();
			values[i][1] = temp.getMethodNumber() + "";
			values[i][2] = temp.getMethodRate();
		}

		wordUtils.insertSimpleTable(values, "检测方法", "项目总数", "项目检出频次");

		/**
		 * 6、风险评估
		 */
		List<StandardComparsionResult> scrlist = getStandardComparsionResult;
		wordUtils.insertTitlePattern("6、风险评估", rtfGsBt1);
		wordUtils.insertTitlePatternSecond("6.1 检测项目与限量标准对比情况", rtfGsBt2);

		for (int i = 0; i < scrlist.size(); i++) {
			StandardComparsionResult s = scrlist.get(i);
			wordUtils.insertContext(
					"  食GB2763-2014限量标准中相关茶叶的农药项目有" + s.getCount() + "项，"
							+ "GB2763-2014具备" + s.getSum() + "个检测项目能力，占"
							+ s.getProper() * 100 + "%，还有"
							+ (s.getCount() - s.getSum()) + "个检测项目无检测能力，占"
							+ (1 - s.getProper()) * 100 + "%。", 12,
					Font.NORMAL, Element.ALIGN_LEFT);
		}
		wordUtils.insertContext("表8 检测农药与限量标准对照表", 12, Font.NORMAL,
				Element.ALIGN_CENTER);
		wordUtils.getDocument().add(new Phrase(""));// 为了解决在插入段落与表之间产生多余的空格
		new Paragraph();

		values = new String[comparisonResultInfor.size()][selected.length + 2];
		// 构造表头
		String[] head = new String[selected.length + 2];
		head[0] = "编号";
		head[1] = "检测项目";
		for (int i = 0; i < selected.length; i++) {
			head[i + 2] = selected[i];
		}

		for (int i = 0; i < comparisonResultInfor.size(); i++) {
			StandardComparsionInfor s = comparisonResultInfor.get(i);
			values[i][0] = s.getId() + "";
			values[i][1] = s.getMbr_cname();
			List l = s.getList();
			for (int j = 0; j < l.size(); j++) {
				values[i][j + 2] = (String) l.get(j);
			}
		}

		wordUtils.insertSimpleTable(values, head);

		// 检出情况与限量库标准对比
		wordUtils.insertTitlePatternSecond("6.2.检出情况与限量库标准比对", rtfGsBt2);

		String notVar = "  经统计，在" + dectionCheckLimitedLibrary.size() + "批次的"
				+ DetectionItem + "样品中，有";
		String var = "";

		for (int i = 0; i < getStandardComparsionResult.size(); i++) {
			ComparisonResult t = getComparisonResult.get(i);
			var = "有" + (dectionCheckLimitedLibrary.size() - t.getSum())
					+ "批次样品没有超出" + t.getSta() + "限量规定，占" + t.getProper()
					+ "%，有" + t.getSum() + "批次样品检出超标，超标情况为";
			Set<String> set = t.getMap().keySet();
			Map map = t.getMap();
			for (Iterator k = set.iterator(); k.hasNext();) {
				Object key = k.next();
				var = var + key + "的" + map.get(key);

			}
		}

		wordUtils.insertContext(notVar + var, 12, Font.NORMAL,
				Element.ALIGN_LEFT);
		wordUtils.insertContext("表9 农药残留检出水平与最大残留限量标准对比分析情况", 12, Font.NORMAL,
				Element.ALIGN_CENTER);
		wordUtils.getDocument().add(new Phrase(""));// 为了解决在插入段落与表之间产生多余的空格
		new Paragraph();

		// 表9内容写入
		values = new String[dectionCheckLimitedLibrary.size()][3 + selected.length * 2];

		for (int i = 0; i < dectionCheckLimitedLibrary.size(); i++) {
			ComparisonInfor c = dectionCheckLimitedLibrary.get(i);
			values[i][0] = c.getPro_name();
			values[i][1] = c.getMbr_cname();
			values[i][2] = c.getResult();
			List l = c.getList();
			for (int j = 0; j < l.size(); j++) {
				String content = (String) l.get(j);
				values[i][j + 3] = content;
			}
		}

		// 表头内容的插入
		String[][] complexTable2 = new String[3 + selected.length][3];

		String[][] var2 = new String[selected.length][3]; // 带有重叠的表头

		// 单表头
		String[] var3 = new String[1];
		String[] var4 = new String[1];
		String[] var5 = new String[1];
		var3[0] = "样品名称";
		complexTable2[0] = var3;
		var4[0] = "检测结果(mg/kg)";
		complexTable2[1] = var4;
		var5[0] = "检测项目";
		complexTable2[2] = var5;

		for (int i = 0; i < selected.length; i++) {
			// var2[i] = selected[i];
			var2[i][0] = selected[i];
			var2[i][1] = "限量要求";
			var2[i][2] = "超标";
			complexTable2[i + 3] = var2[i];
		}

		wordUtils.insertComplexTableFood(values, complexTable2);

		wordUtils.closeDocument();
		return filename;

	}

	/**
	 * 生成预警通报报表 至少会有一个国家 否则不生成word
	 * 
	 * @return
	 * @throws IOException
	 * @throws DocumentException
	 */
	public String createChartReport(Object... objs) throws Exception,
			IOException {
		WordUtils wordUtils = new WordUtils();
		AlarmSta alarmSta = (AlarmSta) objs[0];
		String district = alarmSta.getDistrict().equals("0") ? "境外" : (alarmSta
				.getDistrict().equals("1") ? "境内" : "境内外");

		List<Object> obj = (List) objs[1];
		String[] highAlarm = (String[]) objs[2];
		String[] fieldName = (String[]) objs[3];
		StringBuffer xml = (StringBuffer) objs[4];

		filename = "Alarm";
		wordUtils.openDocument(createFile(filename));

		wordUtils.insertTitle(
				alarmSta.getYear() + "年" + district + alarmSta.getTitle(), 17,
				Font.BOLD, Element.ALIGN_CENTER);
		wordUtils.insertContext("  据统计," + alarmSta.getYear() + "年" + district
				+ "食品预警通报" + obj.get(0) + "例，其中对中国出口食品预警通报" + obj.get(1)
				+ "例，占比" + obj.get(2) + "%", 12, Font.NORMAL,
				Element.ALIGN_LEFT);

		ParseXml parsexml = new ParseXml(xml.toString());
		String contents = ""; // 用于盛放需要插入的段落内容
		double count = 0;
		List<String[]> list = parsexml.getValueByTagName("countries");
		String[] value1;
		String[] value2;
		String[] value3;
		System.out.println(list.size());
		if (list.size() >= 1) {
			value1 = list.get(0);
			contents = "  " + alarmSta.getYear() + "年，共有 " + value1[1]
					+ "个国家 发布了产品通报,在" + district + "发布的" + value1[0] + "通报中"
					+ "在 " + district + "食品通报国家中," + value1[2] + "被通报的次数最多，共 "
					+ value1[3] + "项，占比" + value1[4] + "%;";
			count = count + Double.parseDouble(value1[4]);
		}
		if (list.size() >= 2) {
			value2 = list.get(1);
			contents = contents + "其次为" + value2[2] + "共" + value2[3] + ",占比"
					+ value2[4] + "%;";
			count = count + Double.parseDouble(value2[4]);
		}
		if (list.size() >= 3) {
			value3 = list.get(2);
			contents = contents + value3[2] + "位列第三。共" + value3[3] + "项,占比"
					+ value3[4] + "%。";
			count = count + Double.parseDouble(value3[4]);
		}
		contents = contents + "。上述" + list.size() + "国合计占境外产品通报总数的 " + count
				+ "%,具体情况如上图。";

		/*
		 * 1.产品通报的国家
		 */

		wordUtils.insertTitlePattern("1.通报的国家", rtfGsBt1);
		wordUtils.insertImg(picPath + fieldName[0], Element.ALIGN_CENTER, 400,
				400, 50, 50, 50, 0);
		wordUtils.insertContext(contents, 12, Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("  其中，针对中国的食品通报，" + highAlarm[0] + "发布通报最多",
				12, Font.NORMAL, Element.ALIGN_LEFT);

		/**
		 * 2.各月份产品通报的情况
		 */
		list = parsexml.getValueByTagName("rel_date");
		contents = "";
		if (list.size() >= 1) {
			value1 = list.get(0);
			contents = contents + " " + alarmSta.getYear() + " 年,从全年看,"
					+ value1[2] + "";
		}
		if (list.size() >= 2) {
			value2 = list.get(1);
			contents = contents + "和" + value2[2] + "";
		}
		contents = contents + "通报量较大。具体情况如上图。";
		if (list.size() >= 3) {
			value3 = list.get(2);
			contents = contents + "和" + value3[2] + "";
		}
		wordUtils.insertTitlePattern("2.通报的各月份产品", rtfGsBt1);
		wordUtils.insertImg(picPath + fieldName[1], Element.ALIGN_CENTER, 400,
				400, 50, 50, 50, 0);
		wordUtils.insertContext(contents, 12, Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("  其中，针对中国的食品通报," + highAlarm[1] + "发布通报最多。",
				12, Font.NORMAL, Element.ALIGN_LEFT);
		/**
		 * 3.重点通报的产品分类通报的情况
		 */
		wordUtils.insertTitlePattern("3.通报的产品分类", rtfGsBt1);
		wordUtils.insertImg(picPath + fieldName[2], Element.ALIGN_CENTER, 400,
				400, 50, 50, 50, 0);

		list = parsexml.getValueByTagName("category");
		contents = "";
		if (list.size() >= 1) {
			value1 = list.get(0);
			contents = contents + "  " + alarmSta.getYear() + "年，在 " + district
					+ " 发布的 " + value1[0] + "项通报中，" + "在" + district
					+ "食品通报产品分类中," + value1[2] + "最多，共" + value1[3] + " 项，"
					+ "占比" + value1[4] + "%;";
		}

		if (list.size() >= 2) {
			value2 = list.get(1);
			contents = contents + "其次为 " + value2[2] + ",共 " + value2[3]
					+ "项，占比 " + value2[4] + "%；";
		}
		if (list.size() >= 3) {
			value3 = list.get(2);
			contents = contents + value3[2] + "位列第三，共 " + value3[3] + "项，占比 "
					+ value3[4] + "%。";
		}
		contents = contents + "具体情况如上图";

		wordUtils.insertContext(contents, 12, Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("  其中，针对中国的食品通报," + highAlarm[2] + "被通报次数最多。",
				12, Font.NORMAL, Element.ALIGN_LEFT);
		/**
		 * 4.合格项目分类通报的情况
		 */
		list = parsexml.getValueByTagName("mbrsort");
		contents = "";

		if (list.size() >= 1) {
			value1 = list.get(0);
			contents = contents + "  " + alarmSta.getYear() + "年,在" + district
					+ "发布的" + value1[0] + "通报中," + "在" + district
					+ "食品通报不合格项目分类中" + value1[2] + "被通报的次数最多,共" + value1[3]
					+ "项，占比 " + value1[4] + "%;";
		}

		if (list.size() >= 2) {
			value2 = list.get(1);
			contents = contents + "其次为" + value2[2] + ",共" + value2[3]
					+ "项,占比 " + value2[4] + "%;";
		}

		if (list.size() >= 3) {
			value3 = list.get(2);
			contents = contents + " 位居第三的是" + value3[2] + "," + value3[3]
					+ "项，占比 " + value3[4] + "%。";
		}
		contents = contents + "具体情况如上图";

		wordUtils.insertTitlePattern("4.合格项目分类通报的情况", rtfGsBt1);
		wordUtils.insertImg(picPath + fieldName[3], Element.ALIGN_CENTER, 400,
				400, 50, 50, 50, 0);
		wordUtils.insertContext(contents, 12, Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("  其中，针对中国的食品通报，" + highAlarm[3] + "被通报次数最多。",
				12, Font.NORMAL, Element.ALIGN_LEFT);
		/**
		 * 5不.合格项目通报的情况
		 */
		list = parsexml.getValueByTagName("reject_des");
		contents = "";

		if (list.size() >= 1) {
			value1 = list.get(0);
			contents = contents + "  " + alarmSta.getYear() + "年,在" + district
					+ "发布的," + value1[0] + "通报中,在" + district + "食品通报不合格项目中,"
					+ value1[2] + "被通报的次数最多," + "共" + value1[3] + " 项，占比 "
					+ value1[4] + "%;";
		}

		if (list.size() >= 2) {
			value2 = list.get(1);
			contents = contents + "其次为" + value2[2] + "共 " + value2[3] + "项,占比"
					+ value2[4] + " %;";
		}

		if (list.size() >= 3) {
			value3 = list.get(2);
			contents = contents + value3[2] + "位居第三 ,共" + value3[3] + "项,占比"
					+ value3[4];
		}
		contents = contents + " %。具体情况见上图";
		wordUtils.insertTitlePattern("5.不合格项目通报的情况", rtfGsBt1);
		wordUtils.insertImg(picPath + fieldName[4], Element.ALIGN_CENTER, 400,
				400, 50, 50, 50, 0);
		wordUtils.insertContext(contents, 12, Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("  其中，针对中国的食品通报," + highAlarm[4] + "被通报次数最多。",
				12, Font.NORMAL, Element.ALIGN_LEFT);

		/**
		 * 6.食品通报采取的主要措施通报的情况
		 */
		list = parsexml.getValueByTagName("measures");
		contents = "";

		if (list.size() >= 1) {
			value1 = list.get(0);
			contents = contents + "  " + alarmSta.getYear() + "年,在" + district
					+ "  发布的" + value1[0] + "通报中， 在" + district + "食品通报采取的措施中,"
					+ value1[2] + "被通报的次数最多，" + "共 " + value1[3] + "项,占比 "
					+ value1[4] + "%;";
		}

		if (list.size() >= 2) {
			value2 = list.get(1);
			contents = contents + "其次为 " + value2[2] + ",共" + value2[3]
					+ "项,占比" + value2[4] + " %;";
		}

		if (list.size() >= 3) {
			value3 = list.get(2);
			contents = contents + value3[2] + "位居第三,共" + value3[3] + "项，占比"
					+ value3[4] + "%。";
		}
		contents = contents + "具体情况见上图。";

		wordUtils.insertTitlePattern("6.食品通报采取的主要措施通报的情况", rtfGsBt1);
		wordUtils.insertImg(picPath + fieldName[5], Element.ALIGN_CENTER, 400,
				400, 50, 50, 50, 0);
		wordUtils.insertContext(contents, 12, Font.NORMAL, Element.ALIGN_LEFT);
		wordUtils.insertContext("  其中，针对中国的食品通报," + highAlarm[5] + "被通报次数最多",
				12, Font.NORMAL, Element.ALIGN_LEFT);

		wordUtils.closeDocument();
		return filename;
	}

	public String createFile(String fileName) throws IOException {

		picPath = request.getRealPath("/"); // 得到基础路径
		filePath = picPath.substring(0, picPath.lastIndexOf("\\")) + "\\temp\\"; // 这里是生成的word的路径地址
		picPath = picPath.substring(0, picPath.lastIndexOf("\\") - 15)
				+ "\\temp\\"; // 这里是得到生成的报表 路径地址

		// 重新构建 word文件夹的名称
		Date now = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy_MM_dd_HH_mm_ss");// 可以方便地修改日期格
		this.filename = dateFormat.format(now) + "_" + fileName;

		File f = new File(filePath);
		if (!f.exists()) {
			f.mkdirs();
		}
		f = new File(filePath + this.filename + ".doc");
		f.createNewFile();
		return filePath + this.filename + ".doc";
	}

}
