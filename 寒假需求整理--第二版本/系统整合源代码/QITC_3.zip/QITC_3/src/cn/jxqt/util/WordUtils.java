package cn.jxqt.util;

import java.awt.Color;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;

import com.lowagie.text.BadElementException;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.rtf.RtfWriter2;
import com.lowagie.text.rtf.style.RtfParagraphStyle;

/**
 * word帮助文件
 */
public class WordUtils {
	private Document document;
	private BaseFont bfChinese;
	private String test;

	public BaseFont getBfChinese() {
		return bfChinese;
	}

	public void setBfChinese(BaseFont bfChinese) {
		this.bfChinese = bfChinese;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public WordUtils() {
		this.document = new Document(PageSize.A4);// 设置纸张大小

	}

	/**
	 * 建立一个书写器(Writer)与document对象关联，通过书写器(Writer)可以将文档写入到磁盘中
	 * 
	 * @param filePath
	 *            要操作的文档路径，若文档不存在会自动创建
	 * @throws com.lowagie.text.DocumentException
	 * @throws java.io.IOException
	 */
	public void openDocument(String filePath) throws DocumentException,
			IOException {
		// 建立一个书写器(Writer)与document对象关联，通过书写器(Writer)可以将文档写入到磁盘中
		RtfWriter2.getInstance(this.document, new FileOutputStream(filePath));
		this.document.open();
		// 设置中文字体
		this.bfChinese = BaseFont.createFont("STSongStd-Light", "UniGB-UCS2-H",
				BaseFont.NOT_EMBEDDED);
	}

	/**
	 * @param titleStr
	 *            标题
	 * @param fontsize
	 *            字体大小
	 * @param fontStyle
	 *            字体样式
	 * @param elementAlign
	 *            对齐方式
	 * @throws com.lowagie.text.DocumentException
	 */
	public void insertTitle(String titleStr, int fontsize, int fontStyle,
			int elementAlign) throws DocumentException {
		Font titleFont = new Font(this.bfChinese, fontsize, fontStyle);
		Paragraph title = new Paragraph(titleStr);
		// 设置标题格式对齐方式
		title.setAlignment(elementAlign);
		title.setFont(titleFont);

		this.document.add(title);
	}

	/**
	 * 设置带有目录格式的标题(标题1格式)
	 * 
	 * @param rtfParagraphStyle
	 *            标题1样式
	 * @param titleStr
	 *            标题
	 * @throws DocumentException
	 */
	public void insertTitlePattern(String titleStr,
			RtfParagraphStyle rtfParagraphStyle) throws DocumentException {
		Paragraph title = new Paragraph(titleStr);
		title.setFont(rtfParagraphStyle);
		this.document.add(title);
	}

	/**
	 * 设置带有目录格式的标题(标题2格式)
	 * 
	 * @param titleStr
	 *            标题
	 * @param rtfParagraphStyle
	 *            标题2样式
	 * @throws DocumentException
	 */
	public void insertTitlePatternSecond(String titleStr,
			RtfParagraphStyle rtfParagraphStyle) throws DocumentException {
		Paragraph title = new Paragraph(titleStr);
		// 设置标题格式对齐方式
		title.setFont(rtfParagraphStyle);
		this.document.add(title);
	}

	/**
	 * @param tableName
	 *            标题
	 * @param fontsize
	 *            字体大小
	 * @param fontStyle
	 *            字体样式
	 * @param elementAlign
	 *            对齐方式
	 * @throws com.lowagie.text.DocumentException
	 */
	public void insertTableName(String tableName, int fontsize, int fontStyle,
			int elementAlign) throws DocumentException {
		Font titleFont = new Font(this.bfChinese, fontsize, fontStyle);
		titleFont.setColor(102, 102, 153);
		Paragraph title = new Paragraph(tableName);
		// 设置标题格式对齐方式
		title.setAlignment(elementAlign);
		title.setFont(titleFont);

		this.document.add(title);
	}

	/**
	 * @param contextStr
	 *            内容
	 * @param fontsize
	 *            字体大小
	 * @param fontStyle
	 *            字体样式
	 * @param elementAlign
	 *            对齐方式
	 * @throws com.lowagie.text.DocumentException
	 */
	public void insertContext(String contextStr, int fontsize, int fontStyle,
			int elementAlign) throws DocumentException {
		// 正文字体风格
		Font contextFont = new Font(bfChinese, fontsize, fontStyle);
		Paragraph context = new Paragraph(contextStr);
		// 设置行距
		context.setLeading(3f);
		// 正文格式左对齐
		context.setAlignment(elementAlign);
		context.setFont(contextFont);
		// 离上一段落（标题）空的行数
		context.setSpacingBefore(1);
		// 设置第一行空的列数
		context.setFirstLineIndent(20);
		document.add(context);
	}

	/**
	 * @param imgUrl
	 *            图片路径
	 * @param imageAlign
	 *            显示位置
	 * @param height
	 *            显示高度
	 * @param weight
	 *            显示宽度
	 * @param percent
	 *            显示比例
	 * @param heightPercent
	 *            显示高度比例
	 * @param weightPercent
	 *            显示宽度比例
	 * @param rotation
	 *            显示图片旋转角度
	 * @throws java.net.MalformedURLException
	 * @throws java.io.IOException
	 * @throws com.lowagie.text.DocumentException
	 */
	public void insertImg(String imgUrl, int imageAlign, int height,
			int weight, int percent, int heightPercent, int weightPercent,
			int rotation) throws MalformedURLException, IOException,
			DocumentException {
		// 添加图片
		Image img = Image.getInstance(imgUrl);
		if (img == null)
			return;
		img.setAbsolutePosition(0, 0);
		img.setAlignment(imageAlign);
		img.scaleAbsolute(height, weight);
		img.scaleAbsolute(1000, 1000);
		img.scalePercent(percent);
		img.scalePercent(heightPercent, weightPercent);
		img.setRotation(rotation);
		document.add(img);
	}

	/**
	 * @param tableDatas
	 *            表格数据项
	 * @param tableHeadNames
	 *            表头
	 * @throws DocumentException
	 */
	public void insertSimpleTable(String[][] tableDatas,
			String... tableHeadNames) throws DocumentException {
		Table table = tableStyle(tableHeadNames.length);
		for (String tableHeadName : tableHeadNames) { // 这是写入表格头
			table.addCell(cellStyle(tableHeadName, 1, 1));
		}

		if (tableDatas != null) {

			for (String[] datas : tableDatas) { // 写入表格数据项
				if (datas != null) {// 防止产生空行

					for (String data2 : datas) {
						if (data2 != null) { // 防止产生空行
							table.addCell(cellStyle(data2, 1, 1));
						}
					}
				}

			}
		}
		document.add(table);
	}

	/**
	 * 关于 食品室的表格
	 * 
	 * @param tableDatas
	 *            表格数据项
	 * @param tableHeadNames
	 *            表头
	 * @throws DocumentException
	 */
	public void insertComplexTableFood(String[][] datas, String[][] tableNames)
			throws DocumentException {

		int i = 0;
		// for循环 为了动态确定表格列数 其中需要传入表格的列数
		for (String[] tableName : tableNames) {

			int temp = tableName.length;

			if (temp > 1) {
				temp = temp - 1;
			}

			i = i + temp;
		}
		Table table = tableStyle(i);
		// 创建table对象结束

		// 表头内容写入 写入思路是先写入第一层表头,再写入第二层表头。
		if (tableNames != null) {
			for (int temp = 0; temp < tableNames.length; temp++) { // 第一层表头的写入

				if (tableNames[temp].length > 1) { // 内部还分了其他单元格 换句话说就是单元格跨列数大于一
					table.addCell(cellStyle(tableNames[temp][0],
							tableNames[temp].length - 1, 1));
				} else {
					table.addCell(cellStyle(tableNames[temp][0], 1, 2));
				}

			}
			for (int temp = 0; temp < tableNames.length; temp++) { // 第二层表头写入

				for (int j = 1; j < tableNames[temp].length; j++) {
					table.addCell(cellStyle(tableNames[temp][j], 1, 1));
				}
			}
		}

		// 表格数据部分写入
		if (datas != null) {
			for (String[] data : datas) {
				for (String data1 : data) {
					table.addCell(cellStyle(data1, 1, 1));
				}
			}
		}
		document.add(table);
	}

	/**
	 * 表格样式 设定
	 * 
	 * @return
	 * @throws DocumentException
	 */
	@SuppressWarnings("unused")
	private Table tableStyle(int size) throws DocumentException {

		Table table = new Table(size);
		table.setWidth(100);
		table.setAutoFillEmptyCells(true);
		table.setAlignment(Element.ALIGN_CENTER);// 居中显示
		table.setAlignment(Element.ALIGN_MIDDLE);// 垂直居中显示
		table.setBorder(1000);
		table.setBorderWidth(1);// 边框宽度
		return table;
	}

	/**
	 * 设置 cell单元格的样式
	 * 
	 * @param data
	 *            单元格需要存放的内容
	 * @param clospan
	 *            该单元格所占 列数 必须传入大于1的整数
	 * @param rowspan
	 *            该单元格所占 行数 必须传入大于1的整数
	 * @return
	 * @throws BadElementException
	 */
	private Cell cellStyle(String data, int colspan, int rowspan)
			throws BadElementException {
		Cell cell = new Cell(new Phrase(data));
		cell.setColspan(colspan);// 设置当前单元格占据的列数
		cell.setRowspan(rowspan);
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		return cell;

	}

	/**
	 * @return 带有背景颜色的table
	 * @throws DocumentException
	 */
	public Table insertBGColor() throws DocumentException {
		Table table = new Table(4);// 生成一个四列的表格
		int width[] = { 25, 25, 25, 25 };
		table.setWidths(width);// 设置系列所占比例
		table.setWidth(100);
		table.setAutoFillEmptyCells(true);
		table.setAlignment(Element.ALIGN_CENTER);// 居中显示
		table.setAlignment(Element.ALIGN_MIDDLE);// 垂直居中显示
		table.setBorder(30);
		table.setBorderWidth(230);// 边框宽度
		table.setSpacing(2);
		table.setPadding(3);
		table.setBorderColor(new Color(58, 255, 132));// 边框颜色

		Cell cell = new Cell(new Phrase("列一"));
		cell.setVerticalAlignment(Element.ALIGN_CENTER);
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setBorderColor(new Color(189, 22, 33));
		cell.setBackgroundColor(new Color(58, 137, 20));
		table.addCell(cell);

		Cell cell2 = new Cell(new Phrase("列二"));
		cell2.setVerticalAlignment(Element.ALIGN_CENTER);
		cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell2.setBorderColor(new Color(189, 22, 33));
		cell2.setBackgroundColor(new Color(137, 34, 44));
		table.addCell(cell2);

		Cell cell3 = new Cell(new Phrase("列三"));
		cell3.setVerticalAlignment(Element.ALIGN_CENTER);
		cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell3.setBorderColor(new Color(189, 22, 33));
		cell3.setBackgroundColor(new Color(232, 219, 48));
		table.addCell(cell3);

		Cell cell4 = new Cell(new Phrase("列四"));
		cell4.setVerticalAlignment(Element.ALIGN_CENTER);
		cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell4.setBorderColor(new Color(189, 22, 33));
		cell4.setBackgroundColor(new Color(54, 246, 231));
		table.addCell(cell);

		for (int i = 0; i < 8; i++) {
			table.addCell(new Cell("自定义内容"));
		}
		return table;
	}

	/**
	 * 在操作完成后必须关闭document,否则即使生成了word文档，打开也会发生错误
	 * 
	 * @throws DocumentException
	 */
	public void closeDocument() throws DocumentException {
		this.document.close();
	}

}
