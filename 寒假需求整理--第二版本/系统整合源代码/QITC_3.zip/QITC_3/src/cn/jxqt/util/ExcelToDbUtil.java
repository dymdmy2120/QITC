package cn.jxqt.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import tool.mastery.core.BeanUtil;
import tool.mastery.core.ClassUtil;

public class ExcelToDbUtil {
	public Map<String,List<Object>> getAllByExcel(String excelName,String[] voNames,String filePath){
		Workbook wb = null; // 获取excel第一张表的流。
		InputStream is = null;
		try {
			is = new FileInputStream(filePath);
			wb = createWorkbook(is, filePath);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ExcelException("操作失败!");
		}
		Sheet sheet = wb.getSheetAt(0);
		Map<Integer, String> titleMap = getTitle(sheet); // 获取表格标题行。
		
		Properties classProperties = GetPropertiesUtil
				.getPropertiesInfo(excelName); // 获取视图对象属性配置，检测导入excel的标题行和配置文件是否一致。
		titleMap = checkExcelisModel(excelName, titleMap, classProperties); // 验证导入的excel是否和模板一样
		
		
		
		return scandExcel(sheet,titleMap,voNames);
	}
	
	public List<Object> getAllByExcel(String voName, String filePath,
			Map<String, Object> additionParam) {
		Workbook wb = null; // 获取excel第一张表的流。
		InputStream is = null;
		try {
			is = new FileInputStream(filePath);
			wb = createWorkbook(is, filePath);
		} catch (Exception e) {
			e.printStackTrace();
			throw new ExcelException("操作失败!");
		}
		Sheet sheet = wb.getSheetAt(0);

		Map<Integer, String> titleMap = getTitle(sheet); // 获取表格标题行。
		Properties classProperties = GetPropertiesUtil
				.getPropertiesInfo(voName); // 获取视图对象属性配置，检测导入excel的标题行和配置文件是否一致。
		titleMap = checkExcelisModel(voName, titleMap, classProperties); // 验证导入的excel是否和模板一样
		System.out.println("new titleMap :"+titleMap);
		return scandExcel(sheet, titleMap, voName,additionParam);
	}
	
	private Map<String,List<Object>> scandExcel(Sheet sheet, Map<Integer, String> titleMap,String[] voNames) throws ExcelException {
		int rowCount = sheet.getLastRowNum(); // 表格的行数
		int colCount = titleMap.size(); // 表格的列数
		
		Map<String,List<Object>> result = new HashMap<String,List<Object>>();
		
		List<Object>[] excelContents = new List[voNames.length]; // 返回的excel全文内容。
		Class<?>[] dataObjModelClass = new Class<?>[voNames.length];
		for(int i = 0 ; i < voNames.length; i ++){
			dataObjModelClass[i] = this.getClass(voNames[i]);
			excelContents[i] = new ArrayList<Object>(colCount - 1);
		}
		
		
		Row row = null; // excel表的行
		Cell cell = null; // excel表的列
		String tempCellValue = ""; // excel表的列的值

		Object[] dataObjs = new Object[voNames.length]; // 对应视图对象
		String paramName = null;
		for (int i = 1; i <= rowCount; i++) { // 读行
			try {
				for(int k = 0 ; k < voNames.length; k ++){
					dataObjs[k] = dataObjModelClass[k].newInstance();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			row = sheet.getRow(i);
			if (row == null) {
				continue;
			}
			int nullCounts = 0;
			for (int j = 0; j < colCount; j++) { // 读列
				cell = row.getCell((short) j);
				if (cell != null) {
					tempCellValue = getCellValue(cell);
					if (tempCellValue != null && !"".equals(tempCellValue)) {
						paramName = titleMap.get(j);
						for(int m = 0 ; m < voNames.length; m ++){
							try {
								BeanUtil.setProperty(dataObjs[m], paramName,tempCellValue);
							} catch (Exception e) {
								continue;
							}
						}
					} else {
						nullCounts++;
					}

				} else {
					nullCounts++;
				}
			}
			if (nullCounts != colCount) {
				for(int n = 0 ; n < voNames.length; n ++){
					excelContents[n].add(dataObjs[n]);
				}
				nullCounts = 0;
			}
		}
		for(int r = 0 ; r < voNames.length ; r ++){
			result.put(voNames[r], excelContents[r]);
		}
		return result;
	}
	
	public List<Object> getAllByExcel(String voName, String filePath)
			throws ExcelException {
		return this.getAllByExcel(voName, filePath, null);
	}

	private List<Object> scandExcel(Sheet sheet, Map<Integer, String> titleMap,
			String voName, Map<String, Object> additionParam)
			throws ExcelException {
		int rowCount = sheet.getLastRowNum(); // 表格的行数
		int colCount = titleMap.size(); // 表格的列数

		List<Object> excelContent = new ArrayList<Object>(rowCount - 1); // 返回的excel全文内容。
		Class<?> dataObjModelClass = this.getClass(voName); // 对应视图类的class
		if (dataObjModelClass == null) {
			throw new ExcelException("系统错误！");
		}
		Row row = null; // excel表的行
		Cell cell = null; // excel表的列
		String tempCellValue = ""; // excel表的列的值

		Object dataObj = null; // 对应视图对象
		String paramName = null;
		for (int i = 1; i <= rowCount; i++) { // 读行
			try {
				dataObj = dataObjModelClass.newInstance();
			} catch (Exception e) {
				e.printStackTrace();
			}
			row = sheet.getRow(i);
			if (row == null) {
				continue;
			}
			int nullCounts = 0;
			for (int j = 0; j < colCount; j++) { // 读列
				cell = row.getCell((short) j);
				if (cell != null) {
					tempCellValue = getCellValue(cell);
					if (tempCellValue != null && !"".equals(tempCellValue)) {
						paramName = titleMap.get(j);
						try {
							BeanUtil.setProperty(dataObj, paramName,
									tempCellValue);
						} catch (Exception e) {
//							System.out.println("excel行转obj	查找对应属性类型出错："
//									+ e.getMessage());
							continue;
						}
					} else {
						nullCounts++;
					}

				} else {
					nullCounts++;
				}
			}
			if (nullCounts != colCount) {
				if(additionParam != null){
					for(Iterator<String> it = additionParam.keySet().iterator(); it.hasNext();) {
						String key = it.next();
						try {
							BeanUtil.setProperty(dataObj, key,
									additionParam.get(key).toString());
						} catch (Exception e) {
							System.out.println("附加参数配置错误！："
									+ e.getMessage());
							continue;
						}
					}
				}
				excelContent.add(dataObj);
				nullCounts = 0;
			}
		}
		return excelContent;
	}

	private Map<Integer, String> getTitle(Sheet sheet) {
		Map<Integer, String> sheetTitle = null;
		Row row = sheet.getRow(0);
		if (row != null) {
			sheetTitle = new HashMap<Integer, String>();
			Cell cell = null;
			String cellValue = null;
			for (int i = 0; i < row.getLastCellNum(); i++) {
				cell = row.getCell((short) i);
				if (cell == null) {
					continue;
				}
				cellValue = getCellValue(cell);
				if (!"".equals(cellValue) && cellValue != null) {
					sheetTitle.put(i, cellValue);
				}
			}
		}
		return sheetTitle;
	}

	// 生成HSSFWorkbook对象；
	private Workbook createWorkbook(InputStream is, String filePath)
			throws IOException {
		String fileFormat = filePath.substring(filePath.lastIndexOf(".") + 1,
				filePath.length());
		try {
			if (fileFormat.equals("xls")) {
				return new HSSFWorkbook(is);
			}
			if (fileFormat.equals("xlsx")) {
				return new XSSFWorkbook(is);
			}
		} catch (Exception e) {
			
		}
		throw new ExcelException("您的Excel版本目前无法解析！");
	}

	@SuppressWarnings("deprecation")
	private String getCellValue(Cell Cell) {
		int cellValueType = Cell.getCellType();
		if (cellValueType == Cell.CELL_TYPE_STRING) {
			if (Cell.getHyperlink() != null) {
				return Cell.getHyperlink().getAddress();
			}
			return String.valueOf(Cell.getStringCellValue());
		} else if (cellValueType == Cell.CELL_TYPE_NUMERIC) {
			if (HSSFDateUtil.isCellDateFormatted(Cell)) {// 时间
				java.util.Date date = Cell.getDateCellValue();
				SimpleDateFormat sdf = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss");
				return sdf.format(date);
			}
			if (String.valueOf(Cell.getNumericCellValue()).indexOf("E") == -1) { // 判定小数
				return String.valueOf(Cell.getNumericCellValue());
			}
			long temp = (long) Cell.getNumericCellValue(); // 长整型去除科学计数法
			return String.valueOf(temp);
		} else if (Cell.getCellType() == Cell.CELL_TYPE_BOOLEAN) {
			return String.valueOf(Cell.getBooleanCellValue());
		} else if (Cell.getCellType() == Cell.CELL_TYPE_BLANK) {
			return "";
		}
		return "";
	}

	/**
	 * 获取对象
	 * 
	 * @param className
	 * @return
	 */
	private Class<?> getClass(String className) {
		Class<?> obj = null;
		try {
			obj = ClassUtil.getVoClassByName(className);
		} catch (Exception e) {
			try {
				obj = ClassUtil.getPoClassByName(className);
			} catch (Exception e1) {
				try {
					obj = ExcelUtil.getTSByName(className);
				} catch (Exception e2) {
					throw new ExcelException("系统错误！");
				}
			}
		}
		return obj;
	}

	/**
	 * 检验导入的Excel文件对应的标题是否和配置的属性文件一致。
	 * 
	 * @param voName
	 * @param titleRow
	 * @param classProperties
	 */
	private Map<Integer, String> checkExcelisModel(String voName,
			Map<Integer, String> titleRow, Properties classProperties)
			throws ExcelException {
		System.out.println(titleRow);
		Map<Integer, String> newTitleRow = new HashMap<Integer, String>(
				titleRow.size());
		Properties excelNamePro = null;
		try {
			excelNamePro = GetPropertiesUtil.getPropertiesInfo("ClassMean");
		} catch (Exception e1) {
			e1.printStackTrace();
			throw new ExcelException("操作失败！");
		}
		String property = excelNamePro.getProperty(voName);// vo中对应的属性；
		StringBuffer info = new StringBuffer("请检查您导入的'");
		info.append(property);
		info.append("'Excel中标题行第");
		Enumeration<?> enumeration = classProperties.propertyNames();
		List<String> propertiesKeys = new ArrayList<String>(); 
		
		boolean temp = false;
		while(enumeration.hasMoreElements()){
			Object e = enumeration.nextElement();
			propertiesKeys.add(e.toString());
		}
		String titleRowCellValue = null;
		int titleRowSize = titleRow.size();
		
		for(int i=0;i<titleRowSize;i++){
			titleRowCellValue = titleRow.get(i);
			boolean flag = false;
			for(int j=0;j<propertiesKeys.size();j++){
				if(titleRowCellValue.equals(propertiesKeys.get(j))){
					newTitleRow.put(i, classProperties.get(propertiesKeys.get(j)).toString());
					propertiesKeys.remove(titleRowCellValue);
					flag = true;
					continue;
				}
			}
			if(flag == false){
				temp = true;
				info = info.append(String.valueOf(i+1));
				info.append("、");
			}
		}
		if (temp) {
			info.substring(0, info.length() - 1);
			info.append("列是否和模板一致,请修改后重新上传！");
			throw new ExcelException(info.toString());
		}
		return newTitleRow;
	}

	public static void main(String[] args) {
		ExcelToDbUtil e = new ExcelToDbUtil();
		String[] voNames = {"ClientInfor","TestResult"};
		try{
//			Map<String,Object> map = new HashMap<String,Object>();
//			map.put("category_id", "0");
			Map<String,List<Object>> list = e.getAllByExcel("Detectionitem",voNames,"G:\\蓝点资料\\12级蓝点暑假项目\\产品阶段性任务\\寒假需求整理--第二版本\\项目测试\\数据导入测试模板\\江西农大蓝点工作室规定模板\\检测统计分析-模板.xls");
			List<Object> result = list.get("ClientInfor");
			for(Object o : result){
				System.out.println(o);
			}
			System.out.println(result.size());
//			result = list.get("TestResult");
//			for(Object o : result){
//				System.out.println(o);
//			}
//			System.out.println(result.size());
		}catch(Exception e1){
			e1.printStackTrace();
		}
		
	}
}
