package cn.jxqt.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

public class ParseXml {

	private static final boolean String = false;
	private String xml = null;
	Document doc = null;
	Element rootElt;

	public ParseXml(String xml) throws DocumentException {
		this.xml = xml;
		doc = DocumentHelper.parseText(xml); // 将字符串转为XML
		rootElt = doc.getRootElement();
	}

	public Map<String, String> getCommonOfValue() {
		Map map = new HashMap(6);
		Iterator iter = rootElt.elementIterator("common"); // 得到common节点
		while (iter.hasNext()) {
			Element recordEle = (Element) iter.next();
			String value = recordEle.elementTextTrim("year");
			map.put("year", value);
			value = recordEle.elementTextTrim("district");
			map.put("district", value);
			value = recordEle.elementTextTrim("title");
			map.put("title", value);
			value = recordEle.elementTextTrim("wholeItem");
			map.put("wholeItem", value);
			value = recordEle.elementTextTrim("chinaItem");
			map.put("chinaItem", value);
			value = recordEle.elementTextTrim("proportion");
		}
		return map;

	}

	// 得到china标签下的数据
	public String[] getChinaOfValue() {
		Element element = rootElt.element("china"); // 得到common节点
		List list = element.elements();
		String[] china = new String[list.size()];
		for (int i = 0; i < list.size(); i++) {
			Element ele = (Element) list.get(i);
			china[i] = (String) ele.getData();
		}
		return china;

	}

	public List<String[]> getValueByTagName(String tagName) {

		System.out.println("sun " + tagName);

		List<String[]> rtn = new ArrayList<String[]>();

		Element element = rootElt.element("rank"); // 得到rank节点
		element = element.element(tagName); // 得到tagName标签
		List list = element.elements("rankC");

		System.out.println("sun " + list.size());

		for (int i = 0; i < list.size(); i++) { // 得到所有 rankC标签项
			element = (Element) list.get(i);
			List childs = element.elements("data");
			String[] temp = new String[childs.size()];
			for (int j = 0; j < childs.size(); j++) { // 得到某个rankC标签下的 data所有数据项
				temp[j] = ((Element) childs.get(j)).getTextTrim();
			}
			rtn.add(temp);
		}
		return rtn;

	}

	public static void main(String[] args) throws Exception {
		String temp = "<?xml version=\"1.0\"   encoding=\"UTF-8\" ?>"
				+ "<contents><countries>"
				+ "<rankC><data>2011</data><data>4</data><data>鹰潭</data><data>1000</data><data>49.73</data></rankC>"
				+

				"<rankC><data>2011</data><data>4</data><data>法国</data><data>504</data><data>25.06</data></rankC>"
				+

				"<rankC><data>2011</data><data>4</data><data>万年</data><data>504</data><data>25.06</data></rankC>"
				+

				"</countries></contents>";
		StringBuffer str = new StringBuffer(temp);
		String s = "<filepath>121</filepath>";
		System.out.println(str.insert(str.lastIndexOf("</contents>"), s));
		System.out.println(str.lastIndexOf("</contents>"));

		// (new ParseXml(temp)).getValueByTagName("countries");
	}
}
