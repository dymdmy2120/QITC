package cn.jxqt.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import cn.jxqt.service.Detection.ZBCountUtil;
import cn.jxqt.vo.ClientInfor;
import cn.jxqt.vo.TestResult;
import cn.jxqt.vo.statisticsalaysis.DetectionKey;
import cn.jxqt.vo.statisticsalaysis.ZBTest;

public class ManangerUtil {
	private List<Object> testResasult = null;
	private List<Object> clientInfor = null;
	// 1.1送检品种、数量与项次数
	private List<String> CateGory = new ArrayList<String>();
	private List<List<String>> bName = new ArrayList<List<String>>();
	private List<String> PID = new ArrayList<String>();
	public List<String> getCateGory() {
		return CateGory;
	}
	public List<String> getPID() {
		return PID;
	}
	public List<List<String>> getbName() {
		return bName;
	}
	// 送检客户情况
	private List<String> amount = new ArrayList<String>();// 用于统计出样品的总数
	private List<String> ClientName = new ArrayList<String>();// 存放客户名称集合，该集合必须将重复数据覆盖
	private List<List<String>> PId1 = new ArrayList<List<String>>();// 存放客户名称以及送检样品数量的双重List集合
	private List<List<String>> ClientAddress = new ArrayList<List<String>>();// 存放客户名称以及对应的所属地区
	public List<String> getAmount() {
		return amount;
	}
	public List<String> getClientName() {
		return ClientName;
	}
	public List<List<String>> getPId1() {
		return PId1;
	}
	public List<List<String>> getClientAddress() {
		return ClientAddress;
	}
	// 样品检出情况（除自报检）+关键字
	private List<String> PName = new ArrayList<String>();// 存放样品名称的集合，该集合可以将重复数据覆盖，保持样品名称的唯一
	private List<DetectionKey> PId2 = new ArrayList<DetectionKey>();// 存放样品名称以及对应的送检样品数量的双重List集合//
	private Map map = new IdentityHashMap<String, String>();// 存放每个样品名称对应的检测项目数的双重Map集合
	public List<String> getPName() {
		return PName;
	}
	public List<DetectionKey> getPId2() {
		return PId2;
	}
	public Map getMap() {
		return map;
	}
//	检测方法使用种类及频次
	 List<String> amountMethod = new ArrayList<String>();// 统计检测方法并进行不重负处理
	 Map map1 = new IdentityHashMap<String, String>();//存放检测方法和等级日期的集合
	public List<String> getAmountMethod() {
		return amountMethod;
	}
	public Map getMap1() {
		return map1;
	}
	
	
//得到循环数据
	int testResasultSize = 0;
	int clientInforSize = 0;
	public ManangerUtil(List<Object> testResasult, List<Object> clientInfor) {
		this.clientInfor = clientInfor;
		this.testResasult = testResasult;
		testResasultSize = testResasult.size();
		clientInforSize = clientInfor.size();
	}
	public int getTestResaultSize(){
		return testResasultSize;
	}
	
	
	Map<String,ZBTest> tableZB = new HashMap<String,ZBTest>();		//自报表格
	Map<String,ZBTest> tableNotZB = new HashMap<String,ZBTest>();	//非自报表格
	public Map<String,ZBTest> getTableZB(){
		return this.tableZB;
	}
	public Map<String,ZBTest> getTableNotZB(){
		return this.tableNotZB;
	}
	public void getParam() {
		for (int i = 0; i < testResasultSize; i++) {
			TestResult testa = (TestResult) testResasult.get(i);
			this.getDetectionVarietiesOrAmount(testa);// 获得1.1送检品种、数量与项次数的参数
			this.getDectionSample(testa);// 样品检出情况（除自报检）+关键字
			this.getDectionMethodOrAmount1(testa);// 检测方法使用种类及频次
			this.getZBResult(testa);//检测项目自报检
			this.setMbrNames(testa); //检测结果中的不重复的危害物种类
			this.setCheckOutY(testa);	//其中为阳性的内容
		}
		for (int j = 0; j < clientInforSize; j++) {
			ClientInfor testa = (ClientInfor) clientInfor.get(j);
			this.getClientInfoSituation(testa);// 送检客户情况
		}
	}
	
	

	/**============================================================================
	 * mmt
	 * @param it
	 * @param evaluation
	 * @param Mbr_cname
	 */
	private void changItem(ZBTest it, String evaluation,String Mbr_cname){
		it.setTypeCounts(it.getTypeCounts() + 1);
		if ("检出".equals(evaluation) || "阳性".equals(evaluation)) {
			it.setTestOutCounts(it.getTestOutCounts() + 1);
		}
	}
	
	//mmt============================================
	Set<String> PnameSetIsZB = new HashSet<String>();				//自报
	Set<String> PnameSetNotZB = new HashSet<String>();				//非自报
	ZBTest zbTestSuper = new ZBTest();
	ZBTest	zbTest=null;
	private void getZBResult(TestResult testa){
		//mmt==========================================
		if(ZBCountUtil.itemIsZB(testa.getInspection_id())){									//是自报检
			if(PnameSetIsZB.add(testa.getMbr_cname())){							//是否已经记录过；
				zbTest = (ZBTest) zbTestSuper.clone();
				zbTest.setName(testa.getMbr_cname());
				tableZB.put(testa.getMbr_cname(), zbTest);
				changItem(zbTest,testa.getEvaluation(),testa.getMbr_cname());
			}else{
				zbTest = tableZB.get(testa.getMbr_cname());
				changItem(zbTest,testa.getEvaluation(),testa.getMbr_cname());
			}
		}else{																			//非自报检
			if(PnameSetNotZB.add(testa.getMbr_cname())){
				zbTest = (ZBTest) zbTestSuper.clone();
				zbTest.setName(testa.getMbr_cname());
				tableNotZB.put(testa.getMbr_cname(), zbTest);
				changItem(zbTest,testa.getEvaluation(),testa.getMbr_cname());
			}else{
				zbTest = tableNotZB.get(testa.getMbr_cname());
				changItem(zbTest,testa.getEvaluation(),testa.getMbr_cname());
			}
		}
		//mmt end===========================================
		
	}
	
	
	private void getDetectionVarietiesOrAmount(TestResult testa) {// 获得1.1送检品种、数量与项次数的参数
		List<String> bname = new ArrayList<String>();
		CateGory.add(testa.getP_category());
		PID.add(testa.getP_id());
		bname.add(testa.getP_category());
		bname.add(testa.getInspection_id());
		bname.add(testa.getP_id());
		bName.add(bname);
	}
	private void getClientInfoSituation(ClientInfor testa) {// 送检客户情况
		List<String> pid = new ArrayList<String>();
		List<String> clientaddress = new ArrayList<String>();
		ClientName.add(testa.getClient_name());
		// 送检样品数以及客户名称
		pid.add(testa.getClient_name());
		pid.add(testa.getP_id());
		amount.add(testa.getP_id());
		PId1.add(pid);
		// 客户地址以及客户名称
		clientaddress.add(testa.getClient_name());
		clientaddress.add(testa.getClient_address());
		ClientAddress.add(clientaddress);
	}
	DetectionKey detectionKeySuper = new DetectionKey();
	DetectionKey detectionKey = null;
	private void getDectionSample(TestResult testa) {// 样品检出情况（除自报检）+关键字
		List<String> detection = new ArrayList<String>();
		PName.add(testa.getP_name().substring(0).split(" ")[0]);
		detectionKey = (DetectionKey) detectionKeySuper.clone();
		// 样品数量
		detectionKey.setP_name(testa.getP_name().substring(0).split(" ")[0]);
		detectionKey.setP_id(testa.getP_id());
		detectionKey.setInspection_id(testa.getInspection_id());
		PId2.add(detectionKey);
		// 检测数量
		// bname.add(testa.getInspection_id());
		map.put(testa.getP_id(), testa.getEvaluation());
	}
	private void getDectionMethodOrAmount1(TestResult testa){// 检测方法使用种类及频次
		if(testa.getInspection_id().indexOf("25") != 0){
			map1.put(testa.getM_name(), testa.getRegistration());
			amountMethod.add(testa.getM_name());
		}
	}

	
	/**
	 * zch
	 */
	
	private Set<String> mbrNames = new HashSet<String>();
	
	public Set<String> getMbrNames() {
		return this.mbrNames;
	}
	
	private void setMbrNames(TestResult testResult) {
		mbrNames.add(testResult.getMbr_cname());
	}
	
	//检测出阳性的内容
	private List<TestResult> checkOutYs = new ArrayList<TestResult>();
	
	
	private void setCheckOutY(TestResult testResult) {
		String test_result = testResult.getTest_reasult();
		if(test_result.indexOf("未检出") == -1 && test_result.indexOf("<") == -1) {
			checkOutYs.add(testResult);
		}
	}
	
	public List<TestResult> getCheckOutY() {
		return this.checkOutYs;
	}
		
}
