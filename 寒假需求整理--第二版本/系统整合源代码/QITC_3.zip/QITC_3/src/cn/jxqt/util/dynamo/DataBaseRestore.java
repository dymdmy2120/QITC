package cn.jxqt.util.dynamo;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import org.web.exception.ErrorException;

import tool.mastery.db.DBUtil;
import cn.jxqt.util.ReadDbProUtil;

/**
 * @author ASUS 对数据库文件还原
 * 
 */
public class DataBaseRestore implements IRestore {
	private String DB_DBName = null;
	private String DB_Password = null;
	private String DB_DataBaseName = null;

	public DataBaseRestore() {
		DB_DBName = ReadDbProUtil.getDB_DBName();
		DB_Password = ReadDbProUtil.getDB_Password();
		DB_DataBaseName = ReadDbProUtil.getDB_DataBaseName();

	}

	public boolean restore(String sourcePath, String destPath) throws ErrorException {
		// TODO Auto-generated method stub
		if(DBUtil.getConnection() == null)
			throw new ErrorException("数据库服务还没开启");
		boolean flag = false;
		OutputStream out = null;
		BufferedReader br = null;
		OutputStreamWriter writer = null;
		// 导入的时候需要数据库已经建好。
		try {
			// LockDbTableUtil.locktables();
			Runtime rt = Runtime.getRuntime();
			String dataPath = "mysql -h " + "localhost" + " -u" + DB_DBName
					+ " -p" + DB_Password + " " + DB_DataBaseName;
			// String
			// dataPath="mysql -h localhost -uroot -p123 "+DB_DataBaseName;
			Process child = rt.exec(dataPath);
			out = child.getOutputStream();// 控制台的输入信息作为输出流
			String inStr;
			StringBuffer sb = new StringBuffer("");
			String outStr;
			br = new BufferedReader(new InputStreamReader(
			new FileInputStream(sourcePath), "utf8"));
			while ((inStr = br.readLine()) != null) {
				sb.append(inStr + "\r\n");
			}
			outStr = sb.toString();
			writer = new OutputStreamWriter(out, "utf8");
			writer.write(outStr);
			// 注：这里如果用缓冲方式写入文件的话，会导致中文乱码，用flush()方法则可以避免

			writer.flush();
			flag = true;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new ErrorException("请正确上传恢复数据的zip文件！");
		} catch (Exception e) {
			e.printStackTrace();
			throw new ErrorException("数据恢复失败");
		} finally {
			// 释放读锁
			// LockDbTableUtil.unlock();
			// 别忘记关闭输入输出流
			try {
				if (out != null)
					out.close();

				if (br != null)
					br.close();
				if (writer != null)
					writer.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new ErrorException("数据恢复失败");
			}

		}

		return flag;
	}

}
