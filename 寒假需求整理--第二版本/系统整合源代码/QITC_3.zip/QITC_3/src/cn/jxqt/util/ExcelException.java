package cn.jxqt.util;
/**
 * 读取excel文件抛出的异常。
 * @author Administrator
 */
public class ExcelException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
	
	public ExcelException(String message)
	{
		super(message);
	}
	@Override
	public StackTraceElement[] getStackTrace() {
		// TODO Auto-generated method stub
		return super.getStackTrace();
	}

}
