package cn.jxqt.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.MDC;

import cn.jxqt.po.User;

public class LogUtil {
	public static String getIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("http_client_ip");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		// 如果是多级代理，那么取第一个ip为客户ip
		if (ip != null && ip.indexOf(",") != -1) {
			ip = ip.substring(ip.lastIndexOf(",") + 1, ip.length()).trim();
		}
		return ip;
	}
	
	public static void setMDC(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");
		String u_id = user.getU_id();
		String u_name = user.getU_name();
		String ip = LogUtil.getIpAddr(request);
		if(u_id != null) {
			MDC.put("u_id", u_id);
		} else {
			MDC.put("u_id", "");
		}
		if(u_name != null) {
			MDC.put("u_name", u_name);
		} else {
			MDC.put("u_name", "");
		}
		if(ip != null) {
			MDC.put("ip", ip);
		} else {
			MDC.put("ip", "");
		}

	}
	
	public static String getOperateName(String operate) {
		if(operate.equalsIgnoreCase("delete")) {
			return "删除";
		} else if(operate.equalsIgnoreCase("update")) {
			return "修改";
		} else {
			return "添加";
		}
		
	}
	
	public static String getViewName(String name, String category) {
		String viewName = "";
		if(name!= null && name.equals("Alarm") && category != null) {
			if(category.equals("0")) {
				viewName = "境外食品风险预警";
			} else {
				viewName = "国内食品风险预警";
			}
		} else if(name!= null && name.equals("Laws") && category != null) {
			if(category.equals("0")) {
				viewName = "国家法律";
			} else if(category.equals("1")){
				viewName = "食品法规";
			} else if(category.equals("2")) {
				viewName = "进出境法规";
			} else if(category.equals("3")) {
				viewName = "国际法规";
			} else {
				viewName = "其他相关法规";
			}
		} else if(name!= null && name.equals("Standard") && category != null) {
			if(category.startsWith("0")) {
				viewName = "国内食品标准";
			} else {
				viewName = "国外食品标准";
			}
		} else if(name!= null && name.equals("Hazards") && category != null) {
			if(category.startsWith("0")) {
				viewName = "国内限量标准";
			} else {
				viewName = "国外限量标准";
			}
		}
		if(name != null && name.equals("Laboratory")) {
			viewName = "实验室";
		} else if(name != null && name.equals("LabApt")) {
			viewName = "实验室资质";
		} else if(name != null && name.equals("LabTest")) {
			viewName = "实验室检测经历";
		} else if(name != null && name.equals("Typical")) {
			viewName = "实验室典型案例";
		}
		if(viewName.equals("")) {
			viewName = "审核消息";
		}
		return viewName;
	}
}
