package cn.jxqt.util;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;
import org.apache.tools.zip.ZipOutputStream;
import org.web.exception.ErrorException;

public class ZipUtil {
	
	public static void zip(String source, String zipFileName)
			throws IOException {

		ZipOutputStream zos = new ZipOutputStream(new File(zipFileName));
		// 设置压缩的时候文件名编码为gb2312
		zos.setEncoding("gb2312");
		File f = new File(source);
		if (f.isDirectory()) {
			// 如果直接压缩文件夹
			analysisDir(source, zos, f.getName() + "/");// 此处使用/来表示目录，如果使用\\来表示目录的话，会导致压缩后的文件目录组织形式在解压缩的时候不能正确识别。
		} else {// 如果直接压缩文件
			analysisDir(f.getPath(), zos, new File(f.getParent()).getName()
					+ "/");
			analysisFile(f.getPath(), zos, new File(f.getParent()).getName()
					+ "/" + f.getName());

		}
		zos.closeEntry();
		zos.close();
	}

	// 　　/**
	// * analysisFile方法，专门将指定的文件压缩成为zip文件的方法
	// 　　 * zip 压缩单个文件。 除非有特殊需要，否则请调用ZIP方法来压缩文件！
	// 　　 *
	// 　　 * @param sourceFileName
	// 　　 * 要压缩的原文件
	// 　　 * @param zipFileName
	// 　　 * 压缩后的文件名
	// 　　 * @throws IOException
	// 　　 *
	// */
	private static void analysisFile(String sourceFileName, ZipOutputStream zos,
			String tager) throws IOException {
		System.out.println(tager);
		ZipEntry ze = new ZipEntry(tager);
		zos.putNextEntry(ze);
		FileInputStream fis = new FileInputStream(new File(sourceFileName));
		byte[] bf = new byte[2048];
		int location = 0;
		while ((location = fis.read(bf)) != -1) {
			zos.write(bf, 0, location);
		}
		fis.close();
	}

	/**
	 * analysisDir方法，专门在ZIP文件中添加文件夹的方法 　
	 * 					　 压缩目录。 除非有特殊需要，否则请调用ZIP方法来压缩文件！ 　　
	 * 
	 * @param sourceDir
	 *            需要压缩的目录位置 　　
	 * @param zos
	 *            　　 压缩到的zip文件 　　
	 * @param tager
	 *            压缩到的目标位置
	 * @throws IOException
	 *             　压缩文件的过程中可能会抛出IO异常，请自行处理该异常。 　　
	 */
	private static void analysisDir(String sourceDir, ZipOutputStream zos,
			String tager) throws IOException {

		ZipEntry ze = new ZipEntry(tager);
		zos.putNextEntry(ze);
		// 提取要压缩的文件夹中的所有文件
		File f = new File(sourceDir);
		File[] flist = f.listFiles();
		if (flist != null) {
			// 如果该文件夹下有文件则提取所有的文件进行压缩
			for (File fsub : flist) {
				if (fsub.isDirectory()) {

					// 如果是目录则进行目录压缩
					analysisDir(fsub.getPath(), zos, tager + fsub.getName()
							+ "/");
				} else {
					// 如果是文件，则进行文件压缩

					analysisFile(fsub.getPath(), zos, tager + fsub.getName());

				}
			}
		}
	}

	/**
	 * 解压zip文件
	 * 
	 * @param sourceFileName
	 * @param desDir
	 * @throws IOException
	 */
	public static void UnZIP(String sourceFileName, String desDir)
			throws IOException,ErrorException {
		String[] fileNameArry = sourceFileName.split("\\.");
		String extName = fileNameArry[fileNameArry.length-1];
		//若上传的文件不为zip问直接抛出异常
		System.out.println(!"ZIP".equals(extName)+"");
		if((!"zip".equals(extName))&&(!"ZIP".equals(extName)))
		throw new ErrorException("请上传格式为zip的文件");
		
		
		
		ZipFile zf = new ZipFile(new File(sourceFileName));
		Enumeration<ZipEntry> en = zf.getEntries();
		int length = 0;
		byte[] b = new byte[2048];
		
		// 提取压缩文件夹中的所有压缩实例对象
		while (en.hasMoreElements()) {  
			ZipEntry ze = en.nextElement();
			String zipName="";//压缩文件中的名字
			try{
			zipName=ze.getName().substring(0,8);
			}catch(StringIndexOutOfBoundsException e){
				throw new ErrorException("请正确上传恢复数据的zip文件！");
			}
			if(zipName.equals("JxQtData"))
			{
			// 创建解压缩后的文件实例对象
			File f = new File(desDir + ze.getName());
			// 如果当前压缩文件中的实例对象是文件夹就在解压缩后的文件夹中创建该文件夹
			if (ze.isDirectory()) {
				f.mkdirs();
			} else {
				// 如果当前解压缩文件的父级文件夹没有创建的话，则创建好父级文件夹
				if (!f.getParentFile().exists()) {
					f.getParentFile().mkdirs();
					
				}
				// 将当前文件的内容写入解压后的文件夹中。
				OutputStream outputStream = new FileOutputStream(f);
				InputStream inputStream = zf.getInputStream(ze);
				while ((length = inputStream.read(b)) > 0) {
					outputStream.write(b, 0, length);
				}
				inputStream.close();
				outputStream.close();
				
				}
			
			}
			else
			{
			System.out.println(zipName);
			break;
		
		}
		}
		zf.close();
	}

	public static void main(String[] args) throws IOException, ErrorException{
		
		ZipUtil z=new ZipUtil();
		//z.zip("F:/Data","F:/gg.zip");
		z.UnZIP("D:/tomcat/apache-tomcat-7.0.47/webapps/QITC_2/JxQtData/upload/20121519 曾新宇.doc","F:/");
	
	}
	
	
}
