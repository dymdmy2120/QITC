package cn.jxqt.util;

import java.io.File;

public class FileDelete {
	public static void deleteFile(String filePath) {
		FileDelete.delete(filePath);
	}
	private static void delete(String filePath) {
		File f = new File(filePath);  // 输入要删除的文件位置
		if(filePath.indexOf("xls") != -1){
			if(f.exists()){
			    f.delete();
			}
		}
	 }
  }
