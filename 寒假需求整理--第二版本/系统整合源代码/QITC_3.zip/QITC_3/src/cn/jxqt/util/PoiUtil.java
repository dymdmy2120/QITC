package cn.jxqt.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class PoiUtil{
	public static void main(String[] args){
		PoiUtil poi = new PoiUtil();
		try {
			List<List<String>> excelContent = poi.readExcel("D://测试数据//预警通报表.xls");
			poi.printOneExcel(excelContent);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	// 打印Excel内容；
	public void printOneExcel(List<List<String>> excelContent) {
		for (int j = 0; j < excelContent.size(); j++) {
			List<String> oneLine = (List<String>) excelContent.get(j);
			System.out.println(oneLine);
		}
	}
	// 读取一个Excel文件；
	public List<List<String>> readExcel(String fileURL)throws IOException {
		String fileFormat = fileURL.substring(fileURL.lastIndexOf(".")+1, fileURL.length());
		List<List<String>> result = null;
		if(fileFormat.equals("xls")){
			result = this.readXLSExcel(fileURL);
		}
		if(fileFormat.equals("xlsx")){
			result = this.readXLSXExcel(fileURL);
		}
		return result;
	}
	private List<List<String>> readXLSExcel(String fileURL) throws IOException{
		List<List<String>> ExcelContent = new ArrayList<List<String>>();
		InputStream is = new FileInputStream(fileURL);
		HSSFWorkbook wb = createHSSFWorkbook(is);
		HSSFSheet sheet = wb.getSheetAt(0);
		 
		List<String>[] titleList = getSheetTitle(sheet);
		ExcelContent = getSheetContent(sheet, titleList);
		if (is != null) {
			is.close();
		}
		return ExcelContent;
	}
	private List<List<String>> readXLSXExcel(String fileURL) throws IOException{
		List<List<String>> ExcelContent = new ArrayList<List<String>>();
		InputStream is = new FileInputStream(fileURL);
		
		XSSFWorkbook hssfworkbook = new XSSFWorkbook(is); 
		XSSFSheet sheet = hssfworkbook.getSheetAt(0);
		
		List<String>[] titleList = getXLSXSheetTitle(sheet);
		ExcelContent = getXLSXSheetContent(sheet, titleList);
		return ExcelContent;
	}
	
	//生成HSSFWorkbook对象；
	public HSSFWorkbook createHSSFWorkbook(InputStream is)throws IOException {
		HSSFWorkbook wb = null;
		POIFSFileSystem fs = new POIFSFileSystem(is);
		wb = new HSSFWorkbook(fs);
		return wb;
	}
	//获取表头；记录表头属性和属性所在列
	private List<String>[] getSheetTitle(HSSFSheet sheet){
		List<String> sheetTitle[] = new ArrayList[2];
		sheetTitle[0] = new ArrayList<String>();//记录表头属性；
		sheetTitle[1] = new ArrayList<String>();//记录表头属性列的序号；
		HSSFRow row = sheet.getRow(0);
		HSSFCell cell = null;
		String cellValue = "";
		if (row != null) {
			for (int i = 0; i < row.getLastCellNum(); i++) {
				cell = row.getCell((short) i);
				if(cell == null){
					continue;
				}
				cellValue = getCellValue(cell);
				if("".equals(cellValue) || cellValue == null){
					
				}else{
					sheetTitle[0].add(cellValue);
					sheetTitle[1].add(String.valueOf(i));
				}
			}
		}
		return sheetTitle;
	}
	private List<String>[] getXLSXSheetTitle(XSSFSheet sheet){
		List<String> sheetTitle[] = new ArrayList[2];
		sheetTitle[0] = new ArrayList<String>();
		sheetTitle[1] = new ArrayList<String>();
		
		XSSFRow row = sheet.getRow(0);
		XSSFCell cell = null;
		String cellValue = "";
		if (row != null) {
			for (int i = 0; i < row.getLastCellNum(); i++) {
				cell = row.getCell((short) i);
				if(cell == null){
					continue;
				}
				cellValue = getXSSFCellValue(cell);
				if("".equals(cellValue) || cellValue == null){
					
				}else{
					sheetTitle[0].add(cellValue);
					sheetTitle[1].add(String.valueOf(i));
				}
			}
		}
		return sheetTitle;
	}
	//获取表的正文；
	private List<List<String>> getSheetContent(HSSFSheet sheet,List<String>[] title){
		int rowCount = sheet.getLastRowNum();
		List<List<String>> sheetContent = new ArrayList<List<String>>(rowCount);
		List<String> sheetRowContent = null;
		sheetContent.add(title[0]);
		
		HSSFRow row = null;
		HSSFCell cell = null;
		String tempCellValue = "";
		
		int colCount = title[1].size();
		for (int i = 1; i <= rowCount; i++) {					//读行
			row = sheet.getRow(i);
			sheetRowContent = new ArrayList<String>();
			if(row == null){
				continue;
			}
			for (int j = 0; j < colCount; j++) {						//读列
				cell = row.getCell(Short.parseShort(title[1].get(j)));
				if(cell == null){
					sheetRowContent.add("");
				}else{
					tempCellValue = getCellValue(cell);
//					if(" ".equals(tempCellValue)){
//						sheetRowContent.add("null");
//					}else{
//						//tempCellValue.replaceAll("\\s+", "");
//						sheetRowContent.add(tempCellValue);
////						sheetRowContent.add(tempCellValue.replaceAll("\\s+", ""));
//					}
					sheetRowContent.add(tempCellValue);
				}
			}
			sheetContent.add(sheetRowContent);
		}
		
		return sheetContent;
	}
	private List<List<String>> getXLSXSheetContent(XSSFSheet sheet,List<String>[] title){
		int rowCount = sheet.getLastRowNum();
		List<List<String>> sheetContent = new ArrayList<List<String>>(rowCount);
		List<String> sheetRowContent = null;
		sheetContent.add(title[0]);
		XSSFRow row = null;
		XSSFCell cell = null;
		String tempCellValue = "";
		
		int colCount = title[1].size();
		for (int i = 1; i <= rowCount; i++) {					//读行
			row = sheet.getRow(i);
			sheetRowContent = new ArrayList<String>();
			if(row == null){
				continue;
			}
			for (int j = 0; j < colCount; j++) {						//读列
				cell = row.getCell(Short.parseShort(title[1].get(j)));
				if(cell == null){
					sheetRowContent.add("null");
				}else{
					tempCellValue = getXSSFCellValue(cell);
//					if(" ".equals(tempCellValue)){
//						sheetRowContent.add("null");
//					}else{
//						//tempCellValue.replaceAll("\\s+", "");
//						sheetRowContent.add(tempCellValue);
////						sheetRowContent.add(tempCellValue.replaceAll("\\s+", ""));
//					}
					sheetRowContent.add(tempCellValue);
				}
			}
			sheetContent.add(sheetRowContent);
		}
		
		return sheetContent;
	}
	
	//获取表内列中的数据；
	@SuppressWarnings("deprecation")
	private String getCellValue(HSSFCell hssfCell){
		int cellValueType = hssfCell.getCellType();
		if(cellValueType == HSSFCell.CELL_TYPE_STRING){
			if(hssfCell.getHyperlink() != null){
				return hssfCell.getHyperlink().getAddress();
			}
			return String.valueOf(hssfCell.getStringCellValue());
		}else if(cellValueType == HSSFCell.CELL_TYPE_NUMERIC){
			if(HSSFDateUtil.isCellDateFormatted(hssfCell)){//时间
				java.util.Date date = hssfCell.getDateCellValue();
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				return sdf.format(date);
			}
			if(String.valueOf(hssfCell.getNumericCellValue()).indexOf("E") == -1){		//判定小数
				return String.valueOf(hssfCell.getNumericCellValue());
			}
			long temp = (long)hssfCell.getNumericCellValue();							//长整型去除科学计数法
			return String.valueOf(temp);
		}else if(hssfCell.getCellType() == HSSFCell.CELL_TYPE_BOOLEAN) {
            return String.valueOf(hssfCell.getBooleanCellValue());
        }else if(hssfCell.getCellType() == HSSFCell.CELL_TYPE_BLANK) {
            return "null";
        }
		return "null";
	}
	/**
	 * 读取xlsx文件类型列数据；
	 * @param cell
	 * @return
	 * @throws Exception
	 */
	private String getXSSFCellValue(XSSFCell cell){
		DecimalFormat df = new DecimalFormat("0");// 格式化 number String
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 格式化日期字符串
		DecimalFormat nf = new DecimalFormat("0");// 格式化数字 
		
		int cellValueType = cell.getCellType();
		if(cellValueType == HSSFCell.CELL_TYPE_STRING){
			if(cell.getHyperlink() != null){
				return cell.getHyperlink().getAddress();
			}
			return String.valueOf(cell.getStringCellValue());
		}else if(cellValueType == HSSFCell.CELL_TYPE_NUMERIC){
		    if("@".equals(cell.getCellStyle().getDataFormatString())) {
		    	 return df.format(cell.getNumericCellValue());
		    }else if ("General".equals(cell.getCellStyle().getDataFormatString())){
		    	return nf.format(cell.getNumericCellValue());     
		    }else {
		    	return sdf.format(HSSFDateUtil.getJavaDate(cell.getNumericCellValue()));
		    }
		}else if(cell.getCellType() == HSSFCell.CELL_TYPE_BOOLEAN) {
            return String.valueOf(cell.getBooleanCellValue());
        }else if(cell.getCellType() == HSSFCell.CELL_TYPE_BLANK) {
            return "null";
        }
		return "null";
	   }  
}
