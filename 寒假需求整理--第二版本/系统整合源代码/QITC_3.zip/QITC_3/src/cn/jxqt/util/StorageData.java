package cn.jxqt.util;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

//存储查询出来的数据
public class StorageData {

	private static Map<String, Object[]> sotrageMap = new HashMap<String, Object[]>();

	private StorageData() {

	}

	// 将查询出来的数据缓存到Map集合中去
	public static void sotrage(String key, Object[] values) {
		sotrageMap.put(key, values);
	}

	/**
	 * 根据传入的key 得到该用户查询出来的数据，然后和传入的对象比较 判断是否已经存在
	 * 
	 * @param key
	 * @param obj
	 * @return
	 */
	public static boolean isExisted(String key, Object obj) {

		if (obj == null || sotrageMap.size() == 0) {
			return false;
		}

		Object temp = sotrageMap.get(key)[0];
		if (obj.equals(temp)) {
			return true;
		}
		return false;
	}

	// 根据key 得到缓存的数据
	public static Object[] getData(String key) {
		return sotrageMap.get(key);
	}

	public static boolean remove(String key) {
		boolean flag = false;
		if (sotrageMap.remove(key) != null) {
			flag = true;
		}
		return flag;

	}
}
