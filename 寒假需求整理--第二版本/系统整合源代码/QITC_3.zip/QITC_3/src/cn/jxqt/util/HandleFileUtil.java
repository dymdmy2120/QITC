package cn.jxqt.util;

import java.io.File;

/**
 * @author ASUS 此类对文件进行添加 删除
 * 
 */
public class HandleFileUtil {

	/**
	 * 删除一个文件夹和文件
	 * 
	 * @param folderPath
	 */
	public static boolean deleteFile(String delpath) {

		try {
			File file = new File(delpath);
			// 当且仅当此抽象路径名表示的文件存在且 是一个目录时，返回 true
			if (!file.isDirectory()) {
				file.delete();
			} else if (file.isDirectory()) {
				String[] filelist = file.list();
				for (int i = 0; i < filelist.length; i++) {
					File delfile = new File(delpath + "\\" + filelist[i]);
					if (!delfile.isDirectory()) {
						delfile.delete();
						System.out
								.println(delfile.getAbsolutePath() + "删除文件成功");
					} else if (delfile.isDirectory()) {
						deleteFile(delpath + "\\" + filelist[i]);
					}
				}
				System.out.println(file.getAbsolutePath() + "删除成功");
				file.delete();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return true;
	}
}
