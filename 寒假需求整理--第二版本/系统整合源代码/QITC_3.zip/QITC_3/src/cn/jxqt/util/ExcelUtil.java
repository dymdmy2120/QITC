package cn.jxqt.util;

import tool.mastery.core.ClassUtil;
/**
 * 获取数据统计分析中的实体类。
 * @author zxb
 */
public class ExcelUtil {
	private static String TEST_STATISTICSALAY = "cn.jxqt.vo.statisticsalaysis.";
	public static Class<?> getTSByName(String className) throws Exception{
		return ClassUtil.getClassByName(TEST_STATISTICSALAY + className);
	}
}
