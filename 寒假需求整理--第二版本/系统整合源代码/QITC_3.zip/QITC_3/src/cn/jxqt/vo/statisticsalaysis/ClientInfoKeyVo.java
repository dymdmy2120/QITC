package cn.jxqt.vo.statisticsalaysis;

import java.io.Serializable;

public class ClientInfoKeyVo implements Serializable {
	private String firstSupper;
	private String secondSupper;
	public String getFirstSupper() {
		return firstSupper;
	}
	public void setFirstSupper(String firstSupper) {
		this.firstSupper = firstSupper;
	}
	public String getSecondSupper() {
		return secondSupper;
	}
	public void setSecondSupper(String secondSupper) {
		this.secondSupper = secondSupper;
	}
	
}
