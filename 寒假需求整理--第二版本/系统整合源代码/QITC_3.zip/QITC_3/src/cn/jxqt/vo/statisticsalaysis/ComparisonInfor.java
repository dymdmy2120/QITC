package cn.jxqt.vo.statisticsalaysis;

import java.util.List;

public class ComparisonInfor extends Prototype{
	private String pro_name;			//产品名称
	private String mbr_cname;			//危害物名称
	private String result;				//检测结果
	private List<String> list;

	public String getPro_name() {
		return pro_name;
	}

	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}

	public String getMbr_cname() {
		return mbr_cname;
	}

	public void setMbr_cname(String mbr_cname) {
		this.mbr_cname = mbr_cname;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public List<String> getList() {
		return list;
	}

	public void setList(List<String> list) {
		this.list = list;
	}
}
