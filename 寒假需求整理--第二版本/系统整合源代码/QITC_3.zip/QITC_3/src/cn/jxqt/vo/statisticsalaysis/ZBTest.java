package cn.jxqt.vo.statisticsalaysis;
public class ZBTest extends Prototype{
	private String name;
	private float typeCounts = 0;
	private float testOutCounts = 0;
	private String testOutPercent = "0";
	
	public ZBTest(){
		
	}
	public ZBTest(String name){
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getTypeCounts() {
		return typeCounts;
	}
	public void setTypeCounts(float typeCounts) {
		this.typeCounts = typeCounts;
	}
	public float getTestOutCounts() {
		return testOutCounts;
	}
	public void setTestOutCounts(float testOutCounts) {
		this.testOutCounts = testOutCounts;
	}
	public String getTestOutPercent() {
		return testOutPercent;
	}
	public void setTestOutPercent(String testOutPercent) {
		this.testOutPercent = testOutPercent;
	}
	@Override
	public String toString() {
		return "ZBTest [name=" + name + ", typeCounts=" + typeCounts
				+ ", testOutCounts=" + testOutCounts + ", testOutPercent="
				+ testOutPercent + "]";
	}
}
