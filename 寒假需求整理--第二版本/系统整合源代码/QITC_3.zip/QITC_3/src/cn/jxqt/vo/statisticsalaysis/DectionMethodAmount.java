package cn.jxqt.vo.statisticsalaysis;

public class DectionMethodAmount extends Prototype{
	@Override
	public String toString() {
		return "DectionMethodAmount [detectionMethod=" + detectionMethod
				+ ", methodNumber=" + methodNumber + ", methodRate="
				+ methodRate + "]";
	}
	private static DectionMethodAmount instance = null;
	public static synchronized DectionMethodAmount getInstance() {
		if (instance == null) {
			instance = new DectionMethodAmount();
		}
		return instance;
	}
	private String detectionMethod;//检测方法
	private int methodNumber;//检测方法使用频次
	private String methodRate;//使用频率
	public String getDetectionMethod() {
		return detectionMethod;
	}
	public void setDetectionMethod(String detectionMethod) {
		this.detectionMethod = detectionMethod;
	}
	public int getMethodNumber() {
		return methodNumber;
	}
	public void setMethodNumber(int methodNumber) {
		this.methodNumber = methodNumber;
	}
	public String getMethodRate() {
		return methodRate;
	}
	public void setMethodRate(String methodRate) {
		this.methodRate = methodRate;
	}

	public void show(){
		System.out.println("原型模式启动中");
	}
}
