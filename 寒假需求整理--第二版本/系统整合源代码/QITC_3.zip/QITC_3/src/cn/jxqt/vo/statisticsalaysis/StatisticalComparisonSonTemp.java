package cn.jxqt.vo.statisticsalaysis;

import java.util.List;

public class StatisticalComparisonSonTemp {
	// 匹配好已经找到的检测项目数据
	private String limitStands;
	private int findedNumber;
	private String rateFind;
	private List<String> findedDatectionItem;
	// 没有找到限量标准的检测项目数据
	private int notFindNumber;
	private String rateNotFind;
	private List<String> notFindDetectionItem;

	public String getLimitStands() {
		return limitStands;
	}

	public void setLimitStands(String limitStands) {
		this.limitStands = limitStands;
	}

	public int getFindedNumber() {
		return findedNumber;
	}

	public void setFindedNumber(int findedNumber) {
		this.findedNumber = findedNumber;
	}

	public String getRateFind() {
		return rateFind;
	}

	public void setRateFind(String rateFind) {
		this.rateFind = rateFind;
	}

	public List<String> getFindedDatectionItem() {
		return findedDatectionItem;
	}

	public void setFindedDatectionItem(List<String> findedDatectionItem) {
		this.findedDatectionItem = findedDatectionItem;
	}

	public int getNotFindNumber() {
		return notFindNumber;
	}

	public void setNotFindNumber(int notFindNumber) {
		this.notFindNumber = notFindNumber;
	}

	public String getRateNotFind() {
		return rateNotFind;
	}

	public void setRateNotFind(String rateNotFind) {
		this.rateNotFind = rateNotFind;
	}

	public List<String> getNotFindDetectionItem() {
		return notFindDetectionItem;
	}

	public void setNotFindDetectionItem(List<String> notFindDetectionItem) {
		this.notFindDetectionItem = notFindDetectionItem;
	}

}
