package cn.jxqt.vo.statisticsalaysis;

public class StatisticalComparisonKeyVo {

}
