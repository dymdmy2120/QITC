package cn.jxqt.vo;

import java.io.Serializable;

@SuppressWarnings("serial")
public class AlarmSta implements Serializable{
	private String year;//预警通报的年份
	private String bmonth;//预警通报的起始月份
	private String emonth;//预警通报的终止月份
	private String district; //预警通报的地区 (境外 境内 境外内)
	private String title;//预警通报的标题
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getBmonth() {
		return bmonth;
	}
	public void setBmonth(String bmonth) {
		this.bmonth = bmonth;
	}
	public String getEmonth() {
		return emonth;
	}
	public void setEmonth(String emonth) {
		this.emonth = emonth;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bmonth == null) ? 0 : bmonth.hashCode());
		result = prime * result
				+ ((district == null) ? 0 : district.hashCode());
		result = prime * result + ((emonth == null) ? 0 : emonth.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + ((year == null) ? 0 : year.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AlarmSta other = (AlarmSta) obj;
		if (bmonth == null) {
			if (other.bmonth != null)
				return false;
		} else if (!bmonth.equals(other.bmonth))
			return false;
		if (district == null) {
			if (other.district != null)
				return false;
		} else if (!district.equals(other.district))
			return false;
		if (emonth == null) {
			if (other.emonth != null)
				return false;
		} else if (!emonth.equals(other.emonth))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (year == null) {
			if (other.year != null)
				return false;
		} else if (!year.equals(other.year))
			return false;
		return true;
	}
	
}