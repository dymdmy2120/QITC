package cn.jxqt.vo.statisticsalaysis;


import java.util.Arrays;

public class CountData {
	private int times;//检测项目数
	private int kind;//种类数
	private int testOutTimes;//检出频次
	private int testOutKind;//检出种类
	private String[] firstFive;//检出最多的（前五）数据
	private int firstTestOutTimes;//检出最多项目的次数
	
	public CountData(){
		
	}
	
	public int getTimes() {
		return times;
	}
	public void setTimes(int times) {
		this.times = times;
	}
	public int getKind() {
		return kind;
	}
	public void setKind(int kind) {
		this.kind = kind;
	}
	public int getTestOutTimes() {
		return testOutTimes;
	}
	public void setTestOutTimes(int testOutTimes) {
		this.testOutTimes = testOutTimes;
	}
	public int getTestOutKind() {
		return testOutKind;
	}
	public void setTestOutKind(int testOutKind) {
		this.testOutKind = testOutKind;
	}
	public String[] getFirstFive() {
		return firstFive;
	}
	public void setFirstFive(String[] firstFive) {
		this.firstFive = firstFive;
	}
	public int getFirstTestOutTimes() {
		return firstTestOutTimes;
	}
	public void setFirstTestOutTimes(int firstTestOutTimes) {
		this.firstTestOutTimes = firstTestOutTimes;
	}

	@Override
	public String toString() {
		return "CountData [times=" + times + ", kind=" + kind
				+ ", testOutTimes=" + testOutTimes + ", testOutKind="
				+ testOutKind + ", firstFive=" + Arrays.toString(firstFive)
				+ ", firstTestOutTimes=" + firstTestOutTimes + "]";
	}
}
