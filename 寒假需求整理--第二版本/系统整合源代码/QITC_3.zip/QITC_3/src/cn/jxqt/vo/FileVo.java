package cn.jxqt.vo;

import java.io.Serializable;
import java.util.Date;

public class FileVo implements Serializable,Comparable<FileVo> , Cloneable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int fileVoId;
	private Object vo;
	private String operate;
	private Date time;
	private String u_name;
	private String u_id;
	private String reason;
	public String getU_name() {
		return u_name;
	}
	public void setU_name(String u_name) {
		this.u_name = u_name;
	}
	public String getU_id() {
		return u_id;
	}
	public void setU_id(String u_id) {
		this.u_id = u_id;
	}
	public Object getVo() {
		return vo;
	}
	public void setVo(Object vo) {
		this.vo = vo;
	}
	public String getOperate() {
		return operate;
	}
	public void setOperate(String operate) {
		this.operate = operate;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}

	/* (non-Javadoc)
	 * 
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(FileVo o) {
		if(this.time.getTime() < o.getTime().getTime()) {
			return 1;
		}else if(this.time.getTime() == o.getTime().getTime()) {
			return 0;
		}else {
			return -1;
		}
	}
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof FileVo) {
			FileVo fileVo = (FileVo)obj;
			if(this.fileVoId == fileVo.getFileVoId()) {
				return true;
			}
		}
		return super.equals(obj);
	}
	
	public int getFileVoId() {
		return this.fileVoId;
	}
	public void setFileVoId(int fileVoId) {
		this.fileVoId = fileVoId;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	@Override
	public String toString() {
		return "FileVo [fileVoId=" + fileVoId + ", vo=" + vo + ", operate="
				+ operate + ", time=" + time + ", u_name=" + u_name + ", u_id="
				+ u_id + ", reason=" + reason + "]";
	}

}
