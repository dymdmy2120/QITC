package cn.jxqt.vo.statisticsalaysis;

import java.util.ArrayList;
import java.util.List;


public class DatectionSampleKeyVo extends Prototype{
	private int varietiesNumber;//样品品种数量
	private List<String> rankingOneTofive = new ArrayList<String>();//检测样品前五
	private int varietiesAmount;//检测样品总数
	private int detectionAmount;//检出样品总数
	private String ratio;//总的样品检出率
	private String largeDetection;//最大检出样品名称
	private int tempFlag;//检出次数
	public int getVarietiesNumber() {
		return varietiesNumber;
	}
	public void setVarietiesNumber(int varietiesNumber) {
		this.varietiesNumber = varietiesNumber;
	}
	public List<String> getRankingOneTofive() {
		return rankingOneTofive;
	}
	public void setRankingOneTofive(List<String> rankingOneTofive) {
		this.rankingOneTofive = rankingOneTofive;
	}
	public int getVarietiesAmount() {
		return varietiesAmount;
	}
	public void setVarietiesAmount(int varietiesAmount) {
		this.varietiesAmount = varietiesAmount;
	}
	public int getDetectionAmount() {
		return detectionAmount;
	}
	public void setDetectionAmount(int detectionAmount) {
		this.detectionAmount = detectionAmount;
	}
	
	public String getRatio() {
		return ratio;
	}
	public void setRatio(String ratio) {
		this.ratio = ratio;
	}
	public String getLargeDetection() {
		return largeDetection;
	}
	public void setLargeDetection(String largeDetection) {
		this.largeDetection = largeDetection;
	}
	public int getTempFlag() {
		return tempFlag;
	}
	public void setTempFlag(int tempFlag) {
		this.tempFlag = tempFlag;
	}
}
