package cn.jxqt.vo.statisticsalaysis;


public class ClientInfoSituation extends Prototype{

	@Override
	public String toString() {
		return "ClientInfoSituation [id=" + id + ", clientName=" + clientName
				+ ", inspectionNumber=" + inspectionNumber
				+ ", inspectionRate=" + inspectionRate + ", address=" + address
				+ "]";
	}
	private int id;
	private String clientName;
	private int inspectionNumber;
	private String inspectionRate;
	private String address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	public int getInspectionNumber() {
		return inspectionNumber;
	}
	public void setInspectionNumber(int inspectionNumber) {
		this.inspectionNumber = inspectionNumber;
	}
	public String getInspectionRate() {
		return inspectionRate;
	}
	public void setInspectionRate(String inspectionRate) {
		this.inspectionRate = inspectionRate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
}
