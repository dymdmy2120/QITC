package cn.jxqt.vo;

import java.util.Arrays;

/**
 * 用户工作量表
 * 
 * @author Administrator
 * 
 */
public class WorkLoad {

	private String u_id; // 用户编号;
	private String u_name; // 姓名;
	private String department; // 科室;
	private Integer monthWorkSize; // 月工作量
	private Integer yearWorkSize; // 年工作量
	private String workTime; // 操作时间
	private String createtime;
	private String log_msg;

	public String getLog_msg() {
		return log_msg;
	}

	public void setLog_msg(String log_msg) {
		this.log_msg = log_msg;
	}

	public String getU_id() {
		return u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getU_name() {
		return u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Integer getMonthWorkSize() {
		return monthWorkSize;
	}

	public void setMonthWorkSize(Integer monthWorkSize) {
		this.monthWorkSize = monthWorkSize;
	}

	public String getWorkTime() {
		return workTime;
	}

	public void setWorkTime(String workTime) {
		this.workTime = workTime;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public Integer getYearWorkSize() {
		return yearWorkSize;
	}

	public void setYearWorkSize(Integer yearWorkSize) {
		this.yearWorkSize = yearWorkSize;
	}

	@Override
	public String toString() {
		return "WorkLoad [u_id=" + u_id + ", u_name=" + u_name
				+ ", department=" + department + ", monthWorkSize="
				+ monthWorkSize + ", yearWorkSize=" + yearWorkSize
				+ ", workTime=" + workTime + ", createtime=" + createtime
				+ ", log_msg=" + log_msg + "]";
	}

}
