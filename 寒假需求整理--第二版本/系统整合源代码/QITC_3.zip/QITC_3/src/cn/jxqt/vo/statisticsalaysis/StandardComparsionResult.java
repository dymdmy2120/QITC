package cn.jxqt.vo.statisticsalaysis;



public class StandardComparsionResult extends Prototype{
	
	private int sum;	//可以检测的项目
	private int count;  //全部的检测项目
	private double proper; // 检出比例

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public double getProper() {
		return proper;
	}

	public void setProper(double proper) {
		this.proper = proper;
	}
}
