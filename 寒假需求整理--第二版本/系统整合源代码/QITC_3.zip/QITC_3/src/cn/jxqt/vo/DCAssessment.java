package cn.jxqt.vo;


public class DCAssessment{
	private String p_name;
	private String mbr_cname;
	private String residue;
	private String m_id;
	private String line;
	private long noticeCount;
	public String getP_name() {
		return p_name;
	}
	public String getLine() {
		return line;
	}
	public void setLine(String line) {
		this.line = line;
	}
	public long getNoticeCount() {
		return noticeCount;
	}
	public void setNoticeCount(long noticeCount) {
		this.noticeCount = noticeCount;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getMbr_cname() {
		return mbr_cname;
	}
	public void setMbr_cname(String mbr_cname) {
		this.mbr_cname = mbr_cname;
	}
	public String getResidue() {
		return residue;
	}
	public void setResidue(String residue) {
		this.residue = residue;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}

	


}
