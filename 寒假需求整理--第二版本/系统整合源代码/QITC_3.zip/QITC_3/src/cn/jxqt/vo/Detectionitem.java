package cn.jxqt.vo;

public class Detectionitem {
	private String recovery ;
	private String inspection_id;
	private String p_id;
	private String p_category;
	private String p_name;
	private String client_address;
	private String client_name;
	private String mbr_cname;
	private String test_department;
	private String m_name;
	private String test_reasult;
	private String unit;
	private String evaluation;
	private String registration;
	
	public String getRecovery() {
		return recovery;
	}
	public void setRecovery(String recovery) {
		this.recovery = recovery;
	}
	public String getInspection_id() {
		return inspection_id;
	}
	public void setInspection_id(String inspection_id) {
		this.inspection_id = inspection_id;
	}
	public String getP_id() {
		return p_id;
	}
	public void setP_id(String p_id) {
		this.p_id = p_id;
	}
	public String getP_category() {
		return p_category;
	}
	public void setP_category(String p_category) {
		this.p_category = p_category;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getClient_address() {
		return client_address;
	}
	public void setClient_address(String client_address) {
		this.client_address = client_address;
	}
	public String getClient_name() {
		return client_name;
	}
	public void setClient_name(String client_name) {
		this.client_name = client_name;
	}
	public String getMbr_cname() {
		return mbr_cname;
	}
	public void setMbr_cname(String mbr_cname) {
		this.mbr_cname = mbr_cname;
	}
	public String getTest_department() {
		return test_department;
	}
	public void setTest_department(String test_department) {
		this.test_department = test_department;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getTest_reasult() {
		return test_reasult;
	}
	public void setTest_reasult(String test_reasult) {
		this.test_reasult = test_reasult;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getEvaluation() {
		return evaluation;
	}
	public void setEvaluation(String evaluation) {
		this.evaluation = evaluation;
	}
	public String getRegistration() {
		return registration;
	}
	public void setRegistration(String registration) {
		this.registration = registration;
	}
}	
