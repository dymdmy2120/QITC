package cn.jxqt.vo.statisticsalaysis;

public class DatectionSample extends Prototype{

	@Override
	public String toString() {
		return "DatectionSample [sampleName=" + sampleName + ", sampleNumber="
				+ sampleNumber + ", sampleDetectionNumber="
				+ sampleDetectionNumber + ", sampleDetectionRate="
				+ sampleDetectionRate + "]";
	}
	private String sampleName;//样品名称
	private int sampleNumber;//样品总数
	private int sampleDetectionNumber;//样品检出数量
	private String sampleDetectionRate;//样品检出率
	public String getSampleName() {
		return sampleName;
	}
	public void setSampleName(String sampleName) {
		this.sampleName = sampleName;
	}
	public int getSampleNumber() {
		return sampleNumber;
	}
	public void setSampleNumber(int sampleNumber) {
		this.sampleNumber = sampleNumber;
	}
	public int getSampleDetectionNumber() {
		return sampleDetectionNumber;
	}
	public void setSampleDetectionNumber(int sampleDetectionNumber) {
		this.sampleDetectionNumber = sampleDetectionNumber;
	}
	public String getSampleDetectionRate() {
		return sampleDetectionRate;
	}
	public void setSampleDetectionRate(String sampleDetectionRate) {
		this.sampleDetectionRate = sampleDetectionRate;
	}
	 public void show(){
		 System.out.println("原型模式处理");
	 }
}
