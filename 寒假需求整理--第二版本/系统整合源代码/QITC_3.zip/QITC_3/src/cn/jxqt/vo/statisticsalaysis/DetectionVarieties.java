package cn.jxqt.vo.statisticsalaysis;
public class DetectionVarieties extends Prototype{
	@Override
	public String toString() {
		return "DetectionVarieties [category=" + category + ", sampleNumber="
				+ sampleNumber + ", sampleNumber25=" + sampleNumber25
				+ ", sampleNumber23=" + sampleNumber23 + ", testingNumber="
				+ testingNumber + ", testingNumber25=" + testingNumber25
				+ ", testingNumber23=" + testingNumber23 + "]";
	}
	private static DetectionVarieties instance = null;
	public static synchronized DetectionVarieties getInstance() {
		if (instance == null) {
			instance = new DetectionVarieties();
		}
		return instance;
	}
	private String category;//样品类别
	private int sampleNumber;//委托检验样品
	private int sampleNumber25;//自报检样品
	private int sampleNumber23;//监控检验样品
	private int testingNumber;//委托检验项目次数
	private int testingNumber25;//自报检项目次数
	public int getSampleNumber() {
		return sampleNumber;
	}
	public void setSampleNumber(int sampleNumber) {
		this.sampleNumber = sampleNumber;
	}
	public int getSampleNumber25() {
		return sampleNumber25;
	}
	public void setSampleNumber25(int sampleNumber25) {
		this.sampleNumber25 = sampleNumber25;
	}
	public int getSampleNumber23() {
		return sampleNumber23;
	}
	public void setSampleNumber23(int sampleNumber23) {
		this.sampleNumber23 = sampleNumber23;
	}
	public int getTestingNumber25() {
		return testingNumber25;
	}
	public void setTestingNumber25(int testingNumber25) {
		this.testingNumber25 = testingNumber25;
	}
	public int getTestingNumber23() {
		return testingNumber23;
	}
	public void setTestingNumber23(int testingNumber23) {
		this.testingNumber23 = testingNumber23;
	}
	private int testingNumber23;//监控项目次数
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getTestingNumber() {
		return testingNumber;
	}
	public void setTestingNumber(int testingNumber) {
		this.testingNumber = testingNumber;
	}
	
	public void show (){
		System.out.println("原型模式实现类");
	}

}
