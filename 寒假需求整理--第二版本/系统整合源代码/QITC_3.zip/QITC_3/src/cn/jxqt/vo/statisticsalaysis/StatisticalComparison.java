package cn.jxqt.vo.statisticsalaysis;

import java.util.List;

public class StatisticalComparison extends Prototype{
	private int id;
	private String detectionItm;
	private List<String> standard;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDetectionItm() {
		return detectionItm;
	}
	public void setDetectionItm(String detectionItm) {
		this.detectionItm = detectionItm;
	}
	public List<String> getStandard() {
		return standard;
	}
	public void setStandard(List<String> standard) {
		this.standard = standard;
	}
}
