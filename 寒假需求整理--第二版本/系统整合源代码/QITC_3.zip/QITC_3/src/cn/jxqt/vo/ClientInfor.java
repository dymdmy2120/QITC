package cn.jxqt.vo;

import java.io.Serializable;

public class ClientInfor implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String inspection_id;
	private String p_id;
	private String p_name;
	private String client_name;
	private String Recovery;
	private String client_address;

	public String getInspection_id() {
		return inspection_id;
	}

	public void setInspection_id(String inspection_id) {
		this.inspection_id = inspection_id;
	}

	public String getP_id() {
		return p_id;
	}

	public void setP_id(String p_id) {
		this.p_id = p_id;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getClient_name() {
		return client_name;
	}

	public void setClient_name(String client_name) {
		this.client_name = client_name;
	}

	public String getRecovery() {
		return Recovery;
	}

	public void setRecovery(String recovery) {
		Recovery = recovery;
	}

	public String getClient_address() {
		return client_address;
	}

	public void setClient_address(String client_address) {
		this.client_address = client_address;
	}

	@Override
	public String toString() {
		return "ClientInfor [inspection_id=" + inspection_id + ", p_id=" + p_id
				+ ", p_name=" + p_name + ", client_name=" + client_name
				+ ", Recovery=" + Recovery + ", client_address="
				+ client_address + "]";
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if (obj instanceof ClientInfor) {
			ClientInfor vo = (ClientInfor) obj;
			if (vo.getInspection_id() == this.inspection_id) {
				return true;
			}
		}
		return super.equals(obj);
	}
}
