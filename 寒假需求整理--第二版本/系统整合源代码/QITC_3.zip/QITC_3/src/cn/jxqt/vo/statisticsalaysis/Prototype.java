package cn.jxqt.vo.statisticsalaysis;

import java.util.ArrayList;

public class Prototype implements Cloneable {
	// 使用原型模型，使的jvm直接操作内存中的二进制流，并进行拷贝，并不需要new出内存加以操作，而且不会执行构造方法
	// 大数据遍历的时候运用原型模式可以大大提高效率
	private ArrayList list = new ArrayList();
	public Prototype clone() {
		Prototype prototype = null;
		try {
			prototype = (Prototype) super.clone();
			prototype.list = (ArrayList) this.list.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return prototype;
	}
}
