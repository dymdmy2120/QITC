package cn.jxqt.vo.statisticsalaysis;

import java.util.List;

public class StandardComparsionInfor extends Prototype{
	
	private int id;				//编号
	private String mbr_cname;	//检测项目	
	private List<String> list;	//结果

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getMbr_cname() {
		return mbr_cname;
	}

	public void setMbr_cname(String mbr_cname) {
		this.mbr_cname = mbr_cname;
	}

	public List<String> getList() {
		return list;
	}

	public void setList(List<String> list) {
		this.list = list;
	}
}
