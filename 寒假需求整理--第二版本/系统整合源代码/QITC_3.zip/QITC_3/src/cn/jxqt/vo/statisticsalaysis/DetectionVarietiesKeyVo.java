package cn.jxqt.vo.statisticsalaysis;

public class DetectionVarietiesKeyVo extends Prototype {

	private String category;
	private int amountCategory;
	private int amountTesting;

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getAmountCategory() {
		return amountCategory;
	}

	public void setAmountCategory(int amountCategory) {
		this.amountCategory = amountCategory;
	}

	public int getAmountTesting() {
		return amountTesting;
	}

	public void setAmountTesting(int amountTesting) {
		this.amountTesting = amountTesting;
	}

}
