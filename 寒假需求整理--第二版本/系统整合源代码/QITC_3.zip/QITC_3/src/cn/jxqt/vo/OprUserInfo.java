package cn.jxqt.vo;

public class OprUserInfo {

	private String u_id; // 用户编号;
	private String u_name; // 姓名;
	private String email; // 邮箱;
	private String phone; // 用户电话;
	private String department; // 科室;
	private String p_id; // 用户权限;

	public String getU_id() {
		return this.u_id;
	}

	public void setU_id(String u_id) {
		this.u_id = u_id;
	}

	public String getU_name() {
		return this.u_name;
	}

	public void setU_name(String u_name) {
		this.u_name = u_name;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDepartment() {
		return this.department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getP_id() {
		return this.p_id;
	}

	public void setP_id(String p_id) {
		this.p_id = p_id;
	}

	@Override
	public String toString() {
		return "OprUserInfo [u_id=" + u_id + ", u_name=" + u_name + ", email="
				+ email + ", phone=" + phone + ", department=" + department
				+ ", p_id=" + p_id + "]";
	}

}
