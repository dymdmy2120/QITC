package cn.jxqt.vo.statisticsalaysis;

import java.util.Map;

/**
 * 
 * @author zch 统计检测项目检出与限量库标准对比分析 涉及到的统计集合
 */
public class ComparisonResult extends Prototype{
	private int sum; // 检出的个数
	private double proper; // 检出的比例
	private Map<String, String> map; // 检出的具体内容
	private String sta; //标准
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public double getProper() {
		return proper;
	}
	public void setProper(double proper) {
		this.proper = proper;
	}
	public Map<String, String> getMap() {
		return map;
	}
	public void setMap(Map<String, String> map) {
		this.map = map;
	}
	public String getSta() {
		return sta;
	}
	public void setSta(String sta) {
		this.sta = sta;
	}
}
