package cn.jxqt.vo.statisticsalaysis;

public class DectionMethodAmountKeyVo extends Prototype{

	private int methodNumber;
	private String mainMethod;
	private int mainMethodNumber;
	public int getMethodNumber() {
		return methodNumber;
	}
	public void setMethodNumber(int methodNumber) {
		this.methodNumber = methodNumber;
	}
	public String getMainMethod() {
		return mainMethod;
	}
	public void setMainMethod(String mainMethod) {
		this.mainMethod = mainMethod;
	}
	public int getMainMethodNumber() {
		return mainMethodNumber;
	}
	public void setMainMethodNumber(int mainMethodNumber) {
		this.mainMethodNumber = mainMethodNumber;
	}
	 
	public void show(){
		System.out.println("原型模式启动");
	}
	
}
