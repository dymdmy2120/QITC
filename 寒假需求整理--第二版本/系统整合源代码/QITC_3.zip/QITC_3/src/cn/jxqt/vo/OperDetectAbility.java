package cn.jxqt.vo;

import java.util.Date;

public class OperDetectAbility {
	/*
	 * 限量库
	 */
	private Integer b_id;
	private String b_name;
	private String residue;
	private String e_residue;
	private String limited;
	private String limited_unit;
	private String mea_site;
	private Date effect_date;
	// private Integer category_id for bounds;
	private Integer au_state;

	/**
	 * 实验室测试经历
	 */

	private Integer dete_id;
	private String country;
	private String technology;
	private String person;
	private String mbr_workdate;
	private String cycle;
	private String charge;
	private String isApprove;
	private String isMeasure;
	private String subcontractor;
	private String sub_charge;
	private String sub_lab;
	private String mbr_stop;
	private String mbr_reason;
	private String standby;

	private Integer apt_id; // 资质编号;
	private String mbr_name; // 检测领域;
	private String serial_id; // 序号;
	private String limit_scope; // 限制范围;
	private String explaination; // 说明;
	private String aptutide; // 资质类别;

	private String lab_id; // 实验室编号;
	private String lab_name; // 实验室名称;
	private String address; // 地址;
	private String functionary; // 负责人;
	private String contact; // 联系方式;

	private Integer mbr_id; // 检测项目编号;
	private String cas_id; // CAS号;
	private String mbr_cname; // 中文名称;
	private String mbr_ename; // 英文名称;

	private Integer p_id; // 样品编号;
	private String p_name; // 样品名称;
	private String p_category; // 样品类别;

	private Integer sta_id; // 编号;
	private String m_id; // 标准编号;
	private String m_name; // 标准名称;
	private String sta_class; // 标准类别;
	private java.util.Date rel_date; // 发布日期;
	private java.util.Date imp_date; // 实施日期;
	private String dra_unit; // 发布单位;
	private String sta_state; // 标准状态;
	private String principle; // 原理;
	private String document; // 原文;
	private String met_profile; // 方法概要;
	private Integer category_id; // 类别号;
	private String line; // 方法测定底限;
	private String unit;
	
	
	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public Integer getB_id() {
		return b_id;
	}

	public void setB_id(Integer b_id) {
		this.b_id = b_id;
	}

	public String getB_name() {
		return b_name;
	}

	public void setB_name(String b_name) {
		this.b_name = b_name;
	}

	public String getResidue() {
		return residue;
	}

	public void setResidue(String residue) {
		this.residue = residue;
	}

	public String getE_residue() {
		return e_residue;
	}

	public void setE_residue(String e_residue) {
		this.e_residue = e_residue;
	}

	public String getLimited() {
		return limited;
	}

	public void setLimited(String limited) {
		this.limited = limited;
	}

	public String getLimited_unit() {
		return limited_unit;
	}

	public void setLimited_unit(String limited_unit) {
		this.limited_unit = limited_unit;
	}

	public String getMea_site() {
		return mea_site;
	}

	public void setMea_site(String mea_site) {
		this.mea_site = mea_site;
	}

	public Date getEffect_date() {
		return effect_date;
	}

	public void setEffect_date(Date effect_date) {
		this.effect_date = effect_date;
	}

	public Integer getAu_state() {
		return au_state;
	}

	public void setAu_state(Integer au_state) {
		this.au_state = au_state;
	}

	public Integer getDete_id() {
		return dete_id;
	}

	public void setDete_id(Integer dete_id) {
		this.dete_id = dete_id;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getPerson() {
		return person;
	}

	public void setPerson(String person) {
		this.person = person;
	}

	public String getMbr_workdate() {
		return mbr_workdate;
	}

	public void setMbr_workdate(String mbr_workdate) {
		this.mbr_workdate = mbr_workdate;
	}

	public String getCycle() {
		return cycle;
	}

	public void setCycle(String cycle) {
		this.cycle = cycle;
	}

	public String getCharge() {
		return charge;
	}

	public void setCharge(String charge) {
		this.charge = charge;
	}

	public String getIsApprove() {
		return isApprove;
	}

	public void setIsApprove(String isApprove) {
		this.isApprove = isApprove;
	}

	public String getIsMeasure() {
		return isMeasure;
	}

	public void setIsMeasure(String isMeasure) {
		this.isMeasure = isMeasure;
	}

	public String getSubcontractor() {
		return subcontractor;
	}

	public void setSubcontractor(String subcontractor) {
		this.subcontractor = subcontractor;
	}

	public String getSub_charge() {
		return sub_charge;
	}

	public void setSub_charge(String sub_charge) {
		this.sub_charge = sub_charge;
	}

	public String getSub_lab() {
		return sub_lab;
	}

	public void setSub_lab(String sub_lab) {
		this.sub_lab = sub_lab;
	}

	public String getMbr_stop() {
		return mbr_stop;
	}

	public void setMbr_stop(String mbr_stop) {
		this.mbr_stop = mbr_stop;
	}

	public String getMbr_reason() {
		return mbr_reason;
	}

	public void setMbr_reason(String mbr_reason) {
		this.mbr_reason = mbr_reason;
	}

	public String getStandby() {
		return standby;
	}

	public void setStandby(String standby) {
		this.standby = standby;
	}

	public Integer getApt_id() {
		return apt_id;
	}

	public void setApt_id(Integer apt_id) {
		this.apt_id = apt_id;
	}

	public String getMbr_name() {
		return mbr_name;
	}

	public void setMbr_name(String mbr_name) {
		this.mbr_name = mbr_name;
	}

	public String getSerial_id() {
		return serial_id;
	}

	public void setSerial_id(String serial_id) {
		this.serial_id = serial_id;
	}

	public String getLimit_scope() {
		return limit_scope;
	}

	public void setLimit_scope(String limit_scope) {
		this.limit_scope = limit_scope;
	}

	public String getExplaination() {
		return explaination;
	}

	public void setExplaination(String explaination) {
		this.explaination = explaination;
	}

	public String getAptutide() {
		return aptutide;
	}

	public void setAptutide(String aptutide) {
		this.aptutide = aptutide;
	}

	public String getLab_id() {
		return lab_id;
	}

	public void setLab_id(String lab_id) {
		this.lab_id = lab_id;
	}

	public String getLab_name() {
		return lab_name;
	}

	public void setLab_name(String lab_name) {
		this.lab_name = lab_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFunctionary() {
		return functionary;
	}

	public void setFunctionary(String functionary) {
		this.functionary = functionary;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public Integer getMbr_id() {
		return mbr_id;
	}

	public void setMbr_id(Integer mbr_id) {
		this.mbr_id = mbr_id;
	}

	public String getCas_id() {
		return cas_id;
	}

	public void setCas_id(String cas_id) {
		this.cas_id = cas_id;
	}

	public String getMbr_cname() {
		return mbr_cname;
	}

	public void setMbr_cname(String mbr_cname) {
		this.mbr_cname = mbr_cname;
	}

	public String getMbr_ename() {
		return mbr_ename;
	}

	public void setMbr_ename(String mbr_ename) {
		this.mbr_ename = mbr_ename;
	}

	public Integer getP_id() {
		return p_id;
	}

	public void setP_id(Integer p_id) {
		this.p_id = p_id;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getP_category() {
		return p_category;
	}

	public void setP_category(String p_category) {
		this.p_category = p_category;
	}

	public Integer getSta_id() {
		return sta_id;
	}

	public void setSta_id(Integer sta_id) {
		this.sta_id = sta_id;
	}

	public String getM_id() {
		return m_id;
	}

	public void setM_id(String m_id) {
		this.m_id = m_id;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public String getSta_class() {
		return sta_class;
	}

	public void setSta_class(String sta_class) {
		this.sta_class = sta_class;
	}

	public java.util.Date getRel_date() {
		return rel_date;
	}

	public void setRel_date(java.util.Date rel_date) {
		this.rel_date = rel_date;
	}

	public java.util.Date getImp_date() {
		return imp_date;
	}

	public void setImp_date(java.util.Date imp_date) {
		this.imp_date = imp_date;
	}

	public String getDra_unit() {
		return dra_unit;
	}

	public void setDra_unit(String dra_unit) {
		this.dra_unit = dra_unit;
	}

	public String getSta_state() {
		return sta_state;
	}

	public void setSta_state(String sta_state) {
		this.sta_state = sta_state;
	}

	public String getPrinciple() {
		return principle;
	}

	public void setPrinciple(String principle) {
		this.principle = principle;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public String getMet_profile() {
		return met_profile;
	}

	public void setMet_profile(String met_profile) {
		this.met_profile = met_profile;
	}

	public Integer getCategory_id() {
		return category_id;
	}

	public void setCategory_id(Integer category_id) {
		this.category_id = category_id;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	@Override
	public String toString() {
		return "OperDetectAbility [b_id=" + b_id + ", b_name=" + b_name
				+ ", residue=" + residue + ", e_residue=" + e_residue
				+ ", limited=" + limited + ", limited_unit=" + limited_unit
				+ ", mea_site=" + mea_site + ", effect_date=" + effect_date
				+ ", au_state=" + au_state + ", dete_id=" + dete_id
				+ ", country=" + country + ", technology=" + technology
				+ ", person=" + person + ", mbr_workdate=" + mbr_workdate
				+ ", cycle=" + cycle + ", charge=" + charge + ", isApprove="
				+ isApprove + ", isMeasure=" + isMeasure + ", subcontractor="
				+ subcontractor + ", sub_charge=" + sub_charge + ", sub_lab="
				+ sub_lab + ", mbr_stop=" + mbr_stop + ", mbr_reason="
				+ mbr_reason + ", standby=" + standby + ", apt_id=" + apt_id
				+ ", mbr_name=" + mbr_name + ", serial_id=" + serial_id
				+ ", limit_scope=" + limit_scope + ", explaination="
				+ explaination + ", aptutide=" + aptutide + ", lab_id="
				+ lab_id + ", lab_name=" + lab_name + ", address=" + address
				+ ", functionary=" + functionary + ", contact=" + contact
				+ ", mbr_id=" + mbr_id + ", cas_id=" + cas_id + ", mbr_cname="
				+ mbr_cname + ", mbr_ename=" + mbr_ename + ", p_id=" + p_id
				+ ", p_name=" + p_name + ", p_category=" + p_category
				+ ", sta_id=" + sta_id + ", m_id=" + m_id + ", m_name="
				+ m_name + ", sta_class=" + sta_class + ", rel_date="
				+ rel_date + ", imp_date=" + imp_date + ", dra_unit="
				+ dra_unit + ", sta_state=" + sta_state + ", principle="
				+ principle + ", document=" + document + ", met_profile="
				+ met_profile + ", category_id=" + category_id + ", line="
				+ line + ", unit=" + unit + "]";
	}

}
