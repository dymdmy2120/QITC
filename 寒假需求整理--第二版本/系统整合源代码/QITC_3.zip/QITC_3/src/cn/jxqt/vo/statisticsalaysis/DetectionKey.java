package cn.jxqt.vo.statisticsalaysis;

public class DetectionKey extends Prototype{
	private String p_name;
	private String p_id;
	private String Inspection_id;
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_id() {
		return p_id;
	}
	public void setP_id(String p_id) {
		this.p_id = p_id;
	}
	public String getInspection_id() {
		return Inspection_id;
	}
	public void setInspection_id(String inspection_id) {
		Inspection_id = inspection_id;
	}
	
	
       
}
