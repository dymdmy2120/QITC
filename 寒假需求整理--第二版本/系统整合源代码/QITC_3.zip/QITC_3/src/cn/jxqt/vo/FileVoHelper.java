package cn.jxqt.vo;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.web.framework.Constant;

import cn.jxqt.dao.file.FileSystem;

import tool.mastery.log.LogUtil;


public class FileVoHelper {

	public static final String ADD = "添加";

	public static final String UPDATE = "修改";

	public static final String DELETE = "删除";

	public static final Map<String, Integer> valueMap = new HashMap<String, Integer>();

	/**
	 * 获得当前对应的id
	 * 
	 * @param name
	 * @return
	 * @throws IOException
	 */
	public static Integer getCurrentId(FileSystem fs) throws IOException {
		String name = fs.getFileName();
		// 如果此id为null时，即为初始状态
		if (FileVoHelper.valueMap.get(name) == null) {
			// 之后去对应的文件中查询序号
			List<FileVo> list = fs.getList();
			fs.stopRead();
			// 获取最后一个id
			int lastId = -1;
			if (list.size() != 0) {
				lastId = list.get(list.size() - 1).getFileVoId();
			}
			// 更新map中的值
			FileVoHelper.valueMap.put(name, ++lastId);
		} else {
			// 否则先更新此值后返回
			FileVoHelper.valueMap
					.put(name, FileVoHelper.valueMap.get(name) + 1);
		}
		return FileVoHelper.valueMap.get(name);
	}

	/**
	 * 将操作名转换成中文
	 * 
	 * @param operate
	 * @return
	 */
	public static String changeOperateToChinese(String operate) {
		if (operate != null) {
			if (operate.equalsIgnoreCase(Constant.ADD)
					|| operate.equalsIgnoreCase(Constant.IMPORT)) {
				return ADD;
			} else if (operate.equalsIgnoreCase(Constant.UPDATE)) {
				return UPDATE;
			} else {
				return DELETE;
			}
		}
		return null;
	}

	/**
	 * 将操作名转换成英文
	 * 
	 * @param operate
	 * @return
	 */
	public static String changeOperateToEnglish(String operate) {
		if (operate != null) {
			if (operate.equalsIgnoreCase(ADD)) {
				return Constant.ADD;
			} else if (operate.equalsIgnoreCase(UPDATE)) {
				return Constant.UPDATE;
			} else {
				return Constant.DELETE;
			}
		}
		return null;
	}
}
