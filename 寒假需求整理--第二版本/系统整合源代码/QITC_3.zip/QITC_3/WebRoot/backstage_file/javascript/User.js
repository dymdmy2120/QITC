var power = [ {
	"key" : "00",
	"value" : "查看预警通报表权限"
}, {
	"key" : "01",
	"value" : "管理预警通报表权限"
}, {
	"key" : "10",
	"value" : "查看标准库权限"
}, {
	"key" : "11",
	"value" : "管理标准库权限"
}, {
	"key" : "20",
	"value" : "查看危害物限量库权限"
}, {
	"key" : "21",
	"value" : "管理危害物限量库权限"
}, {
	"key" : "30",
	"value" : "查看实验室表权限"
}, {
	"key" : "31",
	"value" : "管理实验室表权限"
}, {
	"key" : "40",
	"value" : "查看法律法规权限表"
}, {
	"key" : "41",
	"value" : "管理法律法规表权限"
}, {
	"key" : "50",
	"value" : "查看检测情况统计分析"
}, {
	"key" : "51",
	"value" : "管理检测情况统计分析"
}, {
	"key" : "60",
	"value" : "查看检测能力评估"
}, {
	"key" : "61",
	"value" : "管理检测能力评估"
}, {
	"key" : "2",
	"value" : "审核权限"
} ];

var map = new Map();

function powerConvert(v, f) {
	var temp = document.getElementById(v);
	if (f != null) {
		for ( var i = 0; i < power.length; i++) {
			if (power[i].key == f) {
				temp.options.add(new Option(power[i].value, power[i].value));
				map.put(v, f);
			}
		}
	}
}
function deleteUser(u_id) { // 用户删除
	var address = "UserInfo.delete.do?u_id=" + u_id;
	alert(address);
	window.location.href = address;
}
function fillVoHrefUpdate(u_id, u_name, email, phone, department) { // 修改用户信息

	var action = "backstage_file/back/UserInfo_update.jsp?u_id=" + u_id
			+ "&u_name=" + u_name + "&email=" + email + "&department="
			+ department + "&phone=" + phone + "&p_id=" + map.get(u_id);
	window.location.href = action; // js发出post请求
}

function singleValueQuery() {
	var u_name = document.getElementById("u_name").value;
	if (u_name.length < 2 || u_name.length > 30) {
		alert("用户名长度不合法 必须保持在2到30位");
		return false;
	}
	if (u_name != "") {
		var action = "UserInfo.do?u_name=" + u_name;
		window.location.href = action;
	}
}

function resetPassword(u_id, email) { // 密码重置操作
	var action = "UserInfo.update.do?u_id=" + u_id + "&email=" + email;
	window.location.href = action;
}