window.onload = function() {
	var msg = document.getElementById('msg');
	var msg2 = document.getElementById('msg2');
	if (msg != null && msg.value != "/") {
		alert(msg.value);
		window.location.href = "UserInfo.do";
	}
	// 这里主要是针对于用户信息添加模块 更改原因是添加成功后 不需要再次跳转查询
	if (msg2.value != "/") { // 这里只要给出提示信息 不要再次查询
		alert(msg2.value);
	}
};
