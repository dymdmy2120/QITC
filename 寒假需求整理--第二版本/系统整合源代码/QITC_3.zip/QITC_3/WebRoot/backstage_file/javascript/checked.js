function DoCheck() {
	var ch = document.getElementsByName("allchecked");
	var temp = document.getElementsByName("p_id");
	if (ch[0].checked == true) {
		for ( var i = 0; i < temp.length; i++) {
			temp[i].checked = true;
		}
	} else {
		for ( var i = 0; i < temp.length; i++) {
			temp[i].checked = false;
		}
	}
}