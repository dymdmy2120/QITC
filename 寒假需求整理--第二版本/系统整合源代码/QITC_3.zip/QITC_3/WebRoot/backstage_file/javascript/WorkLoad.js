function workload_check() {
	var department = document.getElementById("department");
	var user_name = document.getElementById("u_name");
	if (department.value == "") {
		alert("请输入科室");
		department.focus();
		return false;
	}
	if (user_name.value == "") {
		alert("请输入用户名");
		user_name.focus();
		return false;
	}
	return true;
}