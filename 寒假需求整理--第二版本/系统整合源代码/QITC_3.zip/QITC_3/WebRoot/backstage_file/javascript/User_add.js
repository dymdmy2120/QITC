	var xmlHttp;
	function createXMLHttp() {
		if (window.XMLHttpRequest) {
			xmlHttp = new XMLHttpRequest();
		} else {
			xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
		}
	}

	// ajax异步验证 Id是否已经提交过了
	function AjaxCheck(u_id) {
		if(strTrim(u_id) == "") {
			return;
		}
		createXMLHttp();
		xmlHttp.open("GET", "User.Ajax.do?u_id=" + u_id,true);
		xmlHttp.onreadystatechange = AjaxCallback;
		xmlHttp.send(null);
	}

	function AjaxCallback() {
		if (xmlHttp.readyState == 4) {
			if (xmlHttp.status == 200) {
				var text = xmlHttp.responseText;
				 var btnSubmit = document.getElementById("submit");
				if (text == "false") { // 用户id已经存在了
				    // 将表单提交按钮设置为不可用，这样就可以避免用户再次点击提交按钮
					btnSubmit.disabled= "disabled";
					document.getElementById("uid_prompt").innerHTML = "用户已存在,不可以录入";
				}
				if (text == "true") {
					btnSubmit.disabled="";
					document.getElementById("uid_prompt").innerHTML = "";
				}
			}
		}
	}
	
	function strTrim(str) {
		return str.replace(/^\s+|\s+$/g, '');
	}