function user_add_check() {
	var user_id = strTrim(document.getElementById("u_id").value);
	var user_name =  strTrim(document.getElementById("u_name").value);
	var user_email =  strTrim(document.getElementById("email").value);
	var phone =  strTrim(document.getElementById("phone").value);
	var department =  strTrim(document.getElementById("department").value);
	var temp = document.getElementsByName("p_ids");
	
	if (user_id == "") {
		alert("用户工号不能为空");
		return false;
	}
	if (user_id.length != 8) {
		alert("用户id必须为8位。一位身份标志+入职年份+三位流水号，身份标志为0代表系统管理员，1代表数据维护人员，2代表管理员。");
		return false;
	}
	if (user_name == "") {
		alert("用户姓名不能为空");
		return false;
	}
	if (!(user_name.length >= 2 && user_name.length <= 30)) {
		alert("用户名长度必须在2到30位");
		return false;

	}
	if (user_email == "") {
		alert("用户邮箱不能为空");
		return false;
	}
	if(user_email.length > 25) {
		alert("邮箱长度必须小于25位");
		return false;
	}
	if (user_email != "") {
		var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
		isok = reg.test(user_email);
		if (!isok) {
			alert("邮箱格式不正确，请重新输入！");
			document.getElementById("email").focus();
			return false;
		}
	}
	if (phone == "") {
		alert("用户联系方式不能为空");
		return false;
	}
	if (phone != "") {
		var re1 = /^1\d{10}$/;
		var re2 = /^0\d{2,3}-?\d{7,8}$/;
		var flag1 = re1.test(phone);
		var flag2 = re2.test(phone);
		if (!flag1 && !flag2) {
			alert("联系方式格式不正确! 请输入固定电话或是手机号");
			return false;
		}
	}
	if (department.length == 0 || department.length >20) {
		alert("用户所在科室长度有误");
		return false;
	}
	for ( var i = 0; i < temp.length; i++) {
		if (temp[i].checked == true) {
			temp[temp.length - 1].checked = true; //添加冗余的一个已选字段
			return true;
		}
		if (i == (temp.length - 1)) { // 到达最后
			alert("请分配权限后，再提交！");
			return false;
		}
	}
	temp[temp.length - 1].checked = true; //添加冗余的一个已选字段
	return true;
};

function DoCheck() {
	var ch = document.getElementsByName("allchecked");
	var temp = document.getElementsByName("p_ids");
	if (ch[0].checked == true) {
		for ( var i = 0; i < temp.length; i++) {
			temp[i].checked = true;
		}
	} else {
		for ( var i = 0; i < temp.length; i++) {
			temp[i].checked = false;
		}
	}
}

function strTrim(str) {
	return str.replace(/^\s+|\s+$/g, '');
}
