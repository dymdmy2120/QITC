var select;
function setTab(param, name, cursel, n) {
	select = cursel - 1;
	for (i = 1; i <= n; i++) {
		var menu = document.getElementById(name + i);
		var con = document.getElementById("con_" + name + "_" + i);
		menu.className = i == cursel ? "hover" : "";
		con.style.display = i == cursel ? "block" : "none";
	}
	if (fieldFlag[select] && flag) {
		getPicNam(year, bmonth, emonth, district, title, param, cursel - 1);
		flag = false;
		currIndex = cursel - 1;
	}

}

// 得到通报的标题和对原产地是中国的预警通报的项数
function gtitle(year, district, title, wholeItem, chinaItem, proportion) {

	var strT = "<div> <h1 align='center'><span>" + year + "年" + district
			+ "</span>" + title + "</h1>";
	var strC = "<p><h2>&nbsp;&nbsp;&nbsp;&nbsp;据统计，<span>" + year + "年"
			+ district + "</span>食品预警通报<span>" + wholeItem
			+ "</span>例，其中对中国出口食品预警通报<span>" + chinaItem + "</span>例，占比<span>"
			+ proportion + "%</span>。</h2></p></div>";

	return strT + strC;
}

// 得到柱状图
function gpic(picName) {

	var pic = " <ul><li><img src ='" + picName + "'/></li></ul>";

	return pic;
}

// 当查看全部的时候显示出该柱状图属于那个字段(国家，月份...) 便于好查看具有层次性
function gfield(index, content) {

	var strContent = "<h2 class='field'>&nbsp;&nbsp" + (index + 1) + " ."
			+ content + "</h2>";

	return strContent;
}

// 得到正文 就是通报次数排在前三列的数据
// fielItem是统计某个字段的总数 例如通报国家的个数
function gcontent(index, year, district, wholeItem, fielItem, field, fir,
		fItem, fPropor, sec, sItem, sPropor, thir, tItem, tPropor) {
	// 当字段是通报国家是需要加入具体的国家的个数

	var strH = "<h2><p>&nbsp;<span>" + year + "年</span>，";
	var strCont = "";
	var strE = "具体情况如上图。";

	if (index == 0)
		strH = strH + "共有<span>" + fielItem + "个国家</span>发布产品通报，";
	if (index == 1)
		strCont = "</span>全年来看，<span>" + fir + "和" + sec + "</span>通报量较大。"
	else {
		strCont = "在 <span>" + district + "</span> 发布的 <span>" + wholeItem
				+ "项</span> 通报中， 在 <span>" + district + "</span>食品通报<span>"
				+ field + "</span>中，<span>" + fir + "</span>被通报的次数最多，共 <span>"
				+ fItem + "项</span>，占比 <span>" + fPropor
				+ "%</span>；其次为 <span>" + sec + "</span>，共 <span>" + sItem
				+ "项</span>，占比 <span>" + sPropor + "%</span>；<span>" + thir
				+ "</span>位列第三，共 <span>" + tItem + "项</span>，占比 <span>"
				+ tPropor + "%</span>。";
	}

	if (index == 0)
		strE = "，上述三国合计占"
				+ district
				+ "产品通报总数的<span>"
				+ ((Number(fPropor) + Number(sPropor) + Number(tPropor))
						.toFixed(2)) + "%</span>。具体情况如上图。</p><h2>";
	return strH + strCont + strE;

}

//得到底部 对原产地是中国的预警信息进行统计

function gbottom(first) {

	var strB = "<h2><p>其中，针对中国的食品通报，<span>" + first
			+ "</span>被通报次数最多。</p></h2>";

	return strB;

}
