var currentOperate = "";
function deleteData(name) {
	var pitch = document.getElementsByName("pitch");
	for ( var i = 0; i < pitch.length; i++) {
		pitch[i].style.display = "block";
	}
	changeAll(name, "block");
}

/**
 * 点击数据删除，数据导出触发的函数
 * 
 * @param name
 * @param flag
 * @param operate
 */
function deleteOperate(name, flag, operate) {
	if (currentOperate != "") {
		erasure();
	}
	var pitch = document.getElementsByName("pitch");
	var show;
	if (flag) {
		show = "block";
	} else {
		show = "none";
	}
	document.getElementsByName("allChecked")[0].style.display = show;
	for ( var i = 0; i < pitch.length; i++) {
		pitch[i].style.display = show;
	}
	changeAll(name, show);
	currentOperate = operate;
	var operates = document.getElementsByName("operate");
	for ( var i = 0; i < operates.length; i++) {
		if (i == 1) {
			operates[i].value += operate;
		} else if (i == 0 || i == 2) {
			operates[i].innerHTML = operate;
		} else {
			operates[i].value = operate + operates[i].value;
		}
	}
	var operateAction = document.getElementsByName("operateAction");
	for ( var i = 0; i < operateAction.length; i++) {
		if (operate == "") {
			break;
		}
		if (operateAction[i].action.indexOf("_delete") != -1) {
			if (operate == "删除") {
				break;
			}
			operateAction[i].action = operateAction[i].action.replace(
					"_delete", ".export");
		} else {
			if (operate == "导出") {
				break;
			}
			operateAction[i].action = operateAction[i].action.replace(
					".export", "_delete");
		}
	}
}

/**
 * 情况之前加入的字符
 */
function erasure() {
	var operates = document.getElementsByName("operate");
	var value;
	for ( var i = 0; i < operates.length; i++) {
		value = operates[i].value;
		if (i == 1) {
			operates[i].value = value.substring(0, value
					.indexOf(currentOperate));

		} else if (i == 0 || i == 2) {
			operates[i].innerHTML = "";
		} else {
			operates[i].value = value.substring(
					value.indexOf(currentOperate) + 2, value.length);
		}
	}
	currentOperate = "";
}

/**
 * 点击退出操作时触发的函数
 * 
 * @param name
 */
function cancle(name) {
	// 擦除
	erasure();
	deleteOperate(name, false, "");
}

/**
 * 改变对应复选框的显示
 * 
 * @param name
 * @param show
 */
function changeAll(name, show) {
	var alarms = document.getElementsByName(name);
	for ( var i = 0; i < alarms.length; i++) {
		alarms[i].style.display = show;
	}
}

function getForm(name) {
	var verifyOperate = document.getElementById("verifyOperate");
	var alarms = document.getElementsByName(name);
	var flag = false;
	for ( var i = 0; i < alarms.length; i++) {
		if (alarms[i].checked == true) {
			flag = true;
			verifyOperate.action += "&" + name + "=" + alarms[i].value;
		}
	}
	return flag;
}

/**
 * 提交操作
 */
function commit(name) {
	var verifyOperate = document.getElementById("verifyOperate");
	flag = getForm(name);
	if (flag) {
		verifyOperate.submit();
	} else {
		alert("请至少选择一条数据进行操作！");
		return false;
	}
}

/**
 * 实验室提交操作
 */
function lab_commit(name) {
	var verifyOperate = document.getElementById("verifyOperate");
	flag = getForm(name);
	if (flag) {
		verifyOperate.submit();
	} else {
		alert("请至少选择一条数据进行操作！");
		return false;
	}
}

/**
 * 提交审核操作
 */
function commit(name , agree) {
	var verifyOperate = document.getElementById("verifyOperate");
	flag = getForm(name);
	verifyOperate.action += "&result=" + agree;
	if (flag) {
		verifyOperate.submit();
	} else {
		alert("请至少选择一条数据进行操作！");
		return false;
	}

}

/**
 * 删除全部数据
 */
function deleteAll() {
	var verifyOperate = document.getElementById("verifyOperate");
	if (verifyOperate.action.indexOf("?") != -1) {
		verifyOperate.action += "&delete=all";
	} else {
		verifyOperate.action += "?delete=all";
	}
	verifyOperate.submit();
}

/**
 * 删除全部数据
 */
function verifyAll(flag) {
	var verifyOperate = document.getElementById("verifyOperate");
	if (verifyOperate.action.indexOf("?") != -1) {
		verifyOperate.action += "&delete=all";
	} else {
		verifyOperate.action += "?delete=all";
	}
	verifyOperate.action += "&result=" + flag;
	verifyOperate.submit();
}

/**
 * 选中所有
 */
function pitchAll(name, flag) {
	var alarms = document.getElementsByName(name);
	for ( var i = 0; i < alarms.length; i++) {
		alarms[i].checked = flag;
	}
}

/**
 * 添加信息判断是何种审核
 * @param flag
 */
function addVerify(flag) {
	var batch = document.getElementById("batch");
	if (batch.action.indexOf("?") != -1) {
		batch.action += "&result=" + flag;
	} else {
		batch.action += "?result=" + flag;
	}
}

function DoCheck(name) {
	if (document.getElementsByName("allChecked")[0].checked == true) {
		pitchAll(name, true);
	} else {
		pitchAll(name, false);
	}
}

function validate(f) {
	var begin = f.begin.value;
	var end = f.end.value;
	if (begin == "" || end == "") {
		alert("选中页数不能为空！");
		return false;
	} else if (begin == end) {
		alert("错误：两个选中页数不能相等！当前选择为" + begin + "=" + end);
		return false;
	}
	return true;
}

function EnterPress(e) { // 传入 event
	var e = e || window.event;
	if (e.keyCode == 13) {
		document.getElementById("button1").click();
	}
}
