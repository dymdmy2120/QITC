/*function DoCheck(name) {
	var ch = document.getElementsByName(name);
	if (document.getElementsByName("allChecked")[0].checked == true) {
		for ( var i = 0; i < ch.length; i++) {
			ch[i].checked = true;
		}
	} else {
		for ( var i = 0; i < ch.length; i++) {
			ch[i].checked = false;
		}
	}
}
*/