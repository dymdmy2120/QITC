// ���߷���ͳ��
document.writeln("<script type=\"text/javascript\">");
document.writeln("var _bdhmProtocol = ((\"https:\" == document.location.protocol) ? \" https://\" : \" http://\");");
document.writeln("document.write(unescape(\"%3Cscript src=\'\" + _bdhmProtocol + \"hm.baidu.com/h.js%3F2aeaa32e7cee3cfa6e2848083235da9f\' type=\'text/javascript\'%3E%3C/script%3E\"));");
document.writeln("</script>");
document.writeln("<script language=\"javascript\" type=\"text\/javascript\" src=\"http:\/\/js.users.51.la\/1636395.js\"><\/script>");
document.writeln("<noscript><a href=\"http:\/\/www.51.la\/?1636395\" target=\"_blank\"><img alt=\"&#x6211;&#x8981;&#x5566;&#x514D;&#x8D39;&#x7EDF;&#x8BA1;\" src=\"http:\/\/img.users.51.la\/1636395.asp\" style=\"border:none\" \/><\/a><\/noscript>");
