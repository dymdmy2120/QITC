function Typical_add_check(){
	var fileDocument = document.getElementById("fileDocument").value;
	if(fileDocument==""){
		alert("案例文档不能为空,请上传典型案例!");
		return false;
	}
	return true;
};
function Typical_update_check(){
	var title = document.getElementById("title").value;
	var author = document.getElementById("author").value;
	var introduction = document.getElementById("introduction").value;
	var fileDocument = document.getElementById("fileDocument").value;
	var reason = document.getElementById("reason").value;
	if(reason==""){
		alert("修改理由不能为空！");
		return false;
	}
	if(title==""){
		alert("修改后案例标题不能为空！");
		return false;
	}
	if(author==""){
		alert("修改后请填写案例作者！");
		return false;
	}
	if(introduction==""){
		alert("请详细填写案例的简介");
		return false;
	}
	if(fileDocument==""){
		alert("修改后案例文档不能为空");
		return false;
	}
	return true;
};

function Typical_query_check(){
	var title = document.getElementById("title").value;
	var author = document.getElementById("author").value;
	var introduction = document.getElementById("introduction").value;
	var document = document.getElementById("document").value;
	if(title==""||author==""||introduction==""||document==""){
		alert("请至少输入一个字段进行查询");
		return false;
	}
	return true;
};