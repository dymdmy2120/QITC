function check_import_form(){
	if(document.import_form.uploadFile.value==""){
		document.getElementById("import_target").innerHTML = '<font size="-2" color="#E43633">*请选择文件</font>';
		return false;
	}
	return true;
}

function labAddCheck(){
	var lab_name = document.getElementById("lab_name").value;
	var address = document.getElementById("address").value;
	var contact = document.getElementById("contact").value;
	var functionary = document.getElementById("functionary").value;
	var result = true;
	if(lab_name == ""){
		document.getElementById("lab_name_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(lab_name.length > 60){
		document.getElementById("lab_name_target").innerHTML = '<font size="-2" color="#E43633">*最多60字</font>';
		reslut = false;
	}
	if(address == ""){
		document.getElementById("address_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(address.length > 63 ){
		document.getElementById("address_target").innerHTML = '<font size="-2" color="#E43633">*最多60字</font>';
		reslut = false;
	}
	if(contact == ""){
		document.getElementById("contact_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		reslut = false;
	}
	if(functionary == ""){
		document.getElementById("functionary_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		reslut = false;
	}
	return result;
}

function checkUpdataForm(){
	var lab_name = document.labUpdateForm.lab_name.value;
	var address = document.labUpdateForm.address.value;
	var contact = document.labUpdateForm.contact.value;
	var functionary = document.labUpdateForm.functionary.value;
	var reason = document.labUpdateForm.reason.value;
	var result = true;
	if(lab_name == ""){
		document.getElementById("lab_name_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(lab_name.length > 60){
		document.getElementById("lab_name_target").innerHTML = '<font size="-2" color="#E43633">*最多60字</font>';
		reslut = false;
	}
	if(address == ""){
		document.getElementById("address_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(address.length > 60 ){
		document.getElementById("address_target").innerHTML = '<font size="-2" color="#E43633">*最多60字</font>';
		reslut = false;
	}
	if(contact == ""){
		document.getElementById("contact_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		reslut = false;
	}
	if(functionary == ""){
		document.getElementById("functionary_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		reslut = false;
	}
	if(reason == ""){
		document.getElementById("reason_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		reslut = false;
	}
	if(reason.length > 100){
		document.getElementById("reason_target").innerHTML = '<font size="-2" color="#E43633">*最多100字</font>';
		reslut = false;
	}
	return reslut;
}
