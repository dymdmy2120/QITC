function Detection_add_check(){
	var DocumentTitle = document.getElementById("DocumentTitle").value;
	var DetectionItem = document.getElementById("DetectionItem").value;
	var TestDate = document.getElementById("TestDate").value;
	var Department = document.getElementById("Department").value;
	var ClientInfor = document.getElementById("ClientInfor").value;
	
	if(DocumentTitle==""){
		alert("文档标题不能为空,请从新填写!");
		return false;
	}
	
	if(DetectionItem==""){
		alert("检测样品不能为空,请从新填写!");
		return false;
	}
	if(TestDate==""){
		alert("检测日期不能为空,请从新填写!");
		return false;
	}
	if(Department==""){
		alert("检测部门不能为空,请从新填写!");
		return false;
	}
	if(ClientInfor==""){
		alert("统计文档不能为空,请从新填写!");
		return false;
	}
	return true;
};