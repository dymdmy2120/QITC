function Hazards_check(f) {
	var conditions = new Array("e_residue", "m_name", "mea_site");
	return public_check(f, conditions, "除残 留 物 定 义（英 文），检 测 方 法，测 定 部 位之外，其他属性不能为空！");
}