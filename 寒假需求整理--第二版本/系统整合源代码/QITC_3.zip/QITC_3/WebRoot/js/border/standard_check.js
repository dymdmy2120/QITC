function standard_check(forName){
	
	var form = document.getElementById(forName);
	var tagElements = form.getElementsByTagName("input");
	for(var i = 0;i<tagElements.length;i++) {
		var name = tagElements[i].name;
		if(!(name == "document" || name == "met_profile" )) {
			var value = tagElements[i].value;
			if(value == "") {
			alert("除原文和方法概要可为空外，其他都不允许为空");
			return false;
			}
		}
		
		
	}
	
	return true;
}

//function standard_update_check(){
//	var m_name = document.getElementById("m_name").value;
//	var sta_class = document.getElementById("sta_class").value;
//	var rel_date = document.getElementById("rel_date").value;
//	var imp_date = document.getElementById("imp_date").value;
//	var dra_unit = document.getElementById("dra_unit").value;
//	var sta_state = document.getElementById("sta_state").value;
//	var mbr_cname = document.getElementById("mbr_cname").value;
//	var principle = document.getElementById("principle").value;
//	var tdocument = document.getElementById("document").value;
//	var line = document.getElementById("line").value;
//	if(m_name ==""){
//		alert("修改后名称类别字段不能为空");
//		return false;
//	}
//	if(sta_class==""){
//		alert("修改后标准类别字段不能为空");
//		return false;
//	}
//	if(rel_date==""){
//		alert("修改后发布日期状态字段不能为空");
//		return false;
//	}
//	if(imp_date==""){
//		alert("修改后实施日期字段不能为空");
//		return false;
//	}
//	if(dra_unit==""){
//		alert("修改后发布单位字段不能为空");
//		return false;
//	}
//	if(sta_state==""){
//		alert("修改后标准状态字段不能为空");
//		return false;
//	}
//	if(mbr_cname==""){
//		alert("修改后检测项目字段不能为空");
//		return false;
//	}
//	if(principle==""){
//		alert("修改后原理字段不能为空");
//		return false;
//	}
//	
//	if(line==""){
//		alert("检测底限字段不能为空");
//		return false;
//	}
//	return true;
//};
//
