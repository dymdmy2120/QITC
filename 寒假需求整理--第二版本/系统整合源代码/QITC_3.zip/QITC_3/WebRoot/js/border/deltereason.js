$(document).ready(function(){
	//点击数据删除
	$("#delete").click(function(){
		$("#reasDiv").css("display","block");
		
		
	});
	//退出删除
	$("#exit").click(function(){
		
		$("#reasDiv").css("display","none");
	});
	$("#confirm").click(function(){
		$("#batch").append($("#reasDiv"));
		
	});
	var link = $("#ver_delete").attr("href");
	$("#ver_delete").click(function(){
		var reason = $("#reason").val();
		if(reason == ""){
			alert("理由没填！");
			$("#ver_delete").attr("href","javascript:void()");
			
			} else {
				$("#ver_delete").attr("href","javascript:void()");
				link = link+"&reason="+reason;
				window.location=link;
			}
			
		
	});
});