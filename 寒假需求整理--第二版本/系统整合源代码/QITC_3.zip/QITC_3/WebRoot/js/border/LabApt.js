/*function labApt_check(f) {
	var forms = f.getElementsByTagName("input");
	alert(document.getElementsByName("reason").length);
	for(var i = 0 ; i < forms.length ; i ++) {
		var name = forms[i].name;
		var value = forms[i].value;
		if(!(name == "explaination" || name == "aptutide" || name == "limit_scope"|| name == "project_id")) {
			if(value == "") {
				alert("除项目序号，限制范围，说明，资质类别之外，其他属性不能为空！");
				return false;
			}
		}
	}
	var reson = document.getElementsByName("reason");
	if(reson.length != 0) {
		if(reson[0].value == "") {
			alert("修改理由不能为空！");
			return false;
		}
	}
	
	return true;
}
 */

function labApt_check(f) {
	var conditions = new Array("explaination", "aptutide", "limit_scope",
			"project_id");
	return public_check(f, conditions, "除项目序号，限制范围，说明，资质类别之外，其他属性不能为空！");
}