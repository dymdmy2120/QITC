function public_check(f , conditions , msg) {
	var forms = f.getElementsByTagName("input");
	var flag = false;
	for(var i = 0 ; i < forms.length ; i ++) {
		var name = forms[i].name;
		var value = forms[i].value;
		for(var j = 0 ; j < conditions.length ;j ++) {
			if(name == conditions[j]) {
				flag = true;
				break;
			}
		}
		if(!flag) {
			if(value == "") {
				alert(msg);
				return false;
			}
		}
	}
	var reson = document.getElementsByName("reason");
	if(reson.length != 0) {
		if(reson[0].value == "") {
			alert("修改理由不能为空！");
			return false;
		}
	}
	
	return true;
}