function laws_addCheck(){
	var result = true;
	if(document.lawAddForm.proof.value==""){
		document.getElementById("proof_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(document.lawAddForm.laws_name.value==""){
		document.getElementById("name_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	
	if(document.lawAddForm.countries.value==""){
		document.getElementById("countries_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(document.lawAddForm.laws_state.value==""){
		document.getElementById("state_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}

	if(document.lawAddForm.rel_date.value==""){
		document.getElementById("rel_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(document.lawAddForm.act_date.value==""){
		document.getElementById("act_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	return result;
}

function laws_updateCheck(){
	var result = true;
	if(document.lawAddForm.proof.value==""){
		document.getElementById("proof_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(document.lawAddForm.laws_name.value==""){
		document.getElementById("name_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	
	if(document.lawAddForm.countries.value==""){
		document.getElementById("countries_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(document.lawAddForm.laws_state.value==""){
		document.getElementById("state_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}

	if(document.lawAddForm.rel_date.value==""){
		document.getElementById("rel_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	if(document.lawAddForm.act_date.value==""){
		document.getElementById("act_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
	}
	var reason = document.getElementById("reason").value;
	if(reason == ""){
		document.getElementById("reason_target").innerHTML = '<font size="-2" color="#E43633">*必填</font>';
		result = false;
		return false;
	}
	return result;
}

function laws_importCheck(){
	if(document.lawsAddForm1.uploadFile.value==""){
		document.getElementById("import_target").innerHTML = '<font size="-2" color="#E43633">*请选择文件</font>';
		return false;
	}
	return true;
}

function CheckDate(strDate,target) {
    var reg = /^(\d{4})-(\d{2})-(\d{2})$/;
    alert(target+":"+strDate+":");
    if (!reg.test(strDate)) {
    	document.getElementById(target).innerHTML = '<font size="-2" color="#E43633">*格式为:yyyy-mm-dd</font>';
        return false;
    }
    var year = strDate.substring(0, 4);
    var month = strDate.substring(5, 7);
    var date = strDate.substring(8, 10);
    if (!checkYear(year)) { return false; }
    if (!checkMonth(month)) { return false; }
    if (!checkDate(year, month, date)) { return false; }
    return true;
}
function checkYear(year,target) {
    if (isNaN(parseInt(year))) {
    	document.getElementById(target).innerHTML = '<font size="-2" color="#E43633">*年份错误</font>';
        return false;
    }
    else return true;
}
function checkMonth(month,target) {
    if (isNaN(parseInt(month, 10))) {
    	document.getElementById(target).innerHTML = '<font size="-2" color="#E43633">*月份错误</font>';
    	return false; 
    }
    else if (parseInt(month, 10) < 1 || parseInt(month, 10) > 12) {
    	document.getElementById(target).innerHTML = '<font size="-2" color="#E43633">*月份在1-12之间</font>';
        return false;
    }
    else return true;
}
function checkDate(year, month, date,target) {
    var daysOfMonth = CalDays(parseInt(year), parseInt(month));
    if (isNaN(parseInt(date))) {
    	document.getElementById(target).innerHTML = '<font size="-2" color="#E43633">*日期错误</font>';
    	return false; 
    }
    else if (parseInt(date) < 1 || parseInt(date) > daysOfMonth) { 
    	document.getElementById(target).innerHTML = '<font size="-2" color="#E43633">*日期在1-'+daysOfMonth+'之间</font>';
    	return false; 
    }
    else return true;
}
function CalDays(year, month) {
    var date = new Date(year, month, 0);
    return date.getDate();
}
function isLeapYear(year) {
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) return true;
    else return false;
}

