function loginFormValidate(){
	if(document.loginForm.u_id.value==""){
		window.alert("请输入账号！");
		return false;
	}
	if(document.loginForm.password.value==""){
		window.alert("请输入用户登录密码！");
		return false;
	}
	if(document.loginForm.operation.value==""){
		window.alert("请选择登录用户类型！");
		return false;
	}
	return true;
}

function forgetPasValidate(){
	if(document.forgetPas.u_id.value==""){
		window.alert("请输入账号！");
		return false;
	}
	return true;
}

function anwserFormValidate(){
	if(document.anwserForm.answer1.value==""){
		window.alert("请输入密保问题一的答案！");
		return false;
	}
	if(document.anwserForm.answer2.value==""){
		window.alert("请输入密保问题二的答案！");
		return false;
	}
	if(document.anwserForm.answer3.value==""){
		window.alert("请输入密保问题三的答案！");
		return false;
	}
	return true;
}

function alertPasFormValidate(){
	if(document.alertPas.newPass.value==""){
		window.alert("请输入新密码！");
		return false;
	}
	if(document.alertPas.password.value==""){
		window.alert("请再次输入密码！");
		return false;
	}
	if(document.alertPas.newPass.value != document.alertPas.password.value){
		window.alert("两次密码不相同，请确认！");
		return false;
	}
	return true;
}