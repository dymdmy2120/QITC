package cn.jxqt.service;

import static org.junit.Assert.fail;

import org.junit.Test;
import org.web.access.factory.OperateServiceExecuteAdviceFactory;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.service.OperateServiceExecuteAdvice;

public class LabTestServiceTest {

	@Test
	public void testSave() throws ErrorException, BeanInitializationException {
		OperateServiceExecuteAdvice service = OperateServiceExecuteAdviceFactory.getService("LabTest");
		service.execute(null, "save");
	}

	@Test
	public void testUpdate() {
		fail("Not yet implemented");
	}

	@Test
	public void testDelete() {
		fail("Not yet implemented");
	}

}
