package cn.jxqt.service;


import org.junit.Test;
import org.web.exception.BeanInitializationException;
import org.web.exception.ErrorException;
import org.web.service.QueryService;

public class QueryServiceTest {

	@Test
	public void test() throws ErrorException, BeanInitializationException {
		QueryService service = new QueryService("LabTest");
		service.getResult(null, null);
	}

}

